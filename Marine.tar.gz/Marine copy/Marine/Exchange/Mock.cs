﻿using System;
using System.Collections.Generic;
using Marine.Config;
using Marine.Proto;

namespace Marine.Exchange
{
    public class MockExchange : Exchange
    {
        public Dictionary<long, Order> Orders = new Dictionary<long, Order>();

        public MockExchange(ExchangeConfig conf) : base(conf)
        {
        }

        public override bool SendOrder(Order order)
        {
            var id = Orders.Count + 1;
            Orders[id] = order;
            order.Id = id;
            return true;
        }

        public override bool CancelOrder(Order order)
        {
            order.State = Order.Types.StateType.Cancel;
            return true;
        }

        public override bool GetOrderResponse(Order order)
        {
            if (!order.IsOpen())
            {
                return true;
            }

            if (CurTick.ContainsKey(order.Symbol))
            {
                var t = CurTick[order.Symbol];
                var qfill = 0.0;
                var avgpx = 0.0;
                var remain = order.Quantity;

                if (order.Side == Order.Types.SideType.Buy)
                {
                    for (var i = 0; i < t.Asks.Count; i++)
                    {
                        var prc = t.Asks[i];
                        if (order.Price >= prc)
                        {
                            var size = t.AskSizes[i];
                            var fill = Math.Min(remain, size);

                            avgpx = (avgpx * qfill + prc * fill) / (qfill + fill);
                            qfill += fill;
                            remain -= fill;
                            if (remain <= 0) break;
                        }
                    }
                }
                else
                {
                    for (var i = 0; i < t.Bids.Count; i++)
                    {
                        var prc = t.Bids[i];
                        if (order.Price <= prc)
                        {
                            var size = t.BidSizes[i];
                            var fill = Math.Min(remain, size);

                            avgpx = (avgpx * qfill + prc * fill) / (qfill + fill);
                            qfill += fill;
                            remain -= fill;
                            if (remain <= 0) break;
                        }
                    }
                }

                order.AvgPrice = avgpx;
                order.Qfill = qfill;
                order.Qdone += qfill;
                order.UpdateUtc = t.UpdateUtc;
                order.State = remain > 0 ? Order.Types.StateType.Live : Order.Types.StateType.Fill;
                return true;
            }

            order.State = Order.Types.StateType.Live;
            return false;
        }
    }
}
