﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Marine.Common;
using Marine.Config;
using Marine.Proto;
using Newtonsoft.Json;

namespace Marine.Exchange.Huobi
{
    public partial class HoubiExchange : Exchange
    {
        public const string ApiUri = @"http://api.huobi.com";
        public const string PostApiUri = @"https://api.huobi.com/apiv3";
        public const string TickerUri = "staticmarket/ticker_{0}_json.js";
        public const string DepthUri = "staticmarket/depth_{0}_{1}.js";

        public HoubiExchange(HuobiConfig conf) : base(conf)
        {
        }

        public override Tick GetTick(string sym)
        {
            var t = new Tick
            {
                Exchange = Name,
                Symbol = sym,
                CreateUtc = DateTime.Now.ToUnixTime()
            };
            var conf = ConfigDic[sym];

            RestTicker ticker = null;
            RestDepth depth = null;
            try
            {
                if (conf.IsTicker)
                {
                    var url = string.Format($"{ApiUri}/{TickerUri}", sym);
                    ticker = WebUtil.Get<RestTicker>(url, null, Conf.TimeoutInMs);
                }
                if (conf.IsDepth)
                {
                    var url = string.Format($"{ApiUri}/{DepthUri}", sym, conf.ReqDepth);
                    depth = WebUtil.Get<RestDepth>(url, null, Conf.TimeoutInMs);
                }
            }
            catch (Exception ex)
            {
                Error($"GetTick error: {ex.Message}");
            }

            if (ticker == null && depth == null)
                return null;

            if (ticker != null)
            {
                t.ServerUtc = ticker.time;
                t.Last = ticker.ticker.last;
                t.AccVol = ticker.ticker.vol;
                t.Bid = ticker.ticker.buy;
                t.Ask = ticker.ticker.sell;
            }
            if (depth != null)
            {
                foreach (var a in depth.asks)
                {
                    t.Asks.Add(a[0]);
                    t.AskSizes.Add(a[1]);
                }
                foreach (var b in depth.bids)
                {
                    t.Bids.Add(b[0]);
                    t.BidSizes.Add(b[1]);
                }

                if (conf.AggDepth > 0 && conf.AggPrecise > 0)
                {
                    TickHelper.AggregateOrderBook(t, conf.AggPrecise, conf.AggDepth, conf.UseAggPrice);
                }
            }
            t.UpdateUtc = DateTime.Now.ToUnixTime();
            return t;
        }

        #region post helper
        private string EncrypPostParams(IEnumerable<KeyValuePair<string, string>> values)
        {
            var sign = string.Join("&", values.Select(kv => kv.Key + "=" + kv.Value).ToArray());

            using (var md5Hash = MD5.Create())
            {
                var data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(sign));
                return BitConverter.ToString(data).Replace("-", "").ToLower();
            }
        }
        public string CoinSymConv(string sym)
        {
            if (sym.ToLower().Contains("btc"))
                return "1";
            if (sym.ToLower().Contains("ltc"))
                return "2";
            return null;
        }

        private T Post<T>(string method, Dictionary<string, string> extras = null)
        {
            var args = new Dictionary<string, string>
            {
                {"created", ((long)DateTime.UtcNow.ToUnixTime()).ToString()},
                {"access_key", Conf.AccessKey},
                {"secret_key", Conf.SecretKey},
                {"method", method}
            };
            extras?.Keys.ToList().ForEach(k => args[k] = extras[k]);
            args["sign"] = EncrypPostParams(args.OrderBy(kvp => kvp.Key));
            args.Remove("secret_key");

            try
            {
                string json;
                using (var client = new WebUtil(Conf.TimeoutInMs))
                {
                    client.Headers.Set("Content-Type", "application/x-www-form-urlencoded");
                    var response = client.UploadValues(PostApiUri, WebUtil.ToPostParam(args));
                    json = Encoding.UTF8.GetString(response);
                    Debug($"[POST]{method}: {json}");
                }

                if (json.Contains("code"))
                {
                    var obj = JsonConvert.DeserializeObject<RestError>(json);
                    throw new Exception(obj.message);
                }
                else
                {
                    var obj = JsonConvert.DeserializeObject<T>(json);
                    return obj;
                }
            }
            catch (Exception ex)
            {
                var msg = $"post={method},params={args.ToDebugString()},error={ex.Message}";
                throw new Exception(msg);
            }
        }
        #endregion

        public override Account GetAccount()
        {
            try
            {
                var uinfo = Post<RestAccountInfo>("get_account_info");
                var acct = new Account
                {
                    Exchange = Name,
                    Btc = uinfo.available_btc_display,
                    Ltc = uinfo.available_ltc_display,
                    Cny = uinfo.available_cny_display,
                    UpdateUtc = DateTime.Now.ToUnixTime()
                };
                Account = acct;
                return acct;
            }
            catch (Exception ex)
            {
                Error($"GetAccount error: {ex.Message}");
                return null;
            }
        }

        public override bool SendOrder(Order order)
        {
            var args = new Dictionary<string, string>
            {
                {"coin_type", CoinSymConv(order.Symbol)},
                {"price", order.Price.ToString("F2")},
                {"amount", Math.Abs(order.Quantity).ToString("F2")}
            };

            try
            {
                var method = order.Side == Order.Types.SideType.Buy ? "buy" : "sell";
                var trade = Post<RestTrade>(method, args);
                var result = trade.result.ToLower().Equals("success");
                if (result)
                {
                    order.Id = trade.id;
                }
                Info($"send order: {order.DumpToString()}");
                return result;
            }
            catch (Exception ex)
            {
                Error($"SendOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool CancelOrder(Order order)
        {
            var args = new Dictionary<string, string>
            {
                {"id", order.Id.ToString()},
                {"coin_type", CoinSymConv(order.Symbol)}
            };

            try
            {
                var trade = Post<RestTrade>("cancel_order", args);
                Info($"cancel order: {order.DumpToString()}");
                return trade.result.ToLower().Equals("success");
            }
            catch (Exception ex)
            {
                Error($"CancelOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool GetOrderResponse(Order order)
        {
            var args = new Dictionary<string, string>
            {
                {"id", order.Id.ToString()},
                {"coin_type", CoinSymConv(order.Symbol)}
            };

            try
            {
                var rsp = Post<RestOrderInfo>("order_info", args);
                if (rsp.status == 0 || rsp.status == 1)
                    order.State = Order.Types.StateType.Live;
                else if (rsp.status == 2)
                    order.State = Order.Types.StateType.Fill;
                else if (rsp.status == 3)
                    order.State = Order.Types.StateType.Cancel;
                else
                    order.State = Order.Types.StateType.Unack;

                order.AvgPrice = rsp.processed_price;
                order.Qfill = rsp.processed_amount - order.Qdone;
                order.Qdone = rsp.processed_amount;
                order.UpdateUtc = DateTime.Now.ToUnixTime();
                //Info($"get order response: {order.DumpToString()}");
                return true;
            }
            catch (Exception ex)
            {
                Error($"GetOrderResponse error: {ex.Message}");
                return false;
            }
        }

        public override bool PostUnitTest()
        {
            var symbol = "btc";
            var tick = GetTick(symbol);
            Helper.Assert(tick != null, "unittest: GetTick");

            var acct = GetAccount();
            Helper.Assert(acct != null, "unittest: GetAccount");

            var order = new Order
            {
                Side = Order.Types.SideType.Buy,
                Symbol = symbol,
                Price = tick.Bids.Last() * (1 - 0.02),
                Quantity = 0.01
            };
            Helper.Assert(SendOrder(order), "unittest: SendOrder");

            if (order.Id > 0)
            {
                Thread.Sleep(500);
                Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");

                Helper.Assert(CancelOrder(order), "unittest: CancelOrder");
                Thread.Sleep(500);
                Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");
            }
            return true;
        }
    }
}
