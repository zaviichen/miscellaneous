﻿using System.Collections.Generic;

namespace Marine.Exchange.Huobi
{
    public class RestError
    {
        public int code;
        public string message;
        public string msg;
    }

    public class RestTicker
    {
        public class Ticker
        {
            public string symbol;
            public double buy;
            public double high;
            public double last;
            public double low;
            public double sell;
            public double vol;
            public double open;
        }

        public long time;
        public Ticker ticker;
    }

    public class RestDepth
    {
        public List<List<double>> asks;
        public List<List<double>> bids;
    }

    public class RestAccountInfo
    {
        public double total;
        public double net_asset;
        public double available_cny_display;
        public double available_btc_display;
        public double available_ltc_display;
        public double frozen_cny_display;
        public double frozen_btc_display;
        public double frozen_ltc_display;
        public double loan_cny_display;
        public double loan_btc_display;
        public double loan_ltc_display;
    }
    public class RestTrade
    {
        public string result;
        public long id;
    }

    public class RestOrderInfo
    {
        public long id;
        public int type;
        public double order_price;
        public double order_amount;
        public double processed_price;
        public double processed_amount;
        public double vot;
        public double fee;
        public double total;
        public int status;
    }
}
