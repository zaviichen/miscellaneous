﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Marine.Common;
using Marine.Config;
using Marine.Proto;
using Newtonsoft.Json;

namespace Marine.Exchange.Okcoin
{
    public class OkcoinExchange : Exchange
    {
        public const string ApiUri = @"https://www.okcoin.cn";

        public OkcoinExchange(OkcoinConfig conf) : base(conf)
        {
        }

        public override Tick GetTick(string sym)
        {
            var t = new Tick
            {
                Exchange = Name,
                Symbol = sym,
                CreateUtc = DateTime.Now.ToUnixTime()
            };
            var conf = ConfigDic[sym];

            SpotTicker ticker = null;
            SpotDepth depth = null;
            try
            {
                if (conf.IsTicker)
                {
                    var args = new Dictionary<string, object>();
                    args["symbol"] = sym;
                    ticker = WebUtil.Get<SpotTicker>($"{ApiUri}/api/v1/ticker.do", args, Conf.TimeoutInMs);
                }
                if (conf.IsDepth)
                {
                    var args = new Dictionary<string, object>();
                    args["symbol"] = sym;
                    args["size"] = conf.ReqDepth;
                    depth = WebUtil.Get<SpotDepth>($"{ApiUri}/api/v1/depth.do", args, Conf.TimeoutInMs);
                }
            }
            catch (Exception ex)
            {
                Error($"GetTick error: {ex.Message}");
            }
            
            if (ticker == null && depth == null)
                return null;
            
            if (ticker != null)
            {
                t.ServerUtc = ticker.date;
                t.Last = ticker.ticker.last;
                t.AccVol = ticker.ticker.vol;
                t.Bid = ticker.ticker.buy;
                t.Ask = ticker.ticker.sell;
            }
            if (depth != null)
            {
                foreach (var a in depth.asks)
                {
                    t.Asks.Add(a[0]);
                    t.AskSizes.Add(a[1]);
                }
                foreach (var b in depth.bids)
                {
                    t.Bids.Add(b[0]);
                    t.BidSizes.Add(b[1]);
                }

                if (conf.AggDepth > 0 && conf.AggPrecise > 0)
                {
                    TickHelper.AggregateOrderBook(t, conf.AggPrecise, conf.AggDepth, conf.UseAggPrice);
                }
            }
            t.UpdateUtc = DateTime.Now.ToUnixTime();
            return t;
        }

        #region post helper
        private string EncrypPostParams(IEnumerable<KeyValuePair<string, string>> values)
        {
            var sign = string.Join("&", values.Select(kv => kv.Key + "=" + kv.Value).ToArray());
            sign += $"&secret_key={Conf.SecretKey}";

            using (var md5Hash = MD5.Create())
            {
                var data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(sign));
                var sBuilder = new StringBuilder();
                foreach (var e in data)
                {
                    sBuilder.Append(e.ToString("x2"));
                }
                return sBuilder.ToString().ToUpper();
            }
        }

        private T Post<T>(string url, Dictionary<string, string> args)
        {
            args["api_key"] = Conf.AccessKey;
            args["sign"] = EncrypPostParams(args.OrderBy(kvp => kvp.Key));

            try
            {
                using (var client = new WebUtil(Conf.TimeoutInMs))
                {
                    var response = client.UploadValues(url, WebUtil.ToPostParam(args));
                    var json = Encoding.Default.GetString(response);
                    Debug($"[POST]{url}: {json}");
                    return JsonConvert.DeserializeObject<T>(json);
                }
            }
            catch (Exception ex)
            {
                var msg = $"post={url},params={args.ToDebugString()},error={ex.Message}";
                throw new Exception(msg);
            }
        }
        #endregion

        public override Account GetAccount()
        {
            var args = new Dictionary<string, string>();
            try
            {
                var uinfo = Post<SpotUserinfo>($"{ApiUri}/api/v1/userinfo.do", args).info.funds;
                var acct = new Account
                {
                    Exchange = Name,
                    UpdateUtc = DateTime.Now.ToUnixTime(),

                    Btc = uinfo.free.btc,
                    Ltc = uinfo.free.ltc,
                    Cny = uinfo.free.cny,

                    BorrowBtc = uinfo.borrow.btc,
                    BorrowLtc = uinfo.borrow.ltc,
                    BorrowCny = uinfo.borrow.cny,

                    FreezeBtc = uinfo.freezed.btc,
                    FreezeLtc = uinfo.freezed.ltc,
                    FreezeCny = uinfo.freezed.cny
                };
                Account = acct;
                return acct;
            }
            catch (Exception ex)
            {
                Error($"GetAccount error: {ex.Message}");
                return null;
            }
        }

        public override bool SendOrder(Order order)
        {
            var args = new Dictionary<string, string>
            {
                {"symbol", order.Symbol},
                {"type", order.Side == Order.Types.SideType.Buy ? "buy" : "sell"},
                {"price", order.Price.ToString("F2")},
                {"amount", Math.Abs(order.Quantity).ToString("F2")}
            };

            try
            {
                var trade = Post<SpotTrade>($"{ApiUri}/api/v1/trade.do", args);
                if (trade.result)
                {
                    order.Id = trade.order_id;
                }
                Info($"send order: {order.DumpToString()}");
                return trade.result;
            }
            catch (Exception ex)
            {
                Error($"SendOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool CancelOrder(Order order)
        {
            var args = new Dictionary<string, string>
            {
                {"symbol", order.Symbol},
                {"order_id", order.Id.ToString()}
            };

            try
            {
                var trade = Post<SpotCancelOrder>($"{ApiUri}/api/v1/cancel_order.do", args);
                Info($"cancel order: {order.DumpToString()}");
                return trade.result;
            }
            catch (Exception ex)
            {
                Error($"CancelOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool GetOrderResponse(Order order)
        {
            var args = new Dictionary<string, string>
            {
                {"symbol", order.Symbol},
                {"order_id", order.Id.ToString()}
            };

            try
            {
                var oinfo = Post<SpotOrderInfo>($"{ApiUri}/api/v1/order_info.do", args);
                if (oinfo.result)
                {
                    var rsp = oinfo.orders[0];
                    if (rsp.status == -1)
                        order.State = Order.Types.StateType.Cancel;
                    else if (rsp.status == 0 || rsp.status == 1)
                        order.State = Order.Types.StateType.Live;
                    else if (rsp.status == 2)
                        order.State = Order.Types.StateType.Fill;
                    else if (rsp.status == 4)
                        order.State = Order.Types.StateType.Cancel;
                    else
                        order.State = Order.Types.StateType.Unack;

                    order.AvgPrice = rsp.avg_price;
                    order.Qfill = rsp.deal_amount - order.Qdone;
                    order.Qdone = rsp.deal_amount;
                    order.UpdateUtc = DateTime.Now.ToUnixTime();
                }
                //Info($"get order response: {order.DumpToString()}");
                return oinfo.result;
            }
            catch (Exception ex)
            {
                Error($"GetOrderResponse error: {ex.Message}");
                return false;
            }
        }

        public override bool PostUnitTest()
        {
            var symbol = "btc_cny";
            var tick = GetTick(symbol);
            Helper.Assert(tick != null, "unittest: GetTick");

            var acct = GetAccount();
            Helper.Assert(acct != null, "unittest: GetAccount");

            var order = new Order
            {
                Side = Order.Types.SideType.Buy,
                Symbol = symbol,
                Price = tick.Bids.Last() * (1 - 0.02),
                Quantity = 0.01
            };
            Helper.Assert(SendOrder(order), "unittest: SendOrder");

            if (order.Id > 0)
            {
                Thread.Sleep(500);
                Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");

                Helper.Assert(CancelOrder(order), "unittest: CancelOrder");
                Thread.Sleep(500);
                Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");
            }
            return true;
        }
    }
}
