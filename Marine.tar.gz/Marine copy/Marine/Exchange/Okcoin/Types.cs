﻿using System.Collections.Generic;

namespace Marine.Exchange.Okcoin
{
    #region Spot
    public class SpotTicker
    {
        public class Ticker
        {
            public double buy;
            public double high;
            public double last;
            public double low;
            public double sell;
            public double vol;
        }

        public long date;
        public Ticker ticker;
    }

    public class SpotDepth
    {
        public List<List<double>> asks;
        public List<List<double>> bids;
    }

    public class SpotUserinfo
    {
        public class Info
        {
            public Funds funds;
        }

        public class Funds
        {
            public Asset asset;
            public Currencies borrow;
            public Currencies free;
            public Currencies freezed;
        }

        public class Asset
        {
            public double net;
            public double total;
        }

        public class Currencies
        {
            public double btc;
            public double cny;
            public double ltc;
        }

        public bool result;
        public Info info;
    }

    public class SpotTrade
    {
        public bool result;
        public long order_id;
    }

    public class SpotCancelOrder
    {
        public bool result;
        public long order_id;
        public string success;
        public string error;
    }

    public class SpotOrderInfo
    {
        public class OrderInfo
        {
            public double amount;
            public double avg_price;
            public long create_date;
            public double deal_amount;
            public long order_id;
            //public long orders_id;
            public double price;
            public int status;
            public string symbol;
            public string type;
        }

        public bool result;
        public List<OrderInfo> orders;
    }
    #endregion

    #region Future
    public class FutureTicker
    {
        public class Ticker
        {
            public double buy;
            public double high;
            public double last;
            public double low;
            public double sell;
            public double vol;
            public double coin_vol;
            public int unit_amount;
        }

        public long date;
        public Ticker ticker;
    }
    
    public class FutureDepth
    {
        public List<List<double>> asks;
        public List<List<double>> bids;
    }

    public class FutureIndex
    {
        public double future_index;
    }

    public class FutureUserinfo
    {
        public class Info
        {
            public Funds btc;
            public Funds ltc;
        }

        public class Funds
        {
            public double account_rights;
            public double keep_deposit;
            public double profit_real;
            public double profit_unreal;
            public double risk_rate;
        }
        
        public bool result;
        public Info info;
    }

    public class FutureOrderInfo
    {
        public class OrderInfo
        {
            public double amount;
            public string contract_name;
            public double price_avg;
            public long create_date;
            public double deal_amount;
            public long order_id;
            public double fee;
            public double price;
            public int status;
            public string symbol;
            public string type;
            public int lever_rate;
            public int unit_amount;
        }

        public bool result;
        public List<OrderInfo> orders;
    }
    
    public class FutureTrade
    {
        public bool result;
        public long order_id;
    }

    public class FutureCancelOrder
    {
        public bool result;
        public long order_id;
        public string success;
        public string error;
    }
    #endregion
}
