﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Marine.Common;
using Marine.Config;
using Marine.Proto;
using Newtonsoft.Json;

namespace Marine.Exchange.Okcoin
{
    public class OkcoinFuture : Exchange
    {
        public const string ApiUri = @"https://www.okcoin.com/api/v1";

        public enum CoinType
        {
            BTC_T,
            BTC_N,
            BTC_Q,
            LTC_T,
            LTC_N,
            LTC_Q,
            BTC_IDX,
            LTC_IDX
        }
        
        public string[] SymbolToExNames(string sym)
        {
            var coin = Helper.EnumParse<CoinType>(sym);
            switch (coin)
            {
                case CoinType.BTC_IDX:
                    return new[] {"btc_usd", ""};
                case CoinType.LTC_IDX:
                    return new[] {"ltc_usd", ""};
                case CoinType.BTC_T:
                    return new[] {"btc_usd", "this_week"};
                case CoinType.BTC_N:
                    return new[] {"btc_usd", "next_week"};
                case CoinType.BTC_Q:
                    return new[] {"btc_usd", "quarter"};
                case CoinType.LTC_T:
                    return new[] {"ltc_usd", "this_week"};
                case CoinType.LTC_N:
                    return new[] {"ltc_usd", "next_week"};
                case CoinType.LTC_Q:
                    return new[] {"ltc_usd", "quarter"};
                default:
                    throw new Exception("invalid type");
            }
        }
        
        public DateTime ExpireDate(CoinType type)
        {
            var today = DateTime.Today;
            if (type == CoinType.BTC_T || type == CoinType.LTC_T)
            {
                var friday = today.AddDays(-(int)today.DayOfWeek).AddDays(4);
                return friday;
            }
            if (type == CoinType.BTC_N || type == CoinType.LTC_N)
            {
                var friday = today.AddDays(-(int) today.DayOfWeek).AddDays(4);
                return friday.AddDays(7);
            }
            if (type == CoinType.BTC_Q || type == CoinType.LTC_Q)
            {
                DateTime quanrterEnd;
                var id = today.Month / 3;

                if (id == 0)
                    quanrterEnd = new DateTime(today.Year, 3, 31);
                else if (id == 1)
                    quanrterEnd = new DateTime(today.Year, 6, 30);
                else if (id == 2)
                    quanrterEnd = new DateTime(today.Year, 9, 30);
                else
                    quanrterEnd = new DateTime(today.Year, 12, 31);

                var friday = quanrterEnd;
                while (friday.DayOfWeek != DayOfWeek.Friday)
                {
                    friday = friday.AddDays(-1);
                }
                return friday;
            }
            return today;
        }
        
        public OkcoinFuture(OkcoinConfig conf) : base(conf)
        {
        }

        public override Tick GetTick(string sym)
        {
            var coin = Helper.EnumParse<CoinType>(sym);
            if (coin == CoinType.BTC_IDX || coin == CoinType.LTC_IDX)
            {
                return GetIndex(sym);
            }
            else
            {
                return GetFuture(sym);
            }
        }

        public Tick GetFuture(string sym)
        {
            var names = SymbolToExNames(sym);
            var symbol = names[0];
            var contract = names[1];

            var t = new Tick
            {
                Exchange = Name,
                Symbol = sym,
                Type = Tick.Types.CoinType.Future,
                CreateUtc = Now.ToUnixTime()
            };
            var conf = ConfigDic[sym];

            FutureTicker ticker = null;
            FutureDepth depth = null;
            try
            {
                if (conf.IsTicker)
                {
                    var args = new Dictionary<string, object>
                    {
                        {"symbol", symbol},
                        {"contract_type", contract}
                    };
                    ticker = WebUtil.Get<FutureTicker>($"{ApiUri}/future_ticker.do", args, Conf.TimeoutInMs);
                }
                if (conf.IsDepth)
                {
                    var args = new Dictionary<string, object>
                    {
                        {"symbol", symbol},
                        {"contract_type", contract},
                        {"size", conf.ReqDepth}
                    };
                    depth = WebUtil.Get<FutureDepth>($"{ApiUri}/future_depth.do", args, Conf.TimeoutInMs);
                }
            }
            catch (Exception ex)
            {
                Error($"GetTick error: {ex.Message}");
            }
            
            if (ticker == null && depth == null)
                return null;
            
            if (ticker != null)
            {
                t.ServerUtc = ticker.date;
                t.Last = ticker.ticker.last;
                t.AccVol = ticker.ticker.vol;
                t.Bid = ticker.ticker.buy;
                t.Ask = ticker.ticker.sell;
            }
            if (depth != null)
            {
                foreach (var a in depth.asks)
                {
                    t.Asks.Add(a[0]);
                    t.AskSizes.Add(a[1]);
                }
                foreach (var b in depth.bids)
                {
                    t.Bids.Add(b[0]);
                    t.BidSizes.Add(b[1]);
                }

                if (conf.AggDepth > 0 && conf.AggPrecise > 0)
                {
                    TickHelper.AggregateOrderBook(t, conf.AggPrecise, conf.AggDepth, conf.UseAggPrice);
                }
            }
            t.UpdateUtc = Now.ToUnixTime();
            return t;
        }

        public Tick GetIndex(string sym)
        {
            var names = SymbolToExNames(sym);
			var symbol = names[0];

            var t = new Tick
            {
                Exchange = Name,
                Symbol = symbol,
                Type = Tick.Types.CoinType.Index,
                CreateUtc = Now.ToUnixTime(),
                OrderBookDepth = 5
            };

            try
            {
                var args = new Dictionary<string, object>
                {
                    {"symbol", symbol}
                };
                var ticker = WebUtil.Get<FutureIndex>($"{ApiUri}/future_index.do", args, Conf.TimeoutInMs);
                t.Last = ticker.future_index;
                t.UpdateUtc = Now.ToUnixTime();
            }
            catch (Exception ex)
            {
                Error($"GetIndex error: {ex.Message}");
            }
            return t;
        }

        #region post helper
        private string EncrypPostParams(IEnumerable<KeyValuePair<string, string>> values)
        {
            var sign = string.Join("&", values.Select(kv => kv.Key + "=" + kv.Value).ToArray());
            sign += $"&secret_key={Conf.SecretKey}";

            using (var md5Hash = MD5.Create())
            {
                var data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(sign));
                var sBuilder = new StringBuilder();
                foreach (var e in data)
                {
                    sBuilder.Append(e.ToString("x2"));
                }
                return sBuilder.ToString().ToUpper();
            }
        }

        private T Post<T>(string url, Dictionary<string, string> args)
        {
            args["api_key"] = Conf.AccessKey;
            args["sign"] = EncrypPostParams(args.OrderBy(kvp => kvp.Key));

            try
            {
                using (var client = new WebUtil(Conf.TimeoutInMs))
                {
                    var response = client.UploadValues(url, WebUtil.ToPostParam(args));
                    var json = Encoding.Default.GetString(response);
                    Debug($"[POST]{url}: {json}");
                    return JsonConvert.DeserializeObject<T>(json);
                }
            }
            catch (Exception ex)
            {
                var msg = $"post={url},params={args.ToDebugString()},error={ex.Message}";
                throw new Exception(msg);
            }
        }
        #endregion

        public override Account GetAccount()
        {
            var args = new Dictionary<string, string>();
            try
            {
                var uinfo = Post<FutureUserinfo>($"{ApiUri}/future_userinfo.do", args).info;
                var acct = new Account
                {
                    Exchange = Name,
                    UpdateUtc = Now.ToUnixTime(),

                    Btc = uinfo.btc.account_rights,
                    Ltc = uinfo.ltc.account_rights,
                };
                Account = acct;
                return acct;
            }
            catch (Exception ex)
            {
                Error($"GetAccount error: {ex.Message}");
                return null;
            }
        }

        public override bool SendOrder(Order order)
        {
			var names = SymbolToExNames(order.Symbol);
			var symbol = names[0];
			var contract = names[1];

            var args = new Dictionary<string, string>
			{
				{"symbol", symbol},
                {"contract_type", contract},
                {"price", order.Price.ToString("F2")},
                {"amount", Math.Abs(order.Quantity).ToString("F0")},
                {"match_price", order.Execute == Order.Types.ExecuteType.Limit ? "0" : "1"},
                {"lever_rate", "20"},
            };

            if (order.Purpose == Order.Types.PurposeType.Initial)
            {
                args["type"] = order.Side == Order.Types.SideType.Buy ? "1" : "2";
            }
            else if (order.Purpose == Order.Types.PurposeType.Unwind)
            {
                args["type"] = order.Side == Order.Types.SideType.Buy ? "4" : "3";
            }

            try
            {
                var trade = Post<FutureTrade>($"{ApiUri}/future_trade.do", args);
                if (trade.result)
                {
                    order.Id = trade.order_id;
                }
                Info($"send order: {order.DumpToString()}");
                return trade.result;
            }
            catch (Exception ex)
            {
                Error($"SendOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool CancelOrder(Order order)
        {
			var names = SymbolToExNames(order.Symbol);
			var symbol = names[0];
			var contract = names[1];

            var args = new Dictionary<string, string>
            {
                {"symbol", symbol},
                {"contract_type", contract},
                {"order_id", order.Id.ToString()}
            };

            try
            {
                var trade = Post<FutureCancelOrder>($"{ApiUri}/future_cancel.do", args);
                Info($"cancel order: {order.DumpToString()}");
                return trade.result;
            }
            catch (Exception ex)
            {
                Error($"CancelOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool GetOrderResponse(Order order)
        {
			var names = SymbolToExNames(order.Symbol);
			var symbol = names[0];
			var contract = names[1];

            var args = new Dictionary<string, string>
            {
                {"symbol", symbol},
                {"contract_type", contract},
                {"order_id", order.Id.ToString()}
            };

            try
            {
                var oinfo = Post<FutureOrderInfo>($"{ApiUri}/future_order_info.do", args);
                if (oinfo.result)
                {
                    var rsp = oinfo.orders[0];
                    if (rsp.status == -1)
                        order.State = Order.Types.StateType.Cancel;
                    else if (rsp.status == 0 || rsp.status == 1)
                        order.State = Order.Types.StateType.Live;
                    else if (rsp.status == 2)
                        order.State = Order.Types.StateType.Fill;
                    else if (rsp.status == 4)
                        order.State = Order.Types.StateType.Cancel;
                    else
                        order.State = Order.Types.StateType.Unack;

                    order.AvgPrice = rsp.price_avg;
                    order.Qfill = rsp.deal_amount - order.Qdone;
                    order.Qdone = rsp.deal_amount;
                    order.UpdateUtc = Now.ToUnixTime();
                }
                return oinfo.result;
            }
            catch (Exception ex)
            {
                Error($"GetOrderResponse error: {ex.Message}");
                return false;
            }
        }

        public override bool PostUnitTest()
        {
            var symbol = "btc_usd#T";
            var tick = GetTick(symbol);
            Helper.Assert(tick != null, "unittest: GetTick");

            symbol = "btc_usd";
            var index = GetIndex(symbol);
            Helper.Assert(index != null, "unittest: GetIndex");

            var acct = GetAccount();
            Helper.Assert(acct != null, "unittest: GetAccount");

            //var order = new Order
            //{
            //    Side = Order.Types.SideType.Buy,
            //    Symbol = symbol,
            //    Price = tick.Bids.Last() * (1 - 0.02),
            //    Quantity = 1,
            //    Purpose = Order.Types.PurposeType.Initial,
            //};
            //Helper.Assert(SendOrder(order), "unittest: SendOrder");

            //if (order.Id > 0)
            //{
            //    Thread.Sleep(500);
            //    Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");

            //    Helper.Assert(CancelOrder(order), "unittest: CancelOrder");
            //    Thread.Sleep(500);
            //    Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");
            //}
            return true;
        }
    }
}
