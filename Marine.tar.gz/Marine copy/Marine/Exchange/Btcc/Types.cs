﻿using System.Collections.Generic;

namespace Marine.Exchange.Btcc
{
    // https://www.btcc.com/apidocs/spot-exchange-trade-json-rpc-api

    public class RestError
    {
        public class Error
        {
            public int code;
            public string message;
            public long id;
        }

        public Error error;
    }

    public class RestTicker
    {
        public class Ticker
        {
            public double buy;
            public double high;
            public double last;
            public double low;
            public double sell;
            public double vol;
            public double open;
            public double prev_close;
            public double vwap;
            public long date;
        }

        public Ticker ticker;
    }

    public class RestDepth
    {
        public List<List<double>> asks;
        public List<List<double>> bids;
        public long date;
    }

    public class RestAccountInfo
    {
        public class Result
        {
            public class Profile
            {
                public string username;
                public bool trade_password_enabled;
                public bool otp_enabled;
                public double trade_fee;
                public double trade_fee_cnyltc;
                public double trade_fee_btcltc;
                public double daily_btc_limit;
                public double daily_ltc_limit;
                public string btc_deposit_address;
                public string btc_withdrawal_address;
                public string ltc_deposit_address;
                public string ltc_withdrawal_address;
                public int api_key_permission;
            }
            public class Coin
            {
                public string currency;
                public string symbol;
                public double amount;
                public long amount_integer;
                public int amount_decimal;
            }

            public class Balance
            {
                public Coin btc;
                public Coin ltc;
                public Coin cny;
            }

            public class Frozen
            {
                public Coin btc;
                public Coin ltc;
                public Coin cny;
            }

            public class Loan
            {
                public Coin btc;
                public Coin ltc;
                public Coin cny;
            }

            public Profile profile;
            public Balance balance;
            public Frozen frozen;
            public Loan loan;
        }

        public Result result;
        public long id;
    }
    public class RestTrade
    {
        public long result;
        public long id;
    }

    public class RestCancelOrder
    {
        public bool result;
        public long id;
    }

    public class RestOrderInfo
    {
        public class Result
        {
            public class Order
            {
                public long id;
                public string type;
                public double price;
                public double? avg_price;
                public string currency;
                public double amount;
                public double amount_original;
                public long date;
                public string status;
            }

            public Order order;
        }

        public Result result;
        public long id;
    }
}
