﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Marine.Common;
using Marine.Config;
using Marine.Proto;
using Newtonsoft.Json;

namespace Marine.Exchange.Btcc
{
    public partial class BtccExchange : Exchange
    {
        public const string GetApiUri = @"https://data.btcchina.com/data/";
        public const string PostApiUri = @"https://api.btcc.com/api_trade_v1.php";
        public const string TickerUri = "staticmarket/ticker_{0}_json.js";
        public const string DepthUri = "staticmarket/depth_{0}_{1}.js";

        public BtccExchange(BtccConfig conf) : base(conf)
        {
        }

        public override Tick GetTick(string sym)
        {
            var t = new Tick
            {
                Exchange = Name,
                Symbol = sym,
                CreateUtc = DateTime.Now.ToUnixTime()
            };
            var conf = ConfigDic[sym];

            RestTicker ticker = null;
            RestDepth depth = null;
            try
            {
                if (conf.IsTicker)
                {
                    var url = $"{GetApiUri}/ticker?market={sym}";
                    ticker = WebUtil.Get<RestTicker>(url, null, Conf.TimeoutInMs);
                }
                if (conf.IsDepth)
                {
                    var url = $"{GetApiUri}/orderbook?market={sym}&limit={conf.ReqDepth}";
                    depth = WebUtil.Get<RestDepth>(url, null, Conf.TimeoutInMs);
                }
            }
            catch (Exception ex)
            {
                Error($"GetTick error: {ex.Message}");
            }

            if (ticker == null && depth == null)
                return null;

            if (ticker != null)
            {
                t.ServerUtc = ticker.ticker.date;
                t.Last = ticker.ticker.last;
                t.AccVol = ticker.ticker.vol;
                t.Bid = ticker.ticker.buy;
                t.Ask = ticker.ticker.sell;
            }
            if (depth != null)
            {
                foreach (var a in depth.asks)
                {
                    t.Asks.Add(a[0]);
                    t.AskSizes.Add(a[1]);
                }
                foreach (var b in depth.bids)
                {
                    t.Bids.Add(b[0]);
                    t.BidSizes.Add(b[1]);
                }

                if (conf.AggDepth > 0 && conf.AggPrecise > 0)
                {
                    TickHelper.AggregateOrderBook(t, conf.AggPrecise, conf.AggDepth, conf.UseAggPrice);
                }
            }
            t.UpdateUtc = DateTime.Now.ToUnixTime();
            return t;
        }

        #region post helper
        private string EncrypPostParams(IDictionary<string, string> values)
        {
            var ordered = new List<string> { "tonce", "accesskey", "requestmethod", "id", "method", "params" };
            var orderedList = new List<string>();

            ordered.ForEach(k => orderedList.Add($"{k}={values[k]}"));
            var sign = string.Join("&", orderedList);
            sign = sign.Replace("\"", "").Replace("true", "1").Replace("false", "").Replace("null", "");

            var hmacsha1 = new HMACSHA1(Encoding.ASCII.GetBytes(Conf.SecretKey));
            var data = hmacsha1.ComputeHash(Encoding.ASCII.GetBytes(sign));
            var sBuilder = new StringBuilder();
            foreach (var e in data)
            {
                sBuilder.Append(e.ToString("x2"));
            }
            return sBuilder.ToString();
        }

        private string QuoteStr(object x)
        {
            return $"\"{x}\"";
        }

        private T Post<T>(string method, List<string> params_=null)
        {
            var tonce = (long) DateTime.UtcNow.ToUnixTimeMs()*1000;
            var args = new Dictionary<string, string>
            {
                {"tonce", tonce.ToString()},
                {"accesskey", Conf.AccessKey},
                {"requestmethod", "post"},
                {"id", tonce.ToString()},
                {"method", method}
            };
            args["params"] = params_ == null ? "" : string.Join(",", params_);

            var sign = EncrypPostParams(args);
            var b64 = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{Conf.AccessKey}:{sign}"));
            var postJson = "{\"method\": \"" + args["method"] + "\", \"params\": [" + args["params"] + "], \"id\": " + args["id"] + "}";

            try
            {
                string json;
                using (var client = new WebUtil(Conf.TimeoutInMs))
                {
                    client.Headers.Set("Content-Type", "application/json-rpc");
                    client.Headers.Set("Authorization", $"Basic {b64}");
                    client.Headers.Set("Json-Rpc-Tonce", tonce.ToString());
                    json = client.UploadString(PostApiUri, postJson);
                    Debug($"[POST]{method}: {json}");
                }

                if (json.Contains("code"))
                {
                    var obj = JsonConvert.DeserializeObject<RestError>(json);
                    throw new Exception(obj.error.message);
                }
                else
                {
                    var obj = JsonConvert.DeserializeObject<T>(json);
                    return obj;
                }
            }
            catch (Exception ex)
            {
                var msg = $"post={method},params={args.ToDebugString()},error={ex.Message}";
                throw new Exception(msg);
            }
        }
        #endregion

        public override Account GetAccount()
        {
            try
            {
                var uinfo = Post<RestAccountInfo>("getAccountInfo").result;
                var acct = new Account
                {
                    Exchange = Name,
                    UpdateUtc = Now.ToUnixTime(),

                    Btc = uinfo.balance.btc.amount,
                    Ltc = uinfo.balance.ltc.amount,
                    Cny = uinfo.balance.cny.amount,

                    BorrowBtc = uinfo.loan.btc.amount,
                    BorrowLtc = 0,
                    BorrowCny = uinfo.loan.cny.amount,

                    FreezeBtc = uinfo.frozen.btc.amount,
                    FreezeLtc = uinfo.frozen.ltc.amount,
                    FreezeCny = uinfo.frozen.cny.amount
                };
                Account = acct;
                return acct;
            }
            catch (Exception ex)
            {
                Error($"GetAccount error: {ex.Message}");
                return null;
            }
        }

        public override bool SendOrder(Order order)
        {
			var args = new List<string>
			{
                order.Price > 0 ? QuoteStr(order.Price.ToString("F2")) : "null",
                QuoteStr(Math.Abs(order.Quantity).ToString("F4")),
                QuoteStr(order.Symbol)
            };

            try
            {
                var method = order.Side == Order.Types.SideType.Buy ? "buyOrder2" : "sellOrder2";
                var trade = Post<RestTrade>(method, args);
                if (trade.result > 0)
                {
                    order.Id = trade.result;
                    Info($"send order: {order.DumpToString()}");
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                Error($"SendOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool CancelOrder(Order order)
        {
            var args = new List<string>
            {
                order.Id.ToString()
            };

            try
            {
                var trade = Post<RestCancelOrder>("cancelOrder", args);
                Info($"cancel order: {order.DumpToString()}");
                return trade.result;
            }
            catch (Exception ex)
            {
                Error($"CancelOrder error: {ex.Message}");
                return false;
            }
        }

        public override bool GetOrderResponse(Order order)
        {
            var args = new List<string>
            {
                order.Id.ToString(),
                QuoteStr(order.Symbol),
                "true"
            };

            try
            {
                var rsp = Post<RestOrderInfo>("getOrder", args).result.order;
				if (rsp.status == "open")
					order.State = Order.Types.StateType.Live;
				else if (rsp.status == "closed")
				{
					if (rsp.avg_price != null && rsp.avg_price > 0)
						order.State = Order.Types.StateType.Fill;
					else
						order.State = Order.Types.StateType.Live;
				}
                else if (rsp.status == "cancelled")
                    order.State = Order.Types.StateType.Cancel;
                else
                    order.State = Order.Types.StateType.Unack;

                order.AvgPrice = rsp.avg_price ?? 0;
                order.Qfill = (order.Quantity - order.Qdone)- rsp.amount;
                order.Qdone += order.Qfill;
                order.UpdateUtc = DateTime.Now.ToUnixTime();
                return true;
            }
            catch (Exception ex)
            {
                Error($"GetOrderResponse error: {ex.Message}");
                return false;
            }
        }

        public override bool PostUnitTest()
        {
            var symbol = "btccny";
            var tick = GetTick(symbol);
            Helper.Assert(tick != null, "unittest: GetTick");

            var acct = GetAccount();
            Helper.Assert(acct != null, "unittest: GetAccount");

            var order = new Order
            {
                Side = Order.Types.SideType.Buy,
                Symbol = symbol,
                Price = tick.Bids.Last() * (1 - 0.02),
                Quantity = 0.01
            };
            Helper.Assert(SendOrder(order), "unittest: SendOrder[limit]");

            if (order.Id > 0)
            {
                Thread.Sleep(500);
                Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");

                Helper.Assert(CancelOrder(order), "unittest: CancelOrder");
                Thread.Sleep(500);
                Helper.Assert(GetOrderResponse(order), "unittest: GetOrderResponse");
            }
            return true;
        }
    }
}
