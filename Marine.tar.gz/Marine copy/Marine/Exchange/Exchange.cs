﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Google.Protobuf;
using Marine.Common;
using Marine.Config;
using Marine.Exchange.Btcc;
using Marine.Exchange.Huobi;
using Marine.Exchange.Okcoin;
using Marine.Proto;

namespace Marine.Exchange
{
    public delegate void OnTickHandler(Tick t);

    public class Exchange
    {
        public ExchangeConfig Conf;
        public Dictionary<string, CoinConfig> ConfigDic;

        public string Name => Conf.Name;
        public DateTime Now => App.Instance.Now;
        public event OnTickHandler OnTickEvent;

        public Exchange(ExchangeConfig conf)
        {
            Conf = conf;
            ConfigDic = conf.CoinConfigs.ToDictionary(e => e.Symbol, e => e);
            OnTickEvent += OnTick;
        }

        public void SubscribeMarket(string sym)
        {
            long lastUpdate = 0;
            while (!IsExit())
            {
                Thread.Sleep(200);
                var utc = (int)DateTime.Now.ToSodSeconds();
                if (utc % Conf.IntervalInSec != 0 || utc - lastUpdate < Conf.IntervalInSec)
                {
                    continue;
                }

                lastUpdate = utc;
                try
                {
                    var t = GetTick(sym);
                    if (t == null)
                        continue;

                    OnTickEvent(t);
                    Loggers.Tick.Info(TickHelper.ToCsv(t));

                    var topic = $"{Name}:Tick";
                    var msg = Convert.ToBase64String(t.ToByteArray());
                    App.Instance.Publish(topic, msg);
                }
                catch (Exception ex)
                {
                    Error($"{sym}: {ex.Message}, {ex.StackTrace}");
                }
            }
        }

        public virtual bool IsExit()
        {
            if (Now > App.Instance.Conf.ExitTime)
            {
                Info("time exit");
                return true;
            }
            return false;
        }

        public virtual void Start()
        {
            var threads = new List<Thread>();
            foreach (var symbol in ConfigDic.Keys)
            {
                var thread = new Thread(() =>
                {
                    SubscribeMarket(symbol);
                });
                Info($"new thread #={thread.ManagedThreadId}, subscribe market: {symbol}");
                threads.Add(thread);
            }

            threads.ForEach(t => t.Start());
            threads.ForEach(t => t.Join());
        }

        #region virtual interfaces

        public virtual void OnTick(Tick t)
        {
            CurTick[t.Symbol] = t;
            if (!HistTicks.ContainsKey(t.Symbol))
            {
                HistTicks[t.Symbol] = new List<Tick>();
            }
            HistTicks[t.Symbol].Add(t);
        }

        public virtual bool PostUnitTest()
        {
            return true;
        }

        public virtual Account GetAccount()
        {
            return Account;
        }

        public virtual Tick GetTick(string sym)
        {
            return null;
        }

        public virtual bool SendOrder(Order order)
        {
            return true;
        }

        public virtual bool CancelOrder(Order order)
        {
            return true;
        }

        public virtual bool GetOrderResponse(Order order)
        {
            return true;
        }

        #endregion

        #region trading stuff

        public Dictionary<string, Tick> CurTick = new Dictionary<string, Tick>();
        public Dictionary<string, List<Tick>> HistTicks = new Dictionary<string, List<Tick>>();

        public Account Account;

        #endregion

        #region common utils
        public void Debug(string msg)
        {
            Loggers.Exec.Debug($"{Name,-10}|{msg}");
        }

        public void Info(string msg)
        {
            Loggers.Exec.Info($"{Name,-10}|{msg}");
        }

        public void Warn(string msg)
        {
            Loggers.Exec.Warn($"{Name,-10}|{msg}");
        }

        public void Error(string msg)
        {
            Loggers.Exec.Error($"{Name,-10}|{msg}");
        }

        public static Exchange CreateExchange(ExchangeConfig conf, bool isSim=false)
        {
            if (isSim)
            {
                return new MockExchange(conf);
            }

            if (conf is OkcoinConfig)
            {
				//return new OkcoinExchange((OkcoinConfig)conf);
				return new OkcoinFuture((OkcoinConfig)conf);
            }
            if (conf is HuobiConfig)
            {
                return new HoubiExchange((HuobiConfig)conf);
            }
            if (conf is BtccConfig)
            {
                return new BtccExchange((BtccConfig)conf);
            }
            return null;
        }
        #endregion
    }
}
