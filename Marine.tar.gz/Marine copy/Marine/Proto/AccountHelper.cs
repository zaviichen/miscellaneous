﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Marine.Common;

namespace Marine.Proto
{
    public class AccountHelper
    {
               
    }
}
