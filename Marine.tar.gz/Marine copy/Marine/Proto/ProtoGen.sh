﻿
/Users/zhchen/Downloads/protoc-3.0.0-osx-x86_64/bin/protoc -I=. --csharp_out=. ./Model.proto