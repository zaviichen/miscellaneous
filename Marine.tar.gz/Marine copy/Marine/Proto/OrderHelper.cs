﻿using System.Collections.Generic;
using Marine.Common;

namespace Marine.Proto
{
    public static class OrderHelper
    {
        public static string CsvHeader()
        {
            return "Exchange,Symbol,Id,Application,Price,Side,Quantity,UpdateUtc,State,AvgPrice,TradePrice,Qdone,Qfill,Purpose,Comment";
        }

        public static string ToCsv(Order o)
        {
            var items = new List<object>
            {
                o.Exchange,
                o.Symbol,
                o.Id,
                o.Application,
                o.Price,
                o.Side,
                o.Quantity,
                o.UpdateUtc.ToTimeStr(),
                o.State,
                o.AvgPrice.ToString("F2"),
                o.TradePrice.ToString("F2"),
                o.Qdone,
                o.Qfill,
                o.Purpose,
                o.Comment,
            };
            return string.Join(",", items);
        }

        public static bool IsBuy(this Order o)
        {
            return o.Side == Order.Types.SideType.Buy;
        }

        public static bool IsLive(this Order o)
        {
            return o.State == Order.Types.StateType.Live;
        }

        public static double Qopen(this Order o)
        {
            return o.Quantity - o.Qdone;
        }

        public static bool IsOpen(this Order o)
        {
            return o.State == Order.Types.StateType.Init ||
                   o.State == Order.Types.StateType.Live ||
                   o.State == Order.Types.StateType.Unack;
        }

        public static bool IsClose(this Order o)
        {
            return !IsOpen(o);
        }
    }
}
