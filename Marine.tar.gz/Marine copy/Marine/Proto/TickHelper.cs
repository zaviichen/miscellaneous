﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Marine.Common;

namespace Marine.Proto
{
	public static class TickHelper
	{
		internal class AggItem
		{
			internal double Boundary;
			internal double AvgPrice;
			internal double Qty;
		}

		private static List<AggItem> InternalAggregate(string sym, double[] prices, double[] sizes, double precise)
		{
			if (prices.Length != sizes.Length)
			{
				throw new Exception($"{sym}: #prices({prices.Length}) != #sizes({sizes.Length})");
			}

			var factor = 1 / precise;
			var dic = new Dictionary<double, List<double[]>>();
			for (var i = 0; i < prices.Length; i++)
			{
				var lower = Math.Floor(prices[i] * factor) / factor;
				if (!dic.ContainsKey(lower))
				{
					dic[lower] = new List<double[]>();
				}
				dic[lower].Add(new[] { prices[i], sizes[i] });
			}

			var ob = new List<AggItem>();
			foreach (var k in dic.Keys)
			{
				var v = dic[k];
				var item = new AggItem
				{
					Boundary = k,
					Qty = Math.Round(v.Select(e => e[1]).Sum(), 4)
				};

				var val = v.Select(e => e[0] * e[1]).Sum();
				item.AvgPrice = Math.Round(val / item.Qty, 2);
				ob.Add(item);
			}
			return ob;
		}

		public static void AggregateOrderBook(Tick t, double precise, int depth, bool aggprc)
		{
			t.OrderBookDepth = depth;

			var asks = InternalAggregate(t.Symbol, t.Asks.ToArray(), t.AskSizes.ToArray(), precise)
				.OrderBy(x => x.Boundary).Take(depth).ToList();

			var bids = InternalAggregate(t.Symbol, t.Bids.ToArray(), t.BidSizes.ToArray(), precise)
				.OrderByDescending(x => x.Boundary).Take(depth).ToList();

			t.Asks.Clear();
			t.AskSizes.Clear();
			t.Bids.Clear();
			t.BidSizes.Clear();
			for (var i = 0; i < depth; i++)
			{
				t.Asks.Add(0);
				t.AskSizes.Add(0);
				t.Bids.Add(0);
				t.BidSizes.Add(0);
			}

			for (var i = 0; i < asks.Count; i++)
			{
				t.Asks[i] = aggprc ? asks[i].AvgPrice : asks[i].Boundary;
				t.AskSizes[i] = asks[i].Qty;
			}
			for (var i = 0; i < bids.Count; i++)
			{
				t.Bids[i] = aggprc ? bids[i].AvgPrice : bids[i].Boundary;
				t.BidSizes[i] = bids[i].Qty;
			}
		}

		public static string ToCsv(Tick t)
		{
			var items = new List<object>
			{
				t.CreateUtc.ToTimeStr(),
				t.Exchange,
				t.Symbol,
				t.Last,
				t.AccVol,
				t.Bid,
				t.Ask
			};
			for (var i = 0; i < t.OrderBookDepth; i++)
			{
				items.Add(t.Asks[i]);
				items.Add(t.AskSizes[i]);
				items.Add(t.Bids[i]);
				items.Add(t.BidSizes[i]);
			}
			items.Add(t.UpdateUtc.ToTimeStr());
			items.Add(t.ServerUtc);
			return string.Join(",", items);
		}

		public static Tick FromCsv(string csv)
		{
			var e = csv.Split(',');
			var t = new Tick
			{
				CreateUtc = e[0].FromTimeStr(),
				Exchange = e[1],
				Symbol = e[2],
				Last = Convert.ToDouble(e[3]),
				AccVol = Convert.ToDouble(e[4]),
				Bid = Convert.ToDouble(e[5]),
				Ask = Convert.ToDouble(e[6]),
				UpdateUtc = e[e.Length - 2].FromTimeStr(),
				ServerUtc = Convert.ToDouble(e[e.Length - 1])
			};
			t.OrderBookDepth = (e.Length - 9) / 4;
			var offset = 7;
			for (var i = 0; i < t.OrderBookDepth; i++)
			{
				var j = offset + i * 4;
				t.Asks.Add(Convert.ToDouble(e[j]));
				t.AskSizes.Add(Convert.ToDouble(e[j + 1]));
				t.Bids.Add(Convert.ToDouble(e[j + 2]));
				t.BidSizes.Add(Convert.ToDouble(e[j + 3]));
			}
			return t;
		}

		public static string CsvHeader(int depth = 5)
		{
			var header = "time,exch,symbol,last,accvol,bid,ask,{0},update,sutc";
			var q = "";
			for (var i = 0; i < depth; i++)
			{
				q += $"ap{i},as{i},bp{i},bs{i},";
			}
			return string.Format(header, q.Remove(q.Length - 1));
		}

		public static string PrintOrderBook(Tick t, int depth = 10)
		{
			var sb = new StringBuilder();
			sb.Append($"Tick: {t.Exchange}#{t.Symbol},t={t.UpdateUtc.ToTimeStr()}\n");
			for (var i = 0; i < Math.Min(t.OrderBookDepth, depth); i++)
			{
				sb.Append($"\t{t.Bids[i],-10}({t.BidSizes[i],-10}) | {t.Asks[i],-10}({t.AskSizes[i],-10})\n");
			}
			return sb.ToString().Trim();
		}

		public static string DisplayName(this Tick t)
		{
			return $"{t.Exchange}#{t.Symbol}";
		}
	}
}
