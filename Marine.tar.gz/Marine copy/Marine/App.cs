﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Marine.Common;
using Marine.Config;
using Marine.Proto;
using Marine.Trade;
using NetMQ;
using NetMQ.Sockets;
using Marine.Trade.Arbitrage;

namespace Marine
{
    public class App
    {
        private static readonly App _instance = new App();
        private PublisherSocket _publisher;
        private readonly object _mutex = new object();

        public static App Instance => _instance;

        private DateTime _now;

        public DateTime Now
        {
            get { return IsSim ? _now : DateTime.Now; }
            set { _now = Date + value.TimeOfDay; }
        }

        public DateTime Date = DateTime.Today;

        public bool IsSim => Conf.SimConfig != null && Conf.SimConfig.SimMode;
        public bool IsTrade => !IsSim;
        public AppConfig Conf;

        public Dictionary<string, Exchange.Exchange> Exchanges;
        public List<Strategy> Strategies;

        public void Init(AppConfig conf)
        {
            Conf = conf;
            Exchanges = new Dictionary<string, Exchange.Exchange>();
            Strategies = new List<Strategy>();

            foreach (var exconf in Conf.ExchangeConfigs)
            {
                var ex = Exchange.Exchange.CreateExchange(exconf, IsSim);
                if (ex != null)
                {
                    Exchanges[ex.Name] = ex;
                    Loggers.Exec.Info($"create exchange - {ex.Name}");
                }
                else
                {
                    Loggers.Exec.Error($"fail to create exchange - {exconf.Name}");
                }
            }

            foreach (var sconf in Conf.StrategyConfigs)
            {
                var strat = Strategy.CreateStrategy(sconf);
                if (strat != null)
                {
                    Strategies.Add(strat);
                    Loggers.Exec.Info($"create strategy - {strat.Name}");
                }
                else
                {
                    Loggers.Exec.Error($"fail to create strategy - ${sconf.Name}");
                }
            }

            try
            {
				if (conf.ZmqConfig != null)
				{
					Loggers.Exec.Info($"bind publisher: {conf.ZmqConfig.PubUri}");
					_publisher = new PublisherSocket();
					_publisher.Bind(conf.ZmqConfig.PubUri);
				}
				else 
				{
					Loggers.Exec.Info("not bind zeromq");
				}
            }
            catch (Exception ex)
            {
                _publisher = null;
                Loggers.Exec.Error($"bind publisher exception: {ex.Message}");
            }

            Loggers.Tick.Info(TickHelper.CsvHeader());
            Loggers.Order.Info(OrderHelper.CsvHeader());
			Loggers.Oppor.Info(Opportunity.CsvHeader());
        }

        public void Start()
        {
            if (IsSim)
            {
                Loggers.Exec.Info("use Sim mode.");
                SimStart();
                return;
            }

            if (Conf.SimConfig != null && Conf.SimConfig.UnitTest)
            {
                Loggers.Exec.Info("unittest starts.");
                Exchanges.Values.ToList().ForEach(ex => ex.PostUnitTest());
                return;
            }

            var threads = new List<Thread>();
            foreach (var exch in Exchanges.Values)
            {
                var thread = new Thread(() => exch.Start());
                Loggers.Exec.Info($"new thread #={thread.ManagedThreadId}, exchange start: {exch.Name}");
                threads.Add(thread);
            }

            foreach (var strat in Strategies)
            {
                var thread = new Thread(() => strat.Start());
                Loggers.Exec.Info($"new thread #={thread.ManagedThreadId}, strategy start: {strat.Name}");
                threads.Add(thread);
            }
            
            threads.ForEach(t => t.Start());
            threads.ForEach(t => t.Join());

            Strategies.ForEach(s => s.Stop());
            Loggers.Exec.Info("application exit");
        }

        public void SimStart()
        {
            var file = Conf.SimConfig.TickFile;
            Date = Helper.GetDateFromFile(file);

            foreach (var line in File.ReadAllLines(file))
            {
                Tick t;
                try
                {
                    t = TickHelper.FromCsv(line.Trim());
                    Now = t.UpdateUtc.FromUnixTime();
                    if (!Exchanges.ContainsKey(t.Exchange))
                        continue;
                }
                catch (Exception)
                {
                    continue;
                }

                var ex = Exchanges[t.Exchange];
                ex.OnTick(t);

                foreach (var strat in Strategies)
                {
                    strat.OnTick(t);
                }
            }
        }

        public void Publish(string topic, string msg)
        {
            if (_publisher == null || !Monitor.TryEnter(_mutex))
                return;
            try
            {
                _publisher.SendFrame($"{topic}|{msg}");
            }
            catch (Exception ex)
            {
                Loggers.Exec.Error($"publish error: {ex.Message}");
            }
            finally
            {
                Monitor.Exit(_mutex);
            }
        }
    }
}
