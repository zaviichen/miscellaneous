﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using Newtonsoft.Json;

namespace Marine.Common
{
    public class WebUtil : WebClient
    {
        public int TimeoutInMs;

        public WebUtil(int timeout)
        {
            TimeoutInMs = timeout;
        }

        protected override WebRequest GetWebRequest(Uri address)
        {
            var wr = base.GetWebRequest(address);
            if (wr != null)
                wr.Timeout = TimeoutInMs;
            return wr;
        }

        public static T Get<T>(string url, Dictionary<string, object> args, int timeout)
        {
            if (args != null)
            {
                var param = args.Select(e => $"{e.Key}={e.Value}").Aggregate((e, next) => e + "&" + next);
                url = $"{url}?{param}";
            }
            Loggers.Exec.Trace(url);

            try
            {
                using (var client = new WebUtil(timeout))
                {        
                    var json = client.DownloadString(url);
                    return JsonConvert.DeserializeObject<T>(json);
                }
            }
            catch (Exception ex)
            {
                var msg = $"get={url},error={ex.Message}";
                throw new Exception(msg);
            }
        }

        public static NameValueCollection ToPostParam(IDictionary<string, string> dic)
        {
            var values = new NameValueCollection();
            foreach (var key in dic.Keys)
            {
                values[key] = dic[key];
            }
            return values;
        }
    }
}
