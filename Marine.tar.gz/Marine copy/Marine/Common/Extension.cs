﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Marine.Common
{
    public static class Extension
    {
        public static DateTime FromUnixTime(this double unixTime)
        {
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            return epoch.AddSeconds(unixTime);
        }

        public static double ToUnixTime(this DateTime date)
        {
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            return (date - epoch).TotalSeconds;
        }

        public static double ToUnixTimeMs(this DateTime date)
        {
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            return (date - epoch).TotalMilliseconds;
        }

        public static double ToSodSeconds(this DateTime date)
        {
            return date.TimeOfDay.TotalSeconds;
        }

        public static string ToDebugString<TKey, TValue>(this IDictionary<TKey, TValue> dictionary)
        {
            return "{" + string.Join(",", dictionary.Select(kv => kv.Key + "=" + kv.Value).ToArray()) + "}";
        }

        public static string DumpToString(this object obj, char delim = '\n')
        {
            var str = "";
            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(obj))
            {
                var name = descriptor.Name;
                var value = descriptor.GetValue(obj);
                str += $"{name}={value},";
            }
            return str;
        }

        public static string ToTimeStr(this double unixTime)
        {
            return unixTime.FromUnixTime().ToString("HH:mm:ss.fff");
        }

        public static double FromTimeStr(this string str)
        {
            var dt = DateTime.ParseExact(str, "HH:mm:ss.fff", null);
            return dt.ToUnixTime();
        }

        public static double ToBps(this double val)
        {
            return Math.Round(val*10000, 1);
        }

        public static double Rnd2(this double val)
        {
            return Math.Round(val, 2);
        }
    }
}
