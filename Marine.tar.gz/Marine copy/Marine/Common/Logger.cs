﻿using NLog;

namespace Marine.Common
{
    public static class Loggers
    {
        private static Logger _exec;
        private static Logger _tick;
        private static Logger _order;
		private static Logger _opportuniry;

        public static Logger Exec
        {
            get
            {
                _exec = _exec ?? LogManager.GetLogger("exec");
                return _exec;
            }
        }

        public static Logger Tick
        {
            get
            {
                _tick = _tick ?? LogManager.GetLogger("tick");
                return _tick;
            }
        }

        public static Logger Order
        {
            get
            {
                _order = _order ?? LogManager.GetLogger("order");
                return _order;
            }
        }

		public static Logger Oppor
		{
			get
			{
				_opportuniry = _opportuniry ?? LogManager.GetLogger("opportunity");
				return _opportuniry;
			}
		}
    }
}
