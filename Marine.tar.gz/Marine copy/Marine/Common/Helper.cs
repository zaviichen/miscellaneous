﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marine.Common
{
    public class Helper
    {
        public static DateTime GetDateFromFile(string file)
        {
            var filename = Path.GetFileName(file);
            if (filename != null)
            {
                var e = filename.Split('.');
                var dateStr = e[e.Length - 2];
                return DateTime.ParseExact(dateStr, "yyyy-MM-dd", null);
            }
            throw new Exception($"file can't be parsed to date(yyyy-MM-dd): {file}");
        }

        public static void Assert(bool condition, string message)
        {
            if (condition)
            {
                Console.WriteLine($"[Success] {message}");
            }
            else
            {
                Console.WriteLine($"[Fail] {message}");
            }
        }

		public static T EnumParse<T>(string str)
		{
			return (T)Enum.Parse(typeof(T), str);
		}
    }
}
