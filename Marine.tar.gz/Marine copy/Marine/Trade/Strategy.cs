﻿using Marine.Common;
using Marine.Config;
using Marine.Proto;
using Marine.Trade.Arbitrage;

namespace Marine.Trade
{
    public class Strategy
    {
        public StrategyConfig BaseConfig { get; set; }
        public string Name => BaseConfig.Name;
        public bool Enable { get; set; }

        public Strategy(StrategyConfig conf)
        {
            BaseConfig = conf;
            Enable = conf.Enable;
        }

        public virtual void Start()
        {
            Info("strategy started");
        }

        public virtual void Stop()
        {
            Info("strategy stopped");
        }

        public virtual void OnTick(Tick tick)
        { }

        public virtual void OnTimer(double time)
        { }

        public virtual void OnOrder(Order order)
        { }

        public static Strategy CreateStrategy(StrategyConfig conf)
        {
            if (conf is StatArbConfig)
            {
                return new StatArb((StatArbConfig) conf);
            }
            return null;
        }

        public void Debug(string msg)
        {
            Loggers.Exec.Debug($"{Name,-10}|{msg}");
        }
        public void Info(string msg)
        {
            Loggers.Exec.Info($"{Name,-10}|{msg}");
        }

        public void Warn(string msg)
        {
            Loggers.Exec.Warn($"{Name,-10}|{msg}");
        }

        public void Error(string msg)
        {
            Loggers.Exec.Error($"{Name,-10}|{msg}");
        }
    }

}
