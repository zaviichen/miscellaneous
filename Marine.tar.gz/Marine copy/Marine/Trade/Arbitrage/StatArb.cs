﻿using System;
using System.Collections.Generic;
using System.Linq;
using Marine.Common;
using Marine.Config;
using Marine.Proto;
using NLog;

namespace Marine.Trade.Arbitrage
{
    public class StatArb : Strategy
    {
		public Logger OpLog = Loggers.Oppor;

        public Exchange.Exchange Ex1 { get; set; }
        public Exchange.Exchange Ex2 { get; set; }
		public string Symbol1 => Conf.Exchange1.Symbol;
		public string Symbol2 => Conf.Exchange2.Symbol;
		public Tick Tick1 { get; set; }
		public Tick Tick2 { get; set; }
        public StatArbConfig Conf { get; set; }
        public DateTime Now => App.Instance.Now;

        public List<Opportunity> Opportunities = new List<Opportunity>();

        public Opportunity OpenOpportunity
        {
            get
            {
                if (Opportunities.Count == 0)
                    return null;
                var last = Opportunities.Last();
                return !last.IsClose() ? last : null;
            }
        }

        public StatArb(StatArbConfig conf) : base(conf)
        {
            Conf = conf;
        }

        public override void Start()
        {
            try
            {
                Ex1 = App.Instance.Exchanges[Conf.Exchange1.Exchange];
                Ex2 = App.Instance.Exchanges[Conf.Exchange2.Exchange];
                Ex1.OnTickEvent += OnTick;
                Ex2.OnTickEvent += OnTick;

                Ex1.GetAccount();
                Ex2.GetAccount();
                Info($"{Ex1.Name} account: {Ex1.Account.DumpToString()}");
                Info($"{Ex2.Name} account: {Ex2.Account.DumpToString()}");
            }
            catch (Exception ex)
            {
                Error($"ArbEngine init failed: exchange/tick not found: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }

        public override void Stop()
        {
            var totalEsti = 0.0;
            var totalReal = 0.0;
            foreach (var op in Opportunities)
            {
                totalEsti += op.EstiPnl;
                totalReal += op.RealPnl;
                Info($"oppor-pnl #{op.Id}: {op.EstiPnl.Rnd2()} (Est.) ~ {op.RealPnl.Rnd2()} (Real.)");
            }
            Info($"total-pnl: {totalEsti.Rnd2()} (Est.) ~ {totalReal.Rnd2()} (Real.)");
        }
        
        public Exchange.Exchange FindExchange(string exch)
        {
            if (Ex1.Name == exch) return Ex1;
            if (Ex2.Name == exch) return Ex2;
            return null;
        }
        
        public bool IsTickValid(Tick t)
        {
            if (t == null)
                return false;
            if (t.UpdateUtc.Equals(0))
                return false;
            if (t.Asks.Count == 0 || t.Bids.Count == 0 || t.AskSizes.Count == 0 || t.BidSizes.Count == 0)
                return false;
            if (t.Asks[0].Equals(0) || t.Bids[0].Equals(0) || t.AskSizes[0].Equals(0) || t.BidSizes[0].Equals(0))
                return false;
            return true;
        }

        public bool IsReady()
        {
            if (!IsTickValid(Tick1) || !IsTickValid(Tick2))
            {
                Info($"{Ex1.Name}/{Ex2.Name}'s tick not valid");
                return false;
            }

            var ex1T = Tick1.UpdateUtc;
            var ex2T = Tick2.UpdateUtc;
            var now = Now.ToUnixTime();
            if (now - Math.Min(ex1T, ex2T) > 1.0)
            {
                return false;
            }
            
            return true;
        }

        public bool CheckEntry(Tick tickL, Tick tickS, ref Opportunity op)
        {
            var prcL = tickL.Asks[0];
            var prcS = tickS.Bids[0];

            var spread = (prcS - prcL)/prcL;
            if (spread >= Conf.EntrySpread)
            {
                op.Long.PriceIn = prcL;
                op.Short.PriceIn = prcS;
                op.SpreadIn = spread;

                op.Long.FeePct = FindExchange(tickL.Exchange).Conf.Fee;
                op.Short.FeePct = FindExchange(tickS.Exchange).Conf.Fee;
                return true;
            }

            return false;
        }

        public bool CheckExit(Tick tickL, Tick tickS, ref Opportunity op)
        {
            if (op.Type != Opportunity.OpporType.Entry)
                return false;

            if (op.Long.Exchange != tickL.Exchange || op.Short.Exchange != tickS.Exchange)
                return false;

            var prcL = tickL.Bids[0];
            var prcS = tickS.Asks[0];

            var spread = (prcS - prcL)/prcL;
            var profit = op.SpreadIn - spread - op.Cost;

            op.Long.PriceOut = prcL;
            op.Short.PriceOut = prcS;
            op.SpreadOut = spread;

            if (profit >= Conf.Rewards)
            {
                op.ExitCode = Opportunity.ExitCodeType.TakeProfit;
                return true;
            }

            var holds = (Now - op.EntryTime).TotalSeconds;
            if (holds > Conf.MaxHoldingPeriod)
            {
                op.ExitCode = Opportunity.ExitCodeType.HoldExpire;
                return true;
            }

            if (Now > App.Instance.Conf.ExitTime.AddMinutes(-1))
            {
                op.ExitCode = Opportunity.ExitCodeType.CloseExit;
                Enable = false;
                return true;
            }

            op.Long.PriceOut = 0;
            op.Short.PriceOut = 0;
            op.SpreadOut = 0;
            return false;
        }

        public double[] GetLimitPrice(Tick tick, double size, bool buy, bool exit)
        {
            var prices = buy ? tick.Asks : tick.Bids;
            var sizes = buy ? tick.AskSizes : tick.BidSizes;
            var accQty = 0.0;
            var avgPx = 0.0;
            var i = 0;
            var enough = false;

            for (i = 0; i < prices.Count; i++)
            {
                avgPx = (avgPx * accQty + prices[i] * sizes[i]) / (accQty + sizes[i]);
                accQty += sizes[i];
                if (accQty * Conf.LiquidityRatio > size)
                {
                    enough = true;
                    break;
                }
            }

            var side = buy ? "Ask" : "Bid";
            if (enough)
            {
                if (i > 0)
                {
					Info($"{tick.DisplayName()} not enough until {side} orderbook #{i}: avgpx={avgPx:F2},target={size}");
                }
            }
            else
            {
                var newsize = accQty * Conf.LiquidityRatio;
                var type = exit ? "Exit" : "Entry";
				Info($"{tick.DisplayName()} {type} not enough in {side} orderbook: target={size}=>{newsize}");
                size = newsize;
            }

            i = Math.Min(i, prices.Count-1);
            var price = prices[i];

			var conf = Conf.Exchange1.Symbol == tick.Symbol ? Conf.Exchange1 : Conf.Exchange2;
			if (conf.AggressiveSpread > 0)
			{
				price += price * (buy ? 1 : -1) * conf.AggressiveSpread;
				price = Math.Round(price, 2);
			}
			return new [] { price, size };
        }

        public Opportunity FindOpportunity(Tick tickL, Tick tickS)
        {
            if (OpenOpportunity == null)
            {
                var op = new Opportunity(Name, tickL.Exchange, tickL.Symbol, tickS.Exchange, tickS.Symbol)
                {
                    Id = Opportunities.Count
                };

                if (CheckEntry(tickL, tickS, ref op))
                {
                    Info($"Entry opportunity found - {tickL.DisplayName()} / {tickS.DisplayName()}");
                    if (Conf.UnitSize <= 0)
                    {
                        Info($"no size specified. calculate size using balance ratio={Conf.BalanceRatio}.");
                        throw new Exception("not implement");
                    }

                    var resBuy = GetLimitPrice(tickL, Conf.UnitSize, buy: true, exit: false);
                    var prcBuy = resBuy[0];
                    var qtyBuy = resBuy[1];

                    var resSel = GetLimitPrice(tickS, Conf.UnitSize, buy:false, exit: false);
                    var prcSel = resSel[0];
                    var qtySel = resSel[1];

                    var qty = Math.Min(qtyBuy, qtySel);

                    if (prcBuy > 0 && prcSel > 0 && qty > 0)
                    {
                        op.Long.Size = qty;
                        op.Short.Size = -1 * qty;
                        op.EntryTime = Now;
                        op.Type = Opportunity.OpporType.Entry;
                        Opportunities.Add(op);

                        var msg = $"entry={op.SpreadIn.ToBps()}";
                        var buyOrder = CreateOrder(op.Long.Exchange, true, prcBuy, qty, msg);
                        var selOrder = CreateOrder(op.Short.Exchange, false, prcSel, qty, msg);
                        SendPairOrders(op, buyOrder, selOrder);

                        return op;
                    }
                    else
                    {
                        Error($"opportunity found but error in orderbook: buy-{qtyBuy}@{prcBuy}, sell-{qtySel}@{prcSel}");
                    }
                }
            }
            else
            {
                var op = OpenOpportunity;
                if (CheckExit(tickL, tickS, ref op))
                {
                    Info($"Exit opportunity found - {tickL.DisplayName()} / {tickS.DisplayName()}");

                    var resSel = GetLimitPrice(tickL, Math.Abs(op.Long.Size), buy:false, exit: true);
                    var prcSel = resSel[0];
                    var qtySel = resSel[1];

                    var resBuy = GetLimitPrice(tickS, Math.Abs(op.Short.Size), buy:true, exit: true);
                    var prcBuy = resBuy[0];
                    var qtyBuy = resBuy[1];

                    if (prcBuy > 0 && prcSel > 0 && qtyBuy > 0 && qtySel > 0)
                    {
                        op.ExitTime = Now;
                        op.Type = Opportunity.OpporType.Exit;
                        var msg = $"{op.ExitCode}={op.SpreadOut.ToBps()}";

                        var selOrder = CreateOrder(op.Long.Exchange, false, prcSel, op.Long.Size, msg);
                        var buyOrder = CreateOrder(op.Short.Exchange, true, prcBuy, op.Short.Size, msg);
                        selOrder.Purpose = Order.Types.PurposeType.Unwind;
                        buyOrder.Purpose = Order.Types.PurposeType.Unwind;
                        SendPairOrders(op, selOrder, buyOrder);

                        return op;
                    }
                    else
                    {
                        Error($"opportunity found but error in orderbook: buy-{qtyBuy}@{prcBuy}, sell-{qtySel}@{prcSel}");
                    }
                }
            }
            return null;
        }

        public void FindOpportunity()
        {
            var op1 = FindOpportunity(Tick1, Tick2);
            if (op1 != null)
            {
                Info(op1.ToString());
                Info($"Long:  {TickHelper.PrintOrderBook(Tick1)}");
                Info($"Short: {TickHelper.PrintOrderBook(Tick2)}");
            }

            var op2 = FindOpportunity(Tick2, Tick1);
            if (op2 != null)
            {
                Info(op2.ToString());
                Info($"Long:  {TickHelper.PrintOrderBook(Tick2)}");
                Info($"Short: {TickHelper.PrintOrderBook(Tick1)}");
            }
        }

        public void SendPairOrders(Opportunity op, Order buyOrder, Order selOrder)
        {
            var exL = FindExchange(op.Long.Exchange);
            var exS = FindExchange(op.Short.Exchange);

            var buySmart = new SmartOrder(buyOrder, exL, this)
            {
                ExpireTime = Conf.OrderExpireSec
            };

            var selSmart = new SmartOrder(selOrder, exS, this)
            {
                ExpireTime = Conf.OrderExpireSec
            };

            if (buySmart.Send())
            {
                Info($"{exL.Name} send buy order success: #{buyOrder.Id}");
                if (selSmart.Send())
                {
                    Info($"{exS.Name} send sell order success: #{selOrder.Id}");
                }
                else
                {
                    Error($"{exS.Name} send sell order failed");
                    Enable = false;
                    Error("strategy disabled");
                    return;
                }
            }
            else
            {
                Error($"{exL.Name} send buy order failed");
                Enable = false;
                Error("strategy disabled");
                return;
            }
            
            op.Long.Orders[buyOrder.Id] = buyOrder;
            op.Short.Orders[selOrder.Id] = selOrder;
        }

        public Order CreateOrder(string ex, bool isbuy, double prc, double qty, string cmt = "")
        {
            var sym = ex == Ex1.Name ? Symbol1 : Symbol2;
            var o = new Order
            {
                Exchange = ex,
                Symbol = sym,
                Application = Name,
                Price = prc,
                Side = isbuy ? Order.Types.SideType.Buy : Order.Types.SideType.Sell,
                Quantity = Math.Abs(qty),
                Purpose = Order.Types.PurposeType.Initial,
                UpdateUtc = Now.ToUnixTime(),
                State = Order.Types.StateType.Init,
                Execute = Order.Types.ExecuteType.Limit,
                Comment = cmt
            };
            return o;
        }

        public override void OnTick(Tick tick)
        {
            if (!Enable)
                return;

            if (tick.Symbol != Symbol1 && tick.Symbol != Symbol2)
                return;

			if (tick.Symbol == Symbol1)
				Tick1 = tick;
			if (tick.Symbol == Symbol2)
				Tick2 = tick;
			
			lock(this)
			{
				if (IsReady())
				{
					FindOpportunity();
				}
			}
        }

        public override void OnOrder(Order order)
        {
            if (order.Application != Name)
                return;

            if (order.Symbol != Symbol1 && order.Symbol != Symbol2)
                return;

            if (Opportunities.Count == 0)
                return;

            Info($"(OnOrder) {order.DumpToString()}");
            
            var op = Opportunities.Last();
            var leg = op.Long.Symbol == order.Symbol ? op.Long : op.Short;

            if (op.Type == Opportunity.OpporType.Entry)
            {
				if (order.State == Order.Types.StateType.Cancel)
				{
					Warn("Init order get cancelled, disable stratgy");
					Enable = false;
				}

                if (order.State == Order.Types.StateType.Live ||
                    order.State == Order.Types.StateType.Fill)
                {
                    leg.Size = (order.IsBuy() ? 1 : -1) * order.Qdone;
                }
            }
            else
            {
                if (op.IsClose())
                {
                    OpLog.Info(op.ToCsv());
                }
            }
        }
    }
}
