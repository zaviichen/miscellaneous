﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Marine.Common;
using Marine.Proto;

namespace Marine.Trade.Arbitrage
{
    public class Opportunity
    {
        public enum OpporType
        {
            None, Entry, Exit, ReEntry
        }

        public enum ExitCodeType
        {
            None,
            TakeProfit,
            StopLoss,
            HoldExpire,
            CloseExit
        }

        public class OpporLeg
        {
            public string Exchange;
            public string Symbol;
            public double PriceIn;
            public double PriceOut;
            public double FeePct;
            public double Size;

            public double Profit => PriceOut <= 0 ? 0 : (PriceOut - PriceIn) / PriceIn * Math.Sign(Size) - 2.0 * FeePct;
            public double EstiPnl => PriceOut <= 0 ? 0 : (PriceOut - PriceIn)*Size;

            public Dictionary<long, Order> Orders = new Dictionary<long, Order>();

            public double RealPnl()
            {
                var sum = 0.0;
                var fee = 0.0;
                foreach (var o in Orders.Values)
                {
                    if (o.State == Order.Types.StateType.Fill)
                    {
                        var cash = Math.Abs(o.Qdone*o.AvgPrice);
                        fee += cash*FeePct;
                        sum += (o.IsBuy() ? -1 : 1)*cash;
                    }
                    else
                    {
                        Loggers.Exec.Warn("find unfilled order - set real pnl to 0");
                        return 0;
                    }
                }
                return sum - fee;
            }

            public override string ToString()
            {
                return
                    $"Exch={Exchange},PriceIn={PriceIn:F2},PriceOut={PriceOut:F2},Size={Size},Profit(bps)={Profit.ToBps()}";
            }
        }

        public Opportunity(string strat, string ex1, string sym1, string ex2, string sym2)
        {
            Strategy = strat;
            Long.Exchange = ex1;
            Long.Symbol = sym1;
            Short.Exchange = ex2;
            Short.Symbol = sym2;
        }

        public string Strategy;
        public int Id;
        public OpporLeg Long = new OpporLeg();
        public OpporLeg Short = new OpporLeg();
        public double SpreadIn = 0;
        public double SpreadOut = 0;
        public DateTime EntryTime;
        public DateTime ExitTime;
        public OpporType Type = OpporType.None;
        public ExitCodeType ExitCode;

        public double Cost => 2 * (Long.FeePct + Short.FeePct);
        public double Exposure => Long.PriceIn * Long.Size;
        public double HoldSeconds => Math.Max(0, (ExitTime - EntryTime).TotalSeconds);
        public double RealPnl => Long.RealPnl() + Short.RealPnl();
        public double EstiPnl => Long.EstiPnl + Short.EstiPnl;

        public bool IsClose()
        {
            if (Type == OpporType.Exit)
            {
                var lcls = Long.Orders.All(p => p.Value.IsClose());
                var scls = Short.Orders.All(p => p.Value.IsClose());
                return lcls && scls;
            }
            return false;
        }

        #region log
        public override string ToString()
        {
            var sb = new StringBuilder($"(Opportunity) {Strategy}#{Id} ");
            if (Type == OpporType.Exit)
            {
                sb.Append($"{Type} {ExitCode}\n");
            }
            else
            {
                sb.Append($"{Type}\n");
            }
            sb.Append($"\tTime:        Entry={EntryTime:HH:mm:ss.fff},Exit={ExitTime:HH:mm:ss.fff},Hold={HoldSeconds}\n");
            sb.Append($"\tSpread(bps): In={SpreadIn.ToBps()},Out={SpreadOut.ToBps()}\n");
            sb.Append($"\tExposure:    {Exposure}\n");
            sb.Append($"\tLong:        {Long}\n");
            sb.Append($"\tShort:       {Short}\n");
            return sb.ToString().Trim();
        }

        public static string CsvHeader()
        {
            return
                "Strategy,Id,Type,ExitCode,Entry,Exit,Hold,SpreadIn,SpreadOut," +
                "ExLong,SymLong,PriceInLong,PriceOutLong,SizeLong,ProfitLong," +
                "ExShort,SymShort,PriceInShort,PriceOutShort,SizeShort,ProfitShort," +
                "Cost,Profit,EstiPnl,RealPnl";
        }

        public string ToCsv()
        {
            var items = new List<object>
            {
                Strategy,
                Id,
                Type,
                ExitCode,
                EntryTime.ToString("HH:mm:ss.fff"),
                ExitTime.ToString("HH:mm:ss.fff"),
                HoldSeconds,
                SpreadIn.ToBps(),
                SpreadOut.ToBps(),
                Long.Exchange,
                Long.Symbol,
                Long.PriceIn,
                Long.PriceOut,
                Long.Size,
                Long.Profit.ToBps(),
                Short.Exchange,
                Short.Symbol,
                Short.PriceIn,
                Short.PriceOut,
                Short.Size,
                Short.Profit.ToBps(),
                Cost.ToBps(),
                (Long.Profit + Short.Profit).ToBps(),
                EstiPnl.Rnd2(),
                RealPnl.Rnd2()
            };
            return string.Join(",", items);
        }
        #endregion
    }
}
