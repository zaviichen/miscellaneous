﻿using System;
using System.Threading;
using Marine.Common;
using Marine.Proto;

namespace Marine.Trade.Arbitrage
{
    public delegate void OnOrderHandler(Order o);

    public class SmartOrder
    {
        public event OnOrderHandler OnOrderEvent;
        public Order Order { get; set; }
        public Exchange.Exchange Exchange { get; set; }
        public Strategy Strategy { get; set; }
        public bool IsActive { get; set; }
        public double SendUtc { get; set; }

        public int LoopInMs = 200;
        public double ExpireTime = 5.0;

        private Thread thread;
        private Order.Types.StateType prevState = Order.Types.StateType.Init;
        private double prevQdone;
        private int numCancel = 0;

        public SmartOrder(Order order, Exchange.Exchange exch, Strategy strat)
        {
            Order = order;
            if (Order.State != Order.Types.StateType.Init)
            {
                throw new Exception($"SmartOrder constructor failed: {Order.Symbol}'s order state must be Init");
            }
            Exchange = exch;
            Strategy = strat;
            OnOrderEvent += strat.OnOrder;
        }

        public void CancelOnExpiry()
        {
            if (!IsExpired())
                return;
            
            Info($"cancel live order due to time expired: #{Order.Id}");
            if (numCancel == 0)
            {
                Exchange.CancelOrder(Order);
                numCancel += 1;
            }
        }

        public void MonitorState()
        {
            while (Order.IsOpen())
            {
                lock (Order)
                {
                    Exchange.GetOrderResponse(Order);
                    if (Order.State != prevState)
                    {
                        Info($"state change: {prevState} => {Order.State}");
                        prevState = Order.State;
                        OnOrderEvent(Order);
                        if (!Order.IsOpen()) break;
                    }
                    else
                    {
                        if (Order.State == Order.Types.StateType.Live && prevQdone < Order.Qdone)
                        {
                            Info($"Live state with new fills: {prevQdone} => {Order.Qdone}");
                            prevQdone = Order.Qdone;
                            OnOrderEvent(Order);
                        }
                    }

                    CancelOnExpiry();
                }
                Thread.Sleep(LoopInMs);
            }
            IsActive = false;
            Loggers.Order.Info(OrderHelper.ToCsv(Order));
            Info("thread exit");
        }

        public bool IsExpired()
        {
            if (SendUtc > 0)
            {
                return (App.Instance.Now.ToUnixTime() - SendUtc) > ExpireTime;
            }
            return false;
        }

        public bool Send()
        {
            if (!Exchange.SendOrder(Order))
            {
                IsActive = false;
                Info("send order failed.");
                return false;
            }

            IsActive = true;
            SendUtc = Order.UpdateUtc;
            if (App.Instance.IsTrade)
            {
                thread = new Thread(MonitorState);
                Info($"new thread #={thread.ManagedThreadId}");
                thread.Start();
            }
            return true;
        }

        private void Info(string msg)
        {
            Strategy.Info($"SOrder|{msg}");
        }
    }
}
