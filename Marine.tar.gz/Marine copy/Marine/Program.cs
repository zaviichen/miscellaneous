﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Marine.Common;
using Marine.Config;

namespace Marine
{
    class Program
    {
        static void Main(string[] args)
        {
            AppConfig conf;
            if (args.Length > 0)
            {
                conf = AppConfig.LoadConfig(args[0]);
            }
            else
            {
                conf = AppConfig.LoadConfig(@"C:\Users\zchen15\workspace\Terran\Marine\marine.config");
            }

            App.Instance.Init(conf);
            App.Instance.Start();
        }
    }
}
