﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Marine.Config
{
    public class CoinConfig
    {
        [XmlAttribute]
        public string Symbol;

        [XmlAttribute]
        public bool IsTicker;

        [XmlAttribute]
        public bool IsDepth;

        [XmlAttribute]
        public int ReqDepth;

        [XmlAttribute]
        public double AggPrecise;

        [XmlAttribute]
        public int AggDepth;

        [XmlAttribute]
        public bool UseAggPrice;
    }

    public class ExchangeConfig
    {
        [XmlAttribute]
        public string Name;

        [XmlAttribute]
        public int TimeoutInMs;

        [XmlAttribute]
        public int IntervalInSec;

        [XmlAttribute]
        public string AccessKey;

        [XmlAttribute]
        public string SecretKey;

        [XmlAttribute]
        public string DataFile;

        [XmlAttribute]
        public double Fee;

        [XmlElement("Coin")]
        public List<CoinConfig> CoinConfigs;

        public static ExchangeConfig LoadConfigStr(string content)
        {
            ExchangeConfig conf = null;
            try
            {
                var serializer = new XmlSerializer(typeof(ExchangeConfig));
                using (var reader = XElement.Parse(content).CreateReader())
                {
                    if (reader.ReadToDescendant("ExchangeConfig"))
                    {
                        conf = (ExchangeConfig)serializer.Deserialize(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return conf;
        }

        public static ExchangeConfig LoadConfig(string file)
        {
            return LoadConfigStr(File.ReadAllText(file));
        }
    }

    public class OkcoinConfig : ExchangeConfig
    { }

    public class HuobiConfig : ExchangeConfig
    { }

    public class BtccConfig : ExchangeConfig
    { }
}
