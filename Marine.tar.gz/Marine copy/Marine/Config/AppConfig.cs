﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace Marine.Config
{
    public class ZmqConfig
    {
        [XmlAttribute]
        public string PubUri;
    }

    public class SimConfig
    {
        [XmlAttribute]
        public bool SimMode;

        [XmlAttribute]
        public bool UnitTest;

        [XmlAttribute]
        public string TickFile;
    }

    public class AppConfig
    {
        [XmlIgnore]
        public DateTime ExitTime { get; set; }

        [XmlAttribute("ExitTime")]
        public string ExitTimeStr
        {
            get { return ExitTime.ToString("HH:mm:ss"); }
            set { ExitTime = DateTime.Parse(value); }
        }

        [XmlElement("ZeroMQ")]
        public ZmqConfig ZmqConfig;

        [XmlElement("Sim")]
        public SimConfig SimConfig;

        [XmlArray("Exchanges")]
        [XmlArrayItem("OkcoinExchange", typeof(OkcoinConfig))]
        [XmlArrayItem("HuobiExchange", typeof(HuobiConfig))]
        [XmlArrayItem("BtccExchange", typeof(BtccConfig))]
        public List<ExchangeConfig> ExchangeConfigs;

        [XmlArray("Strategies")]
        [XmlArrayItem("StatArbConfig", typeof(StatArbConfig))]
        public List<StrategyConfig> StrategyConfigs;

        public static AppConfig LoadConfig(string file)
        {
            var serializer = new XmlSerializer(typeof(AppConfig));
            using (var reader = new StreamReader(file))
            {
                var conf = (AppConfig)serializer.Deserialize(reader);
                return conf;
            }
        }
    }
}
