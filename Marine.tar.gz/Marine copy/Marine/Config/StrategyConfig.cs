﻿using System;
using System.Xml.Serialization;

namespace Marine.Config
{
    public class StrategyConfig
    {
        [XmlAttribute]
        public string Name;

        [XmlAttribute]
        public bool Enable = true;
    }

	public class ArbElementConfig
	{
		[XmlAttribute]
		public string Exchange;

		[XmlAttribute]
		public string Symbol;

		[XmlAttribute]
		public bool UseMarketOrder = false;

		[XmlAttribute]
		public double AggressiveSpread = 0;
    }

    public class StatArbConfig : StrategyConfig
    {
		[XmlElement]
        public ArbElementConfig Exchange1;

		[XmlElement]
		public ArbElementConfig Exchange2;

        [XmlAttribute]
        public double EntrySpread;

        [XmlAttribute]
        public double Rewards;

        [XmlAttribute]
        public double LiquidityRatio = 1;

        [XmlAttribute]
        public int RetryLimit = 1;

        [XmlAttribute]
        public double UnitSize;

        [XmlAttribute]
        public double BalanceRatio;

        [XmlAttribute]
        public int MaxHoldingPeriod = 86400;

        [XmlAttribute]
        public double OrderExpireSec = 5.0;
    }
}
