from setuptools import setup, find_packages
import pycryptoex

setup(name='pycryptoex',
      version=pycryptoex.__version__,
      description='Python library for crypto-currency exchanges',
      url='',
      author='Zhihui Chen',
      author_email='btcarb.smg@outlook.com',
      license='MIT',
      packages=find_packages(),
      zip_safe=False,
      install_requires=[],
      python_requires='>=3.6')
