from pycryptoex.okcoin.okcoin import OKCoin
from pycryptoex.common.logger import exlog as log


class OKSpot(OKCoin):
    def __init__(self, params):
        super().__init__(params)
        self.name = params.get('name', 'OKSpot')
        self.base_url = params.get('base_url', '')
        log.info(f'OKSpot init: {params}')

    def ticker(self, symbol):
        return self._get("ticker.do", {'symbol': symbol})

    def depth(self, symbol, size=5, merge=None):
        params = {'symbol': symbol, 'size': size}
        if merge:
            params['merge'] = merge
        return self._get("depth.do", params)

    def trades(self, symbol):
        return self._get("trades.do", {'symbol': symbol})


class OKCoinCn(OKSpot):
    DefaultBaseUrl = "https://www.okcoin.cn/api/v1"

    def __init__(self, params):
        super(OKCoinCn, self).__init__(params)
        self.name = params.get('name', 'OKCoinCn')
        self.base_url = params.get('base_url', OKCoinCn.DefaultBaseUrl)


class OKCoinCom(OKSpot):
    DefaultBaseUrl = "https://www.okcoin.com/api/v1"

    def __init__(self, params):
        super(OKCoinCom, self).__init__(params)
        self.name = params.get('name', 'OKCoinCom')
        self.base_url = params.get('base_url', OKCoinCom.DefaultBaseUrl)
