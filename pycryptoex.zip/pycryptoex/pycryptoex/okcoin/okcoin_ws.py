import websocket
import json
import zlib
import time
import threading
from datetime import datetime
from pycryptoex.common.logger import exlog as log


class OKCoinWebSocket(object):
    def __init__(self, params):
        self.params = params
        self.ws_url = params.get('wsurl', '')
        self.binary = params.get('binary', False)
        self.daemon = params.get('daemon', True)
        self.channels = params.get('channels', [])
        self.ws = None
        self.exited = False
        self.callbacks = {}
        self.ping_time = None

    def __del__(self):
        self.exit()

    def connect(self):
        log.info(f"connecting to {self.ws_url}")
        self.__connect(self.ws_url)

    def add_channel(self, chan):
        x = {
            'event': 'addChannel',
            'channel': chan,
            'binary': self.binary
        }
        msg = json.dumps(x)
        log.info(msg)
        self.ws.send(msg)

    def add_callback(self, type, cb):
        if type not in self.callbacks:
            self.callbacks[type] = []
        self.callbacks[type].append(cb)
        log.info(f"add callback: {type} => {cb}")

    @property
    def connected(self):
        return self.ws and self.ws.sock and self.ws.sock.connected

    def heartbeat(self):
        while not self.connected:
            time.sleep(1)
        while self.connected:
            log.info("ping...")
            self.ws.send("{'event':'ping'}")
            self.ping_time = datetime.now()
            time.sleep(10)

    def error(self, err):
        log.error(err)
        self.exit()

    def exit(self):
        self.exited = True
        self.ws.close()

    def __connect(self, wsurl):
        self.ws = websocket.WebSocketApp(
            wsurl,
            on_message=self.__on_message,
            on_open=self.__on_open,
            on_close=self.__on_close,
            on_error=self.__on_error
        )

        t = threading.Thread(name="heartbeat", target=self.heartbeat)
        t.daemon = True
        t.start()

        log.info("starting websocket run_forever...")
        try:
            self.ws.run_forever(ping_interval=10, ping_timeout=8)
        except websocket.WebSocketTimeoutException:
            log.warning("timeout, reconnecting...")
            self.connect()
        except Exception as ex:
            log.error(f"unknown exception: {ex}")
            self.exit()

    def __on_open(self, ws):
        log.info("ws on_open")
        for chan in self.channels:
            self.add_channel(chan)
        [cb() for cb in self.callbacks.get('on_open', [])]

    def __on_close(self, ws):
        log.info('ws on_close')
        [cb() for cb in self.callbacks.get('on_close', [])]
        self.exit()

    def __on_error(self, ws, error):
        if self.exited:
            return
        if isinstance(error, websocket.WebSocketTimeoutException):
            log.warning("timeout, reconnecting...")
            # time.sleep(20)
            self.connect()
            return
        self.error(error)
        [cb(error) for cb in self.callbacks.get('on_error', [])]

    def __on_message(self, ws, msg):
        is_str = isinstance(msg, str)
        is_byte = isinstance(msg, bytes)
        if is_str or is_byte:
            if is_byte:
                dex = zlib.decompressobj(-zlib.MAX_WBITS)
                x = dex.decompress(msg)
                x += dex.flush()
                dat = x.decode()
            else:
                dat = json.loads(msg)
            log.debug(dat)
            [cb(dat) for cb in self.callbacks.get('on_message', [])]
        else:
            self.error(msg)


if __name__ == "__main__":
    params = {
        'wsurl': 'wss://real.okex.com:10440/websocket/okexapi',
        'binary': False,
        'daemon': False,
        'channels': [
            'ok_sub_futureusd_btc_ticker_this_week',
            'ok_sub_futureusd_ltc_depth_this_week_20'
        ]
    }
    # params = {
    #     'wsurl': 'wss://real.okcoin.com:10440/websocket/okcoinapi',
    #     'binary': False,
    #     'daemon': False,
    #     'channels': [
    #         'ok_sub_spotusd_btc_ticker',
    #     ]
    # }
    ws = OKCoinWebSocket(params)
    ws.connect()
