from pycryptoex.okcoin.okcoin import OKCoin, encryption
from pycryptoex.common.logger import exlog as log


class OKEx(OKCoin):
    DefaultBaseUrl = "https://www.okex.com/api/v1"

    class OrderTypes:
        OpenLong = '1'
        OpenShort = '2'
        CloseLong = '3'
        CloseShort = '4'

        @classmethod
        def to_str(cls, x):
            x = str(x)
            if x == '1':
                return 'OpenLong'
            elif x == '2':
                return 'OpenShort'
            elif x == '3':
                return 'CloseLong'
            elif x == '4':
                return 'CloseShort'
            else:
                return f"Unknown {x}"

    def __init__(self, params):
        super().__init__(params)
        self.name = params.get('name', 'OKEx')
        self.base_url = params.get('base_url', OKEx.DefaultBaseUrl)
        log.info(f'OKEx init: {params}')

    def future_ticker(self, symbol, contract):
        return self._get("future_ticker.do", {'symbol': symbol, 'contract_type': contract})

    def future_depth(self, symbol, contract, size=5, merge=None):
        params = {'symbol': symbol, 'contract_type': contract, 'size': size}
        if merge:
            params['merge'] = merge
        return self._get("future_depth.do", params)

    def future_trades(self, symbol, contract):
        return self._get("future_trades.do", {'symbol': symbol, 'contract_type': contract})

    def future_index(self, symbol):
        return self._get("future_index.do", {'symbol': symbol})

    def exchange_rate(self):
        return self._get("exchange_rate.do", {})

    def future_estimated_price(self, symbol):
        return self._get("future_estimated_price.do", {'symbol': symbol})

    def future_hold_amount(self, symbol, contract):
        return self._get("future_hold_amount.do", {'symbol': symbol, 'contract_type': contract})

    def future_price_limit(self, symbol, contract):
        return self._get("future_price_limit.do", {'symbol': symbol, 'contract_type': contract})

    def future_kline(self, symbol, contract, kline='1day', size=60):
        raise NotImplementedError()

    def future_userinfo(self):
        params = {'api_key': self.access_key}
        params['sign'] = encryption(params, self.secret_key)
        return self._post("future_userinfo.do", params)

    def future_position(self, symbol, contract):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'contract_type': contract
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("future_position.do", params)

    def future_trade(self, symbol, contract, order_type, price, amount, match_price=0, leverage=20):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'contract_type': contract,
            'type': str(order_type),
            'price': str(price),
            'amount': str(amount),
            'match_price': str(match_price),
            'lever_rate': str(leverage)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("future_trade.do", params)

    def future_cancel(self, symbol, contract, order_ids):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'contract_type': contract,
            'order_id': ','.join(str(o) for o in order_ids)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("future_cancel.do", params)

    def future_order_info(self, symbol, contract, status, order_id="-1"):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'contract_type': contract,
            'status': str(status),
            'order_id': str(order_id),
            'current_page': '0',
            'page_length': '50'
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("future_order_info.do", params)

    def future_orders_info(self, symbol, contract, order_ids):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'contract_type': contract,
            'order_id': ','.join(str(o) for o in order_ids)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("future_orders_info.do", params)
