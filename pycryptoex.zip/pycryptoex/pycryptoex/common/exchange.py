
class Exchange(object):
    def __init__(self, params):
        self.params = params
        self.name = ''
        self.base_url = ''
        self.enable = params.get('enable', True)
        self.access_key = params.get('access_key', '')
        self.secret_key = params.get('secret_key', '')
        self.timeout = params.get('timeout', 3)
        self.websocket = None
        self.session = None

    def get_ticker(self):
        pass

    def get_orderbook(self):
        pass

    def get_trade(self):
        pass