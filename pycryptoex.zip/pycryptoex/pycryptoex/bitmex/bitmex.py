import requests
import base64
import uuid
import json

from pycryptoex.bitmex.auth import APIKeyAuthWithExpires
from pycryptoex.common.exchange import Exchange
from pycryptoex.common.logger import exlog as log


class BitMEX(Exchange):
    DefaultBaseUrl = "https://www.bitmex.com/api/v1"

    def __init__(self, params):
        super().__init__(params)
        self.name = params.get('name', 'BitMEX')
        self.base_url = params.get('base_url', BitMEX.DefaultBaseUrl)
        self.order_prefix = params.get('order_prefix', 'my_bitmex_')
        self.session = requests.session()
        self.session.headers.update({'content-type': 'application/json'})
        self.session.headers.update({'accept': 'application/json'})
        log.info(f'BitMEX init: {params}')

    def _curl(self, url, params, verb='GET', query=None):
        auth = APIKeyAuthWithExpires(self.access_key, self.secret_key)
        try:
            req = requests.Request(verb, f'{self.base_url}/{url}', json=params, auth=auth, params=query)
            req = self.session.prepare_request(req)
            r = self.session.send(req, timeout=self.timeout)
            r.raise_for_status()
            return r.json()
        except Exception as ex:
            log.error(ex)
            return None

    def quote(self, symbol, count=1, reverse=True):
        params = {'symbol': symbol, 'count': count, 'reverse': reverse}
        return self._curl("quote", params, verb="GET")

    def orderbook(self, symbol, depth=5):
        params = {'symbol': symbol, 'depth': depth}
        return self._curl("orderBook/L2", params, verb="GET")

    def trade(self, symbol, count=10, reverse=True):
        params = {'symbol': symbol, 'count': count, 'reverse': reverse}
        return self._curl("trade", params, verb="GET")

    def instrument(self, symbol=None, start=0, count=500, reverse=True):
        # This returns all instruments and indices, including those that have settled or are unlisted
        params = {'start': start, 'count': count, 'reverse': reverse}
        if symbol:
            params['symbol'] = symbol
        return self._curl("instrument", params, verb="GET")

    def instrument_active(self):
        # Get all active instruments and instruments that have expired in <24hrs
        return self._curl("instrument/active", {}, verb="GET")

    def instrument_indices(self):
        # Get all price indices
        return self._curl("instrument/indices", {}, verb="GET")

    def instrument_active_and_indices(self):
        # Gets all active instruments and all indices. This is a join of the result of /indices and /active
        return self._curl("instrument/activeAndIndices", {}, verb="GET")

    def position(self):
        return self._curl("position", {}, verb="GET")

    def order(self, symbol=None, start=0, count=500, reverse=True):
        params = {'start': start, 'count': count, 'reverse': reverse}
        if symbol:
            params['symbol'] = symbol
        return self._curl("order", params, verb="GET")

    def open_orders(self, symbol):
        orders = self._curl(
            "order", params={}, verb="GET",
            query={'filter': json.dumps({'ordStatus.isTerminated': False, 'symbol': symbol})})
        return [o for o in orders if str(o['clOrdID']).startswith(self.order_prefix)]

    def place_order(self, symbol, prc, qty):
        clordid = self.order_prefix + base64.b64encode(uuid.uuid4().bytes).decode('utf-8').rstrip('=\n')
        params = {
            'symbol': symbol,
            'orderQty': qty,
            'price': prc,
            'clOrdID': clordid
        }
        return self._curl("order", params=params, verb="POST")

    def cancel_order(self, order_id):
        params = {'orderID': order_id}
        return self._curl("order", params, verb="DELETE")
