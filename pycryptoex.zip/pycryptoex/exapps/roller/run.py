import sys
import json
from exapps.roller.rollbot import RollBot

config = json.load(open(sys.argv[1]))
bot = RollBot(**config)
bot.start()
