import time
import atexit
import signal
import sys
import collections
import numpy as np
from multiprocessing.pool import ThreadPool
from exapps.roller.logger import get_logger
from exapps.roller.future import Future
from exapps.roller.roll_ws import RollWebSocket
from pycryptoex.okcoin import OKEx


class RollBot(object):
    def __init__(self, **kwargs):
        self.params = kwargs
        self.ex = OKEx(kwargs['exchange'])
        self.symbol = kwargs['symbol']
        self.near = Future(self.ex, self.symbol, kwargs['near_fut'])
        self.far = Future(self.ex, self.symbol, kwargs['far_fut'])
        self.bid_offset = kwargs['bid_offset']
        self.ask_offset = kwargs['ask_offset']
        self.offset_gain = kwargs['offset_gain']
        self.ref_bid = 0
        self.ref_ask = 0
        self.qty = kwargs.get('fixed_amount', 1)
        self.open_delta_limit = kwargs.get('open_delta_limit', 3)
        self.log = get_logger(f"{self.symbol}-{self.near.contract}-{self.far.contract}", kwargs['log_dir'])
        self.active = True
        self.use_websocket = kwargs.get('use_websocket', False)
        self.far_ws = None
        self.near_ws = None
        self.roll_spreads = collections.deque(maxlen=200)
        self.cancel_fails = 0
        self.open_orders = []
        atexit.register(self.exit)
        signal.signal(signal.SIGTERM, self.exit)

    def exit(self):
        try:
            self.cancel_open_orders(self.near.contract)
            self.cancel_open_orders(self.far.contract)
        except Exception as ex:
            self.log.error(f"unable to cancel all live orders: {ex}")
        # try:
        #     self.close_positions(self.near)
        #     self.close_positions(self.far)
        # except Exception as ex:
        #     self.log.error(f"unable to close all positions: {ex}")
        self.active = False
        self.log.info("strategy exit")
        sys.exit()

    @property
    def roll_buy_spread(self):
        # long far short near
        if not self.ready:
            return 0
        return (self.far.ask - self.near.bid) / ((self.far.ask + self.near.bid) / 2)

    @property
    def roll_sell_spread(self):
        # short far long near
        if not self.ready:
            return 0
        return (self.far.bid - self.near.ask) / ((self.far.bid + self.near.ask) / 2)

    @property
    def roll_mid_spread(self):
        return round((self.roll_buy_spread + self.roll_sell_spread) / 2, 4)

    @property
    def avg_roll_spread(self):
        if len(self.roll_spreads) > 0:
            return np.mean(self.roll_spreads)
        return 0

    @property
    def ready(self):
        return self.far.ready and self.near.ready

    def get_position(self, contract):
        rsp = None
        try:
            rsp = self.ex.future_position(self.symbol, contract)
            p = rsp['holding'][0]
            return int(p['buy_amount']), -1 * int(p['sell_amount'])
        except Exception as ex:
            self.log.error("get_position error: ", rsp)
            raise ex

    def get_delta(self, contract):
        long, short = self.get_position(contract)
        return long + short

    def get_open_orders(self, contract):
        x = self.ex.future_order_info(self.symbol, contract, "1")
        orders = []
        if x is not None:
            for e in x['orders']:
                self.log.info(f'\topen: {e}')
                orders.append(e)
        return orders

    def get_orders(self, contract, order_ids):
        orders = {'open': [], 'fill': [], 'cancel': []}
        if len(order_ids) > 0:
            x = self.ex.future_orders_info(self.symbol, contract, order_ids)
            for e in x['orders']:
                status = int(e['status'])
                if status == 0:
                    orders['open'].append(e)
                    self.log.info(f"\topen: {e}")
                elif status == 1 or status == 2:
                    orders['fill'].append(e)
                    self.log.info(f"\tfill: {e}")
                elif status == 4 or status == -1:
                    orders['cancel'].append(e)
                    self.log.info(f"\tcancel: {e}")
                else:
                    self.log.warn(f"\tunknown order status: {status}, {e}")
        return orders

    def order_side(self, order):
        type_ = int(order['type'])
        return 'B' if type_ == 1 or type_ == 4 else 'S'

    def order_qopen(self, order):
        side = self.order_side(order)
        sign = 1 if side == 'B' else -1
        qty = int(order['amount'])
        qdone = int(order['deal_amount'])
        qopen = qty - qdone
        return sign * qopen

    def place_order(self, contract, type, price, amount):
        type_str = OKEx.OrderTypes.to_str(type)
        self.log.info(f"place order: {self.symbol}, {contract}, {type_str} {amount} @ {price}")
        rsp = self.ex.future_trade(self.symbol, contract, type, price, amount)
        try:
            order_id = int(rsp['order_id'])
            self.log.info(f"place order: success, order_id={order_id}")
            return order_id
        except Exception as ex:
            self.log.error(f"place order: {rsp}, {ex}")
            return -1

    def cancel_orders(self, contract, order_ids):
        self.log.info(f"cancel order: {contract}, {','.join(str(o) for o in order_ids)}")
        while len(order_ids) > 0:
            oids = order_ids[:3]
            order_ids = order_ids[3:]
            rsp = self.ex.future_cancel(self.symbol, contract, oids)
            self.log.info(f"cancel order response: {rsp}")
            if rsp is None:
                self.cancel_fails += 1

    def cancel_open_orders(self, contract):
        orders = self.get_open_orders(contract)
        order_ids = [o['order_id'] for o in orders]
        if len(order_ids) > 0:
            self.cancel_orders(contract, order_ids)

    def close_positions(self, fut, cross=True):
        long, short = self.get_position(fut.contract)
        if long > 0:
            px = fut.bid if cross else fut.ask
            self.place_order(fut.contract, OKEx.OrderTypes.CloseLong, px, abs(long))
        if short < 0:
            px = fut.ask if cross else fut.bid
            self.place_order(fut.contract, OKEx.OrderTypes.CloseShort, px, abs(short))

    def quote(self):
        contract = self.near.contract
        qty = self.qty

        orders = self.get_open_orders(contract)
        self.open_orders = orders
        qopens = [self.order_qopen(o) for o in orders]
        open_long = sum(q for q in qopens if q > 0)
        open_shrt = sum(q for q in qopens if q < 0)

        long, short = self.get_position(contract)
        delta = long + short + open_long + open_shrt
        self.log.info(f"quote|delta={delta}, near={long}({open_long})/{short}({open_shrt})")

        self.ref_ask = self.far.ask
        self.ref_bid = self.far.bid
        bid_offset = self.bid_offset * ((1 + self.offset_gain) ** abs(delta))
        ask_offset = self.ask_offset * ((1 + self.offset_gain) ** abs(delta))
        quote_ask = round(self.ref_bid * (1 - self.avg_roll_spread + bid_offset), 3)
        quote_bid = round(self.ref_ask * (1 - self.avg_roll_spread - ask_offset), 3)
        self.log.info(f"quote|roll_sell={self.ref_bid}->{quote_ask}, roll_buy={self.ref_ask}->{quote_bid}")
        if len(self.roll_spreads) < 10:
            self.log.info(f"not enough roll_mid_spread to calculate the average base shift, skip quoting")
            return

        init_buy = True
        init_sel = True
        limit = self.open_delta_limit
        if delta >= limit or open_long >= limit:
            self.log.info(f"quote|delta {delta} or open_long {open_long} >= limit {limit}, skip quoting buy")
            init_buy = False
        if delta <= -limit or open_shrt <= -limit:
            self.log.info(f"quote|delta {delta} or open_shrt {open_shrt} >= limit {limit}, skip quoting sel")
            init_sel = False

        # self.cancel_open_orders(contract)
        cancel_ids = []
        for o in orders:
            side = self.order_side(o)
            oid = int(o['order_id'])
            opx = float(o['price'])
            if side == 'B':
                if abs(quote_bid - opx) > 0.01:
                    cancel_ids.append(oid)
                else:
                    self.log.info(f'quote_bid({quote_bid}) close to open_buy({opx}), skip cancel buy order')
            else:
                if abs(quote_ask - opx) > 0.01:
                    cancel_ids.append(oid)
                else:
                    self.log.info(f'quote_ask({quote_ask}) close to open_sel({opx}), skip cancel sel order')
        if len(cancel_ids) > 0:
            self.cancel_orders(contract, cancel_ids)

        bid_oid = 0
        ask_oid = 0
        if init_buy:
            type = OKEx.OrderTypes.OpenLong
            if abs(short)-open_long >= qty:
                type = OKEx.OrderTypes.CloseShort
            bid_oid = self.place_order(contract, type, quote_bid, qty)
            if bid_oid <= 0:
                self.log.error("quote|fail to quote bid order, skip this quote")
                return

        if init_sel:
            type = OKEx.OrderTypes.OpenShort
            if long-abs(open_shrt) >= qty:
                type = OKEx.OrderTypes.CloseLong
            ask_oid = self.place_order(contract, type, quote_ask, qty)
            if ask_oid <= 0 and bid_oid > 0:
                self.log.error("quote|fail to quote ask order, cancel bid order and skip this quote")
                self.cancel_orders(contract, [bid_oid])
                return

        self.log.info(f"quote|sell {qty} @ {quote_ask} ({ask_oid}), buy {qty} @ {quote_bid} ({bid_oid})")

    def hedge(self):
        long_n, short_n = self.get_position(self.near.contract)
        long_f, short_f = self.get_position(self.far.contract)

        orders = self.get_open_orders(self.far.contract)
        self.open_orders = orders
        delta_open = sum(self.order_qopen(o) for o in orders)

        delta_n = long_n + short_n
        delta_f = long_f + short_f
        delta = delta_n + delta_f + delta_open
        self.log.info(f"hedge|delta={delta}, near={long_n}/{short_n}, far={long_f}/{short_f}, open={delta_open}")

        if delta > 0:
            type = OKEx.OrderTypes.OpenShort
            if delta_f > 0 and delta_f >= delta:
                type = OKEx.OrderTypes.CloseLong
            self.place_order(self.far.contract, type, self.ref_bid, delta)

        if delta < 0:
            type = OKEx.OrderTypes.OpenLong
            if delta_f < 0 and delta_f <= delta:
                type = OKEx.OrderTypes.CloseShort
            self.place_order(self.far.contract, type, self.ref_ask, abs(delta))

    def run_update(self):
        freq = self.params.get('update_period', 3)
        while self.active:
            time.sleep(freq)
            if self.use_websocket:
                ob = self.near_ws.get_depth()
                self.near.update_ws(ob)
                ob = self.far_ws.get_depth()
                self.far.update_ws(ob)
            else:
                self.near.update()
                self.far.update()
            if "ob_group_precise" in self.params:
                precise = self.params['ob_group_precise']
                depth = self.params['ob_group_depth']
                self.near.aggregate(precise, depth)
                self.far.aggregate(precise, depth)
            # self.log.info(
            #     f"update|[near]ask/bid={self.near.ask}/{self.near.bid}, [far]ask/bid={self.far.ask}/{self.far.bid}")
            self.log.info(f'[near] {self.near.dump_str()}')
            self.log.info(f'[far ] {self.far.dump_str()}')
            self.roll_spreads.append(self.roll_mid_spread)
            self.log.info(f'roll_mid_spread={self.roll_mid_spread}, avg_spread={np.mean(self.roll_spreads):.4f}')

    def run_quote(self):
        freq = self.params.get('quote_period', 10)
        while self.active:
            try:
                if self.ready:
                    self.quote()
            except Exception as ex:
                self.log.error(f"quote|exception: {ex}")
            time.sleep(freq)

    def run_hedge(self):
        freq = self.params.get('hedge_period', 3)
        while self.active:
            try:
                if self.ready:
                    self.hedge()
            except Exception as ex:
                self.log.error(f"hedge|exception: {ex}")
            time.sleep(freq)

    def run_sanity_check(self):
        try:
            while self.active:
                if self.cancel_fails >= 10:
                    raise Exception(f"cancel fails >= 10")
                if len(self.open_orders) > self.open_delta_limit * 2:
                    raise Exception(f"#open orders >= {self.open_delta_limit} * 2")
                time.sleep(1)
        except Exception as ex:
            self.log.critical(ex)
            self.exit()

    def far_ws_connect(self):
        self.far_ws = RollWebSocket(self.far.symbol, self.far.contract)
        self.far_ws.log = self.log
        self.far_ws.connect()

    def near_ws_connect(self):
        self.near_ws = RollWebSocket(self.near.symbol, self.near.contract)
        self.near_ws.log = self.log
        self.near_ws.connect()

    def start(self):
        self.log.info("strategy start")
        self.active = True

        funcs = [
            self.run_update,
            self.run_quote,
            self.run_hedge,
            self.run_sanity_check
        ]

        if self.use_websocket:
            funcs.extend([self.far_ws_connect, self.near_ws_connect])

        pool = ThreadPool(processes=len(funcs))
        for func in funcs:
            pool.apply_async(func)

        while self.active:
            time.sleep(60)
