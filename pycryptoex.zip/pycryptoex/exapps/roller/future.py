import math


class Future(object):
    def __init__(self, ex, symbol, contract, depth=50):
        self.ex = ex
        self.ws = None
        self.symbol = symbol
        self.contract = contract
        self.depth = depth
        self.ask_prices = []
        self.bid_prices = []
        self.ask_sizes = []
        self.bid_sizes = []
        self.ask_amounts = []
        self.bid_amounts = []

    @property
    def ask(self):
        return self.ask_prices[0] if len(self.ask_prices) > 0 else 0

    @property
    def bid(self):
        return self.bid_prices[0] if len(self.bid_prices) > 0 else 0

    @property
    def spread(self):
        if not self.ready:
            return 0
        return (self.ask - self.bid) / (self.ask * 0.5 + self.bid * 0.5)

    @property
    def ready(self):
        return self.ask > 0 and self.bid > 0

    def reset(self):
        self.ask_prices.clear()
        self.bid_prices.clear()
        self.ask_sizes.clear()
        self.bid_sizes.clear()
        self.ask_amounts.clear()
        self.bid_amounts.clear()

    def allocate(self, depth):
        self.ask_sizes = [0.] * depth
        self.ask_prices = [0.] * depth
        self.ask_amounts = [0.] * depth
        self.bid_sizes = [0.] * depth
        self.bid_prices = [0.] * depth
        self.bid_amounts = [0.] * depth

    def update(self):
        ob = self.ex.future_depth(self.symbol, self.contract, self.depth)
        self.reset()

        asks = ob['asks']
        for i in range(len(asks) - 1, -1, -1):
            self.ask_prices.append(asks[i][0])
            self.ask_sizes.append(asks[i][1])

        bids = ob['bids']
        for i in range(len(bids)):
            self.bid_prices.append(bids[i][0])
            self.bid_sizes.append(bids[i][1])
        return ob

    def update_ws(self, ob):
        if ob is None:
            return
        self.reset()

        asks = ob['asks']
        for i in range(len(asks) - 1, -1, -1):
            self.ask_prices.append(float(asks[i][0]))
            self.ask_sizes.append(float(asks[i][1]))
            self.ask_amounts.append(float(asks[i][2]))

        bids = ob['bids']
        for i in range(len(bids)):
            self.bid_prices.append(float(bids[i][0]))
            self.bid_sizes.append(float(bids[i][1]))
            self.bid_amounts.append(float(bids[i][2]))

    class AggItem(object):
        def __init__(self):
            self.boundary = 0
            self.avgprc = 0
            self.qty = 0

    @staticmethod
    def internal_agg(prices, sizes, precise, is_lower):
        if len(prices) != len(sizes):
            raise Exception("agg error: len(prices)!=len(sizes)")

        factor = 1.0 / precise
        dic = {}
        for i in range(len(prices)):
            if is_lower:
                px = math.floor(prices[i] * factor) / factor
            else:
                px = math.ceil(prices[i] * factor) / factor
            if px not in dic:
                dic[px] = []
            dic[px].append((prices[i], sizes[i]))

        ob = []
        for k, v in dic.items():
            item = Future.AggItem()
            item.boundary = k
            item.qty = round(sum(e[1] for e in v), 4)
            val = sum(e[0] * e[1] for e in v)
            item.avgprc = round(val / item.qty, 3)
            ob.append(item)
        return ob

    def aggregate(self, precise, depth, use_avgprc=True):
        asks = Future.internal_agg(self.ask_prices, self.ask_sizes, precise, False)[:depth]
        bids = Future.internal_agg(self.bid_prices, self.bid_sizes, precise, True)[:depth]

        self.reset()
        self.allocate(depth)

        for i in range(len(asks)):
            self.ask_prices[i] = asks[i].avgprc if use_avgprc else asks[i].boundary
            self.ask_sizes[i] = asks[i].qty

        for i in range(len(bids)):
            self.bid_prices[i] = bids[i].avgprc if use_avgprc else bids[i].boundary
            self.bid_sizes[i] = bids[i].qty

    def dump_str(self):
        ask_str = []
        for i in range(len(self.ask_prices)):
            ask_str.append(f'({self.ask_prices[i]},{self.ask_sizes[i]})')
        bid_str = []
        for i in range(len(self.bid_prices)):
            bid_str.append(f'({self.bid_prices[i]},{self.bid_sizes[i]})')
        return ','.join(reversed(ask_str)) + ' | ' + ','.join(bid_str)
