import logging
from logging.handlers import TimedRotatingFileHandler


def get_logger(name, dir):
    file = f"{dir}/{name}.log"
    log = logging.getLogger(name)
    handler = TimedRotatingFileHandler(file, when='midnight')
    handler.setFormatter(logging.Formatter("%(asctime)s|%(levelname)s|%(message)s"))
    log.addHandler(handler)
    # log.setLevel(logging.INFO)
    log.setLevel(logging.DEBUG)
    return log
