import pandas as pd
import numpy as np
import h5py
import os.path
import json
import gzip
import shutil

depth = 50

attrs = {
    'ticker_header': 't,date,last,buy,sell,high,low,vol,contract_id,unit_amount',
    'trades_header': 't,date,date_ms,price,amount,type,tid',
    'depth_header': 't,' + ','.join(f'ap{i},as{i},bp{i},bs{i}' for i in range(depth)),
    'index_header': 't,index',
    'side': '0-buy,1-sell'
}


def to_sodsec(dt_str):
    dt = pd.to_datetime(dt_str, format='%Y-%m-%d %H:%M:%S,%f')
    return dt.hour * 3600 + dt.minute * 60 + dt.second + dt.microsecond / 1e6


def archive(file):
    # with open(file, 'rb') as fi:
    #     with gzip.open(f'{file}.gz', 'wb') as fo:
    #         shutil.copyfileobj(fi, fo)
    cmd = f"nice -n19 tar -czf {file}.tar.gz {file}"
    os.system(cmd)
    os.remove(file)


def parse_ticker(time, dat, is_fut):
    x = json.loads(dat)
    t = x['ticker']
    res = [time, float(x['date']), float(t['last']), float(t['buy']), float(t['sell']), float(t['high']),
           float(t['low']), float(t['vol'])]
    if is_fut:
        res.extend([float(t['contract_id']), float(t['unit_amount'])])
    else:
        res.extend([0, 0])
    return res


def parse_trades(time, dat):
    x = json.loads(dat)
    trades = []
    for e in x:
        t = [time, float(e['date']), float(e['date_ms']), float(e['price']), float(e['amount'])]
        t.append(0 if e['type'] == 'buy' else 1)
        t.append(float(e['tid']))
        trades.append(t)
    return trades


def parse_depth(time, dat, depth):
    x = json.loads(dat)
    n = depth * 4
    asks = x['asks'][:depth]
    bids = x['bids'][:depth]
    obs = []
    for i in range(len(bids)):
        bp_ = bids[i][0]
        bs_ = bids[i][1]
        j = len(asks) - i - 1
        ap_ = asks[j][0]
        as_ = asks[j][1]
        obs.extend([ap_, as_, bp_, bs_])
    obs = obs[:n] + [0] * (n - len(obs))
    return [time] + obs


def parse_index(time, dat):
    x = json.loads(dat)
    return [time, float(x['future_index'])]


class OKExRestParser(object):
    def __init__(self, name='okex'):
        self.name = name
        self.symbols = ['btc_usd', 'ltc_usd']
        self.contracts = ['this_week', 'next_week', 'quarter']
        self.data = {}
        for sym in self.symbols:
            self.data[sym] = {}
            self.data[sym]['index'] = []
            for contract in self.contracts:
                self.data[sym][contract] = {}
                self.data[sym][contract]['ticker'] = []
                self.data[sym][contract]['trades'] = []
                self.data[sym][contract]['depth'] = []

    def save_h5(self, file):
        date = os.path.basename(file).split('.')[-1]
        dir_ = os.path.dirname(file)

        h5 = h5py.File(f'{dir_}/{self.name}.{date}.h5', 'w')
        h5.attrs.update(attrs)

        for sym in self.symbols:
            h5.create_group(sym)
            for contract in self.contracts:
                h5.create_group(f'{sym}/{contract}')

        for sym, v in self.data.items():
            for contract, v2 in v.items():
                if contract == 'index':
                    h5.create_dataset(f'{sym}/index', data=np.array(v2), compression='gzip')
                else:
                    for type_, v3 in v2.items():
                        h5.create_dataset(f'{sym}/{contract}/{type_}', data=np.array(v3), compression='gzip')
        h5.close()

    def parse(self, file):
        for line in open(file, 'r').readlines():
            try:
                e = line.rstrip().split('|')
                t = to_sodsec(e[0])
                sym = e[1]
                contract = e[2]
                dat = e[-1].replace('\'', '"')
                if contract == 'index':
                    x = parse_index(t, dat)
                    self.data[sym][contract].append(x)
                else:
                    type_ = e[3]
                    if type_ == 'ticker':
                        x = parse_ticker(t, dat, True)
                        self.data[sym][contract][type_].append(x)
                    elif type_ == 'depth':
                        x = parse_depth(t, dat, depth)
                        self.data[sym][contract][type_].append(x)
                    elif type_ == 'trades':
                        x = parse_trades(t, dat)
                        self.data[sym][contract][type_].extend(x)
            except:
                # print("error: " + line)
                pass
        self.save_h5(file)
        # archive(file)


class OKSpotRestParser(object):
    def __init__(self, name, symbols):
        self.name = name
        self.symbols = symbols
        self.data = {}
        for sym in self.symbols:
            self.data[sym] = {}
            self.data[sym]['ticker'] = []
            self.data[sym]['trades'] = []
            self.data[sym]['depth'] = []

    def save_h5(self, file):
        date = os.path.basename(file).split('.')[-1]
        dir_ = os.path.dirname(file)

        h5 = h5py.File(f'{dir_}/{self.name}.{date}.h5', 'w')
        h5.attrs.update(attrs)

        for sym in self.symbols:
            h5.create_group(sym)

        for sym, v in self.data.items():
            for type_, v2 in v.items():
                h5.create_dataset(f'{sym}/{type_}', data=np.array(v2), compression='gzip')
        h5.close()

    def parse(self, file):
        for line in open(file, 'r').readlines():
            try:
                e = line.rstrip().split('|')
                t = to_sodsec(e[0])
                sym = e[1]
                type_ = e[2]
                dat = e[-1].replace('\'', '"')
                if type_ == 'ticker':
                    x = parse_ticker(t, dat, False)
                    self.data[sym][type_].append(x)
                elif type_ == 'depth':
                    x = parse_depth(t, dat, depth)
                    self.data[sym][type_].append(x)
                elif type_ == 'trades':
                    x = parse_trades(t, dat)
                    self.data[sym][type_].extend(x)
            except:
                # print("error: " + line)
                pass
        self.save_h5(file)
        # archive(file)


if __name__ == '__main__':
    from datetime import date, timedelta
    import glob

    yest = str(date.today() - timedelta(1))
    dir_ = "/data/okcoin/tmp"
    for file in glob.glob(f'{dir_}/*.{yest}'):
        print(file)
        if 'okex' in file:
            p = OKExRestParser('okex')
        elif 'okcn' in file:
            p = OKSpotRestParser('okcn', ['btc_cny', 'ltc_cny', 'eth_cny', 'etc_cny'])
        elif 'okcom' in file:
            p = OKSpotRestParser('okcom', ['btc_usd', 'ltc_usd', 'eth_usd', 'etc_usd'])
        else:
            continue
        # p.parse(file)
        archive(file)
