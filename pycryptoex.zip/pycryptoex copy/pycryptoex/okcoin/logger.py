import logging
from logging.handlers import TimedRotatingFileHandler


def get_logger(dir, name):
    file = f"{dir}/{name}.log"
    log = logging.getLogger(name)
    handler = TimedRotatingFileHandler(file, when='midnight')
    # handler.setFormatter(logging.Formatter("%(asctime)s|%(process)d|%(message)s", "%Y-%m-%dT%H:%M:%S%z"))
    # handler.setFormatter(logging.Formatter("%(asctime)s|%(process)d|%(message)s"))
    handler.setFormatter(logging.Formatter("%(asctime)s,%(message)s"))
    log.addHandler(handler)
    log.setLevel(logging.INFO)
    return log


class OKExLogger(object):
    RestIndex = 'time,symbol,future_index'
    RestTrade = 'time,symbol,contract,date,date_ms,price,amount,type,tid'
    RestDepth = 'time,symbol,contract,' + ''.join(
        "bp{x:02d},bs{x:02d},ap{x:02d},as{x:02d}".format(x=i) for i in range(1, 21))
    RestTicker = 'time,symbol,contract,date,contract_id,last,buy,sell,high,low,day_high,day_low,vol,coin_vol,unit_amount'

    def __init__(self, dir):
        self.dir = dir
        self.rest_index = get_logger(dir, 'okex.rest.index')
        self.rest_trade = get_logger(dir, 'okex.rest.trade')
        self.rest_depth = get_logger(dir, 'okex.rest.depth')
        self.rest_ticker = get_logger(dir, 'okex.rest.ticker')

    def _rest_index(self, x, symbol):
        self.rest_index.info(f"{symbol},{x['future_index']}")

    def _rest_trade(self, x, symbol, contract):
        self.rest_trade.info(
            f"{symbol},{contract},{x['date']},{x['date_ms']},{x['price']},{x['amount']},{x['type']},{x['tid']}")

    def _rest_depth(self, x, symbol, contract):
        aps, ass, bps, bss = [], [], [], []
        for a in x['asks']:
            aps.append(a[0])
            ass.append(a[1])
        for b in x['bids']:
            bps.append(b[0])
            bss.append(b[1])
        assert (len(aps) == len(bps))
        s = ','.join(f"{bps[i]},{bss[i]},{aps[i]},{ass[i]}" for i in range(len(aps)))
        self.rest_depth.info(f"{symbol},{contract},{s}")

    def _rest_ticker(self, x, symbol, contract):
        t = x['ticker']
        s = f"{x['date']},{t['contract_id']},{t['last']},{t['buy']},{t['sell']},{t['high']},{t['low']},{t['day_high']},{t['day_low']},{t['vol']},{t['coin_vol']},{t['unit_amount']}"
        self.rest_ticker.info(f"{symbol},{contract},{s}")

    def log_rest(self, type, x, symbol, contract):
        if type == 'index':
            self._rest_index(x, symbol)
        elif type == 'ticker':
            self._rest_ticker(x, symbol, contract)
        elif type == 'trade':
            for _x in x:
                self._rest_trade(_x, symbol, contract)
        elif type == 'depth':
            self._rest_depth(x, symbol, contract)
        else:
            print("unknown type: " + type)
