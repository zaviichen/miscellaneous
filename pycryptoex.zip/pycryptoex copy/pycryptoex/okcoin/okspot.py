from pycryptoex.okcoin.okcoin import OKCoin, encryption
from pycryptoex.common.logger import exlog as log


class OKSpot(OKCoin):
    def __init__(self, params):
        super().__init__(params)
        self.name = params.get('name', 'OKSpot')
        self.base_url = params.get('base_url', '')
        log.info(f'OKSpot init: {params}')

    def ticker(self, symbol):
        return self._get("ticker.do", {'symbol': symbol})

    def depth(self, symbol, size=5, merge=None):
        params = {'symbol': symbol, 'size': size}
        if merge:
            params['merge'] = merge
        return self._get("depth.do", params)

    def trades(self, symbol):
        return self._get("trades.do", {'symbol': symbol})

    def userinfo(self):
        params = {'api_key': self.access_key}
        params['sign'] = encryption(params, self.secret_key)
        return self._post("userinfo.do", params)

    def trade(self, symbol, type, price, amount):
        ''' type: buy/sell/buy_market/sell_market '''
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'type': type,
            'price': float(price),
            'amount': float(amount)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("trade.do", params)

    def cancel_order(self, symbol, order_ids):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'order_id': ','.join(str(o) for o in order_ids)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("cancel_order.do", params)

    def order_info(self, symbol, order_id=-1):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'order_id': int(order_id)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("order_info.do", params)


    def withdraw(self, symbol, fee, trade_pwd, address, amount, target):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'chargefee': float(fee),
            'trade_pwd': trade_pwd,
            'withdraw_address': address,
            'withdraw_amount': float(amount),
            'target': target
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("withdraw.do", params)

    def withdraw_info(self, symbol, withdraw_id):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'withdraw_id': str(withdraw_id)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("withdraw_info.do", params)


class OKCoinCn(OKSpot):
    DefaultBaseUrl = "https://www.okcoin.cn/api/v1"

    def __init__(self, params):
        super(OKCoinCn, self).__init__(params)
        self.name = params.get('name', 'OKCoinCn')
        self.base_url = params.get('base_url', OKCoinCn.DefaultBaseUrl)


class OKCoinCom(OKSpot):
    DefaultBaseUrl = "https://www.okcoin.com/api/v1"

    def __init__(self, params):
        super(OKCoinCom, self).__init__(params)
        self.name = params.get('name', 'OKCoinCom')
        self.base_url = params.get('base_url', OKCoinCom.DefaultBaseUrl)
