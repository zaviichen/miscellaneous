from pycryptoex.proto.marketdata_pb2 import Orderbook, Index
from datetime import datetime

import redis

r = redis.StrictRedis(host='localhost', port=6379, db=0)


class ProtoHelper(object):
    @staticmethod
    def json_to_orderbook(x):
        ob = Orderbook()
        ob.update_time = datetime.now().timestamp()
        ob.server_time = float(x['timestamp']) / 1000
        asks = x['asks']
        for i in range(len(asks) - 1, -1, -1):
            ob.asks.append(float(asks[i][0]))
            ob.ask_sizes.append(float(asks[i][1]))
        bids = x['bids']
        for i in range(len(bids)):
            ob.bids.append(float(bids[i][0]))
            ob.bid_sizes.append(float(bids[i][1]))
        return ob

    @staticmethod
    def json_to_index(x):
        idx = Index()
        idx.update_time = datetime.now().timestamp()
        idx.server_time = float(x['timestamp']) / 1000
        idx.index = float(x['futureIndex'])
        return idx

    @staticmethod
    def orderbook_from_redis(key: object) -> object:
        x = r.lrange(key, 0, 0)
        if len(x) > 0:
            o = Orderbook()
            o.ParseFromString(x[0])
            return o
        return None
