import logging
from sys import platform
from logging.handlers import TimedRotatingFileHandler

if platform == "win32":
    DefaultLogDir = "c:/temp"
else:
    DefaultLogDir = "/tmp"


def exec_logger(name, path):
    file = f"{path}/pycryptoex.log"
    handler = TimedRotatingFileHandler(file, when='midnight')

    fmt = "%(asctime)s.%(msecs)03d|%(process)d|%(name)s|%(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    formatter = logging.Formatter(fmt, datefmt=datefmt)
    handler.setFormatter(formatter)

    log = logging.getLogger(name)
    log.addHandler(handler)
    log.setLevel(logging.INFO)
    return log


exlog = exec_logger("exchange", path=DefaultLogDir)
