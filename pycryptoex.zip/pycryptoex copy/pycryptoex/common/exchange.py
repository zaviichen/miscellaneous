from pycryptoex.proto.marketdata_pb2 import Ticker, Orderbook, Trade
from pycryptoex.proto.order_pb2 import Order


class Exchange(object):
    def __init__(self, params):
        self.params = params
        self.name = ''
        self.base_url = ''
        self.enable = params.get('enable', True)
        self.access_key = params.get('access_key', '')
        self.secret_key = params.get('secret_key', '')
        self.timeout = params.get('timeout', 3)
        self.websocket = None
        self.session = None

    def get_ticker(self, symbol, **kwargs) -> Ticker:
        raise NotImplementedError()

    def get_orderbook(self, symbol, **kwargs) -> Orderbook:
        raise NotImplementedError()

    def get_trade(self, symbol, **kwargs) -> Trade:
        raise NotImplementedError()

    def send_order(self, order: Order, **kwargs) -> bool:
        raise NotImplementedError()

    def cancel_order(self, order: Order, **kwargs) -> bool:
        raise NotImplementedError()

    def get_order_response(self, order: Order, **kwargs) -> Order:
        raise NotImplementedError()
