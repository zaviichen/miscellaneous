#!/usr/bin/env bash

protoc_bin="/Users/zhchen/Downloads/protoc-3.3.0-osx-x86_64/bin/protoc"
#proto_path="/Users/zhchen/PycharmProjects/pycryptoex/pycryptoex/proto/"

$protoc_bin --proto_path=. --python_out=. marketdata.proto
$protoc_bin --proto_path=. --python_out=. order.proto

$protoc_bin --proto_path=. --csharp_out=. marketdata.proto
$protoc_bin --proto_path=. --csharp_out=. order.proto