import sys

sys.path.extend(["/home/ubuntu/pycryptoex"])

import time
import redis

from pycryptoex.okcoin import OKCoinWebSocket, ProtoHelper

r = redis.StrictRedis(host='localhost', port=6379, db=0)

# either 20 or 60
depth = 20


def okex_save_redis(msg):
    try:
        for e in msg:
            if 'channel' not in e:
                continue
            channel = e['channel']
            data = e['data']

            keys = ['', '', '']
            if 'btc' in channel:
                keys[0] = 'btc_usd'
            else:
                keys[0] = 'ltc_usd'

            if 'index' in channel:
                keys[1] = 'index'
                keys[2] = 'index'
            else:
                if 'this_week' in channel:
                    keys[1] = 'this_week'
                elif 'next_week' in channel:
                    keys[1] = 'next_week'
                elif 'quarter' in channel:
                    keys[1] = 'quarter'

                if 'ticker' in channel:
                    keys[2] = 'ticker'
                elif 'depth' in channel:
                    keys[2] = 'depth'
                elif 'trade' in channel:
                    keys[2] = 'trade'

            if keys[0] == '' or keys[1] == '' or keys[2] == '':
                continue

            key_str = f'{keys[0]}:{keys[1]}:{keys[2]}'
            type_ = keys[2]
            if type_ == 'depth':
                x = ProtoHelper.json_to_orderbook(data)
                r.lpush(key_str, x.SerializeToString())
            elif type_ == 'index':
                x = ProtoHelper.json_to_index(data)
                r.lpush(key_str, x.SerializeToString())
            # if 'trade' in channel:
            #     for t in data:
            #         r.lpush(key_str, t, 60)
            # else:
            #     r.lpush(key_str, data)
            r.ltrim(key_str, 0, 199)
    except Exception as ex:
        print(ex, msg)


def okex_ws_subscribe():
    def okex_channels():
        channels = []
        for symbol in ['btc', 'ltc']:
            channels.append(f'ok_sub_futureusd_{symbol}_index')
            for contract in ['this_week', 'next_week', 'quarter']:
                # channels.append(f'ok_sub_futureusd_{symbol}_ticker_{contract}')
                # channels.append(f'ok_sub_futureusd_{symbol}_trade_{contract}')
                channels.append(f'ok_sub_futureusd_{symbol}_depth_{contract}_{depth}')
        return channels

    ws_params = {
        'wsurl': 'wss://real.okex.com:10440/websocket/okexapi',
        'binary': False,
        'daemon': False,
        'channels': okex_channels()
    }
    ws = OKCoinWebSocket(ws_params)
    ws.add_callback('on_message', okex_save_redis)
    ws.connect()


def okcn_save_redis(msg):
    try:
        for e in msg:
            if 'channel' not in e:
                continue
            channel = e['channel']
            data = e['data']

            keys = ['', '']
            if 'btc' in channel:
                keys[0] = 'btc_cny'
            elif 'ltc' in channel:
                keys[0] = 'ltc_cny'
            elif 'eth' in channel:
                keys[0] = 'eth_cny'

            if 'ticker' in channel:
                keys[1] = 'ticker'
            elif 'depth' in channel:
                keys[1] = 'depth'
            elif 'trade' in channel:
                keys[1] = 'trade'

            if keys[0] == '' or keys[1] == '':
                continue

            key_str = f'{keys[0]}:{keys[1]}'
            type_ = keys[1]
            if type_ == 'depth':
                x = ProtoHelper.json_to_orderbook(data)
                r.lpush(key_str, x.SerializeToString())
            elif type_ == 'index':
                x = ProtoHelper.json_to_index(data)
                r.lpush(key_str, x.SerializeToString())

            # if 'trade' in channel:
            #     for t in data:
            #         r.lpush(key_str, t)
            # else:
            #     r.lpush(key_str, data)
            r.ltrim(key_str, 0, 199)
    except Exception as ex:
        print(ex, msg)


def okcn_ws_subscribe():
    def okcn_channels():
        channels = []
        for symbol in ['btc', 'ltc', 'eth']:
            # channels.append(f'ok_sub_spotcny_{symbol}_ticker')
            # channels.append(f'ok_sub_spotcny_{symbol}_trades')
            channels.append(f'ok_sub_spotcny_{symbol}_depth_60')
        return channels

    ws_params = {
        'wsurl': 'wss://real.okcoin.cn:10440/websocket/okcoinapi',
        'binary': False,
        'daemon': False,
        'channels': okcn_channels()
    }
    ws = OKCoinWebSocket(ws_params)
    ws.add_callback('on_message', okcn_save_redis)
    ws.connect()


if __name__ == "__main__":
    from multiprocessing.pool import ThreadPool
    from multiprocessing import Pool

    funcs = [
        okex_ws_subscribe,
        okcn_ws_subscribe,
    ]

    use_thread = True
    if use_thread:
        pool = ThreadPool(processes=len(funcs))
    else:
        pool = Pool(processes=len(funcs))

    for func in funcs:
        pool.apply_async(func)

    while True:
        time.sleep(60)
