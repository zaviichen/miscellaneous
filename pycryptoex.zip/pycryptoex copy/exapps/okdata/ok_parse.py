import pandas as pd
import numpy as np
import h5py
import os.path
import os
import json
import glob

os.nice(20)
depth = 50

attrs = {
    'ticker_header': 't,date,last,buy,sell,high,low,vol,contract_id,unit_amount',
    'trades_header': 't,date,date_ms,price,amount,type,tid',
    'depth_header': 't,' + ','.join(f'ap{i},as{i},bp{i},bs{i}' for i in range(depth)),
    'index_header': 't,index',
    'side': '0-buy,1-sell'
}

split_cmd = """cat #LOG# | awk -F'|' '{f=$2"."$3"."$4; print > "#LOG#.dir/"f}' """


def to_sodsec(dt_str):
    dt = pd.to_datetime(dt_str, format='%Y-%m-%d %H:%M:%S,%f')
    return dt.hour * 3600 + dt.minute * 60 + dt.second + dt.microsecond / 1e6


def archive(file):
    cmd = f"gzip -9 {file}"
    os.system(cmd)


def parse_ticker(time, dat, is_fut):
    x = json.loads(dat)
    t = x['ticker']
    res = [time, float(x['date']), float(t['last']), float(t['buy']), float(t['sell']), float(t['high']),
           float(t['low']), float(t['vol'])]
    if is_fut:
        res.extend([float(t['contract_id']), float(t['unit_amount'])])
    else:
        res.extend([0, 0])
    return res


def parse_trades(time, dat):
    x = json.loads(dat)
    trades = []
    for e in x:
        t = [time, float(e['date']), float(e['date_ms']), float(e['price']), float(e['amount'])]
        t.append(0 if e['type'] == 'buy' else 1)
        t.append(float(e['tid']))
        trades.append(t)
    return trades


def parse_depth(time, dat, depth):
    x = json.loads(dat)
    n = depth * 4
    asks = x['asks'][:depth]
    bids = x['bids'][:depth]
    obs = []
    for i in range(len(bids)):
        bp_ = bids[i][0]
        bs_ = bids[i][1]
        j = len(asks) - i - 1
        ap_ = asks[j][0]
        as_ = asks[j][1]
        obs.extend([ap_, as_, bp_, bs_])
    obs = obs[:n] + [0] * (n - len(obs))
    return [time] + obs


def parse_index(time, dat):
    x = json.loads(dat)
    return [time, float(x['future_index'])]


class OKCoinRestParser(object):
    def __init__(self, name, symbols, contracts):
        self.name = name
        self.symbols = symbols
        self.contracts = contracts
        self.is_fut = False
        self.data = {}
        for sym in self.symbols:
            self.data[sym] = {}
            for contract in self.contracts:
                self.data[sym][contract] = {}
                self.data[sym][contract]['ticker'] = []
                self.data[sym][contract]['trades'] = []
                self.data[sym][contract]['depth'] = []

    def save_h5(self, file):
        h5 = h5py.File(f'{file}.h5', 'w')
        h5.attrs.update(attrs)
        for sym, v in self.data.items():
            for contract, v2 in v.items():
                for type_, v3 in v2.items():
                    h5.create_dataset(f'{sym}/{contract}/{type_}', data=np.array(v3), compression='gzip')
        h5.close()

    def parse(self, file):
        for line in open(file, 'r').readlines():
            try:
                e = line.rstrip().split('|')
                t = to_sodsec(e[0])
                sym = e[1]
                contract = e[2]
                type_ = e[3]
                dat = e[-1].replace('\'', '"')
                if type_ == 'index':
                    x = parse_index(t, dat)
                    self.data[sym][contract][type_].append(x)
                elif type_ == 'ticker':
                    x = parse_ticker(t, dat, self.is_fut)
                    self.data[sym][contract][type_].append(x)
                elif type_ == 'depth':
                    x = parse_depth(t, dat, depth)
                    self.data[sym][contract][type_].append(x)
                elif type_ == 'trades':
                    x = parse_trades(t, dat)
                    self.data[sym][contract][type_].extend(x)
            except:
                # print("error: " + line.rstrip())
                pass
        self.save_h5(file)
        # archive(file)


class OKExRestParser(OKCoinRestParser):
    def __init__(self, name):
        super().__init__(name, ('btc_usd', 'ltc_usd'), ('index', 'this_week', 'next_week', 'quarter'))
        self.is_fut = True
        for sym in self.symbols:
            self.data[sym]['index'] = {}
            self.data[sym]['index']['index'] = []


class OKSpotRestParser(OKCoinRestParser):
    def __init__(self, name, symbols, contracts):
        super().__init__(name, symbols, contracts)
        self.is_fut = False


def create_parse(file):
    if 'okex' in file:
        return OKExRestParser('okex')
    elif 'okcn' in file:
        return OKSpotRestParser('okcn', ('btc_cny', 'ltc_cny', 'eth_cny', 'etc_cny'), ('cny',))
    elif 'okcom' in file:
        return OKSpotRestParser('okcom', ('btc_usd', 'ltc_usd', 'eth_usd', 'etc_usd'), ('usd',))
    else:
        return None


def run(file):
    tmp_dir = f"{file}.dir"
    if not os.path.exists(tmp_dir):
        os.mkdir(tmp_dir)
    cmd = split_cmd.replace('#LOG#', file)
    print(cmd)
    os.system(cmd)

    for tmpf in glob.glob(f"{tmp_dir}/*"):
        print(tmpf)
        p = create_parse(file)
        if p is not None:
            p.parse(tmpf)
            del p

    dic = {}
    for h5f in glob.glob(f"{tmp_dir}/*.h5"):
        h5r = h5py.File(h5f, 'r')
        for sym, v in h5r.items():
            for contract, v2 in v.items():
                for type_, v3 in v2.items():
                    key = f"{sym}/{contract}/{type_}"
                    if key not in dic:
                        dic[key] = []
                    dic[key].append(pd.DataFrame(h5r[sym][contract][type_][:]))
        h5r.close()
    h5w = h5py.File(f"{file}.h5", 'w')
    h5w.attrs.update(attrs)
    for k, v in dic.items():
        df = pd.concat(v)
        h5w.create_dataset(k, data=df.values, compression='gzip')
    h5w.close()

    archive(file)
    os.system(f"rm -rf {tmp_dir}")


if __name__ == '__main__':
    import sys
    from datetime import date, timedelta

    dir_ = sys.argv[1]

    if len(sys.argv) == 3:
        file = f"{dir_}/{sys.argv[2]}"
        run(file)
    else:
        yest = str(date.today() - timedelta(1))
        for file in glob.glob(f'{dir_}/*.{yest}'):
            print(file)
            run(file)
