import sys
sys.path.extend(["/home/ubuntu/pycryptoex"])

import logging
import time
from logging.handlers import TimedRotatingFileHandler
from pycryptoex.okcoin import OKCoinWebSocket, OKEx, OKCoinCn, OKCoinCom

period = 3
depth = 50


def get_logger(name):
    file = f"/tmp/okcoin/{name}.log"
    log = logging.getLogger(name)
    handler = TimedRotatingFileHandler(file, when='midnight')
    # handler.setFormatter(logging.Formatter("%(asctime)s|%(process)d|%(message)s", "%Y-%m-%dT%H:%M:%S%z"))
    handler.setFormatter(logging.Formatter("%(asctime)s|%(message)s"))
    log.addHandler(handler)
    log.setLevel(logging.INFO)
    return log


def okex_ws_subscribe():
    wslog = get_logger('okex.ws')

    def okex_channels():
        channels = []
        for symbol in ['btc', 'ltc']:
            channels.append(f'ok_sub_futureusd_{symbol}_index')
            for contract in ['this_week', 'next_week', 'quarter']:
                channels.append(f'ok_sub_futureusd_{symbol}_ticker_{contract}')
                channels.append(f'ok_sub_futureusd_{symbol}_trade_{contract}')
                channels.append(f'ok_sub_futureusd_{symbol}_depth_{contract}_20')
        return channels

    ws_params = {
        'wsurl': 'wss://real.okex.com:10440/websocket/okexapi',
        'binary': False,
        'daemon': False,
        'channels': okex_channels()
    }
    ws = OKCoinWebSocket(ws_params)
    ws.add_callback('on_message', wslog.info)
    ws.connect()


def okex_rest_subscribe():
    relog = get_logger('okex.rest')
    ex = OKEx({})

    while True:
        try:
            for symbol in ['btc_usd', 'ltc_usd']:
                relog.info(f'{symbol}|index|index|{ex.future_index(symbol)}')
                for contract in ['this_week', 'next_week', 'quarter']:
                    relog.info(f'{symbol}|{contract}|ticker|{ex.future_ticker(symbol, contract)}')
                    relog.info(f'{symbol}|{contract}|trades|{ex.future_trades(symbol, contract)}')
                    relog.info(f'{symbol}|{contract}|depth|{ex.future_depth(symbol, contract, depth)}')
            time.sleep(period)
        except Exception as ex:
            print(ex)


def okcn_ws_subscribe():
    wslog = get_logger('okcn.ws')

    def okcn_channels():
        channels = []
        for symbol in ['btc', 'ltc', 'eth']:
            channels.append(f'ok_sub_spotcny_{symbol}_ticker')
            channels.append(f'ok_sub_spotcny_{symbol}_trades')
            channels.append(f'ok_sub_spotcny_{symbol}_depth_20')
        return channels

    ws_params = {
        'wsurl': 'wss://real.okcoin.cn:10440/websocket/okcoinapi',
        'binary': False,
        'daemon': False,
        'channels': okcn_channels()
    }
    ws = OKCoinWebSocket(ws_params)
    ws.add_callback('on_message', wslog.info)
    ws.connect()


def okcn_rest_subscribe():
    relog = get_logger('okcn.rest')
    ex = OKCoinCn({})

    while True:
        try:
            for symbol in ['btc_cny', 'ltc_cny', 'eth_cny']:
                relog.info(f'{symbol}|cny|ticker|{ex.ticker(symbol)}')
                relog.info(f'{symbol}|cny|trades|{ex.trades(symbol)}')
                relog.info(f'{symbol}|cny|depth|{ex.depth(symbol, depth)}')
            time.sleep(period)
        except Exception as ex:
            print(ex)


def okcom_ws_subscribe():
    wslog = get_logger('okcom.ws')

    def _channels():
        channels = []
        for symbol in ['btc', 'ltc', 'eth']:
            channels.append(f'ok_sub_spotusd_{symbol}_ticker')
            channels.append(f'ok_sub_spotusd_{symbol}_trades')
            channels.append(f'ok_sub_spotusd_{symbol}_depth_20')
        return channels

    ws_params = {
        'wsurl': 'wss://real.okcoin.com:10440/websocket/okcoinapi',
        'binary': False,
        'daemon': False,
        'channels': _channels()
    }
    ws = OKCoinWebSocket(ws_params)
    ws.add_callback('on_message', wslog.info)
    ws.connect()


def okcom_rest_subscribe():
    relog = get_logger('okcom.rest')
    ex = OKCoinCom({})

    while True:
        try:
            for symbol in ['btc_usd', 'ltc_usd', 'eth_usd']:
                relog.info(f'{symbol}|usd|ticker|{ex.ticker(symbol)}')
                relog.info(f'{symbol}|usd|trades|{ex.trades(symbol)}')
                relog.info(f'{symbol}|usd|depth|{ex.depth(symbol, depth)}')
            time.sleep(period)
        except Exception as ex:
            print(ex)


if __name__ == "__main__":
    from multiprocessing.pool import ThreadPool
    from multiprocessing import Pool

    funcs = [
        # okex_ws_subscribe,
        okex_rest_subscribe,
        # okcn_ws_subscribe,
        okcn_rest_subscribe,
        # okcom_ws_subscribe,
        okcom_rest_subscribe
    ]

    use_thread = True
    if use_thread:
        pool = ThreadPool(processes=len(funcs))
    else:
        pool = Pool(processes=len(funcs))

    for func in funcs:
        pool.apply_async(func)

    while True:
        time.sleep(60)
