import numpy as np
import math
from datetime import datetime
from enum import Enum
from typing import List, Dict
from pycryptoex.proto.order_pb2 import Order


class OpporType(Enum):
    Nothing = 1
    Entry = 2
    Exit = 3
    ReEntry = 4


class ExitCodeType(Enum):
    Nothing = 1
    TakeProfit = 2
    StopLoss = 3
    HoldExpire = 4
    CloseExit = 5


class OpporLeg(object):
    def __init__(self):
        self.exchange = ''
        self.symbol = ''
        self.price_in = 0
        self.price_out = 0
        self.fee_pct = 0
        self.size = 0
        self.orders = {}  # type: Dict[int, Order]
        self.log = None

    @property
    def profit(self):
        if self.price_out <= 0:
            return 0
        return (self.price_out - self.price_in) / self.price_in * np.sign(self.size) - 2.0 * self.fee_pct

    @property
    def estipnl(self):
        if self.price_out <= 0:
            return 0
        return (self.price_out - self.price_in) * self.size

    def realpnl(self):
        sum = 0
        fee = 0
        for o in self.orders.values():
            if o.State == Order.StateType.Fill:
                cash = np.abs(o.Qdone * o.AvgPrice)
                fee += cash * self.fee_pct
                sum += (1 if o.Side == o.SideType.Buy else -1) * cash
            else:
                self.log.warn(f"find unfill order - set real pnl to 0")
                return 0
        return sum - fee


class Opportunity(object):
    def __init__(self):
        self.strategy = ""
        self.id = 0
        self.long = OpporLeg()
        self.short = OpporLeg()
        self.spread_in = 0
        self.spread_out = 0
        self.entry_time: datetime = None  #
        self.exit_time: datetime = None
        self.type = OpporType.Nothing
        self.exit_code = ExitCodeType.Nothing

    @property
    def cost(self):
        return 2 * (self.long.fee_pct + self.short.fee_pct)

    @property
    def exposure(self):
        return self.long.price_in * self.long.size

    @property
    def hold_seconds(self):
        return max(0, (self.exit_time - self.entry_time).total_seconds())

    @property
    def realpnl(self):
        return self.long.realpnl() + self.short.realpnl()

    @property
    def esitpnl(self):
        return self.long.estipnl + self.short.estipnl

    # @property
    # def is_close(self):
    #     if self.type == OpporType.Exit:
    #         lcls = self.long.orders.
