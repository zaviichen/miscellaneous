import sys
sys.path.append("/home/ubuntu/pycryptoex")

import json
from exapps.iarb.ibot import IBot

config = json.load(open(sys.argv[1]))
bot = IBot(**config)
bot.start()
