import logging
from datetime import datetime
from pycryptoex.proto.order_pb2 import Order
from pycryptoex.common.exchange import Exchange


class SmartOrder(object):
    def __init__(self, order: Order, ex: Exchange, strat):
        self.order = order
        self.exchange = ex
        self.strategy = strat
        self.active = False
        self.send_time = 0
        self.loop_in_ms = 200
        self.expire_time = 5
        self.prev_state = Order.State.Init
        self.prev_qdone = 0
        self.num_cancel = 0
        self.log: logging.Logger = strat.log
        if order.state != Order.State.Init:
            raise Exception(f"SmartOrder init failed: {order.Symbol}'s state must be init")

    @property
    def expired(self):
        if self.send_time > 0:
            return datetime.now().timestamp() - self.send_time > self.expire_time
        return False

    def cancel_on_expiry(self):
        if not self.expired:
            return
        self.log.info(f"cancel live order due to time expired: {self.order.Id}")
        if self.num_cancel == 0:
            self.exchange.cancel_order(self.order)
            self.num_cancel += 1

    def send(self):
        if not self.exchange.send_order(self.order):
            self.active = False
            self.log.info("send order failed")
            return False
        self.active = True
        self.send_time = self.order.UpdateUtc
        # start monitoring thread
        return True
