import redis
from exapps.iarb.orderbook import Orderbook


class Spot(object):
    def __init__(self, ex, symbol, depth=50):
        self.ex = ex
        self.ws = None
        self.symbol = symbol
        self.ob = Orderbook(depth)
        self.redis = redis.StrictRedis(host='localhost', port=6379, db=0)

    @property
    def ask(self):
        return self.ob.ask

    @property
    def bid(self):
        return self.ob.bid

    @property
    def spread(self):
        return self.ob.spread

    @property
    def ready(self):
        return self.ob.ready

    def update(self):
        key = f"{self.symbol}:depth"
        ob = self.redis.lrange(key, 0, 0)
        if len(ob) > 0:
            self.ob.update(ob[0])
