import time
import atexit
import signal
import sys
import math
import collections
from multiprocessing.pool import ThreadPool
from exapps.roller.logger import get_logger
from exapps.iarb.spot import Spot
from exapps.iarb.future import Future
from pycryptoex.okcoin import OKEx, OKCoinCn


class IBot(object):
    def __init__(self, **kwargs):
        self.params = kwargs
        self.spt_ex = OKCoinCn(kwargs['spt_ex'])
        self.fut_ex = OKEx(kwargs['fut_ex'])
        self.spt = Spot(self.spt_ex, kwargs['spt_symbol'])
        self.fut = Future(self.fut_ex, kwargs['fut_symbol'], kwargs['fut_contract'])
        self.qty = kwargs.get('fixed_amount', 1)
        self.open_delta_limit = kwargs.get('open_delta_limit', 3)
        self.active = True
        self.fx = kwargs.get('fx', 6.7)
        self.iarb_spreads = collections.deque(maxlen=200)

        atexit.register(self.exit)
        signal.signal(signal.SIGTERM, self.exit)
        self.log = get_logger(f"ibot-{self.spt.symbol}-{self.fut.symbol}-{self.fut.contract}", kwargs['log_dir'])

    def exit(self):
        try:
            pass
            # self.near.cancel_open_orders()
            # self.far.cancel_open_orders()
        except Exception as ex:
            self.log.error(f"unable to cancel all live orders: {ex}")
        self.active = False
        self.log.info("strategy exit")
        sys.exit()

    @property
    def ready(self):
        return self.spt.ready and self.fut.ready

    @property
    def buy_spread(self):
        if not self.ready:
            return 0
        return math.log(self.fut.ask * self.fx / self.spt.bid)

    @property
    def sel_spread(self):
        if not self.ready:
            return 0
        return math.log(self.fut.bid * self.fx / self.spt.ask)

    @property
    def mid_spread(self):
        return round((self.buy_spread + self.sel_spread) / 2, 4)

    def quote(self):
        if self.mid_spread > 0.02:
            

    def run_update(self):
        freq = self.params.get('update_period', 0.5)
        while self.active:
            try:
                self.spt.update()
                self.fut.update()
                if "ob_group_precise" in self.params:
                    precise = self.params['ob_group_precise']
                    depth = self.params['ob_group_depth']
                    self.spt.ob.aggregate(precise, depth, use_avgprc=True)
                    self.fut.ob.aggregate(precise, depth, use_avgprc=True)
                self.log.info(f"mid: {self.mid_spread}, spot={self.spt.ob.dump()}, fut={self.fut.ob.dump()}")
                self.iarb_spreads.append(self.mid_spread)
            except Exception as ex:
                self.log.error(f"update|exception: {ex}")
            time.sleep(freq)

    def run_quote(self):
        freq = self.params.get('quote_period', 10)
        while self.active:
            try:
                if self.ready:
                    self.quote()
            except Exception as ex:
                self.log.error(f"quote|exception: {ex}")
            time.sleep(freq)

    def run_sanity_check(self):
        try:
            while self.active:
                # delta = self.near.long + self.near.short + self.far.long + self.far.short
                # if delta != 0:
                #     time.sleep(10)
                #     delta2 = self.near.long + self.near.short + self.far.long + self.far.short
                #     if delta2 != 0:
                #         raise Exception(f"imbalance delta: near={self.near.dump_pos()}, far={self.far.dump_pos()}")
                time.sleep(1)
        except Exception as ex:
            self.log.critical(ex)
            self.exit()

    def start(self):
        self.log.info("strategy start")
        self.active = True

        funcs = [
            self.run_update,
            self.run_quote,
            self.run_sanity_check
        ]

        pool = ThreadPool(processes=len(funcs))
        for func in funcs:
            pool.apply_async(func)

        while self.active:
            time.sleep(60)
