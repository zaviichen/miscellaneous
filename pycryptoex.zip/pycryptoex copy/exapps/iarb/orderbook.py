import math
from pycryptoex.proto.marketdata_pb2 import Orderbook as OB


class AggItem(object):
    def __init__(self):
        self.boundary = 0
        self.avgprc = 0
        self.qty = 0


def internal_agg(prices, sizes, precise, is_lower):
    if len(prices) != len(sizes):
        raise Exception("agg error: len(prices)!=len(sizes)")

    factor = 1.0 / precise
    dic = {}
    for i in range(len(prices)):
        if is_lower:
            px = math.floor(prices[i] * factor) / factor
        else:
            px = math.ceil(prices[i] * factor) / factor
        if px not in dic:
            dic[px] = []
        dic[px].append((prices[i], sizes[i]))

    ob = []
    for k, v in dic.items():
        item = AggItem()
        item.boundary = k
        item.qty = round(sum(e[1] for e in v), 4)
        val = sum(e[0] * e[1] for e in v)
        item.avgprc = round(val / item.qty, 3)
        ob.append(item)
    return ob


class Orderbook(object):
    def __init__(self, depth=50):
        self.depth = depth
        self.ob = OB()

    @property
    def ask(self):
        return self.ob.asks[0] if len(self.ob.asks) > 0 else 0

    @property
    def bid(self):
        return self.ob.bids[0] if len(self.ob.bids) > 0 else 0

    @property
    def spread(self):
        if not self.ready:
            return 0
        return (self.ask - self.bid) / (self.ask * 0.5 + self.bid * 0.5)

    @property
    def ready(self):
        return self.ask > 0 and self.bid > 0

    def reset(self):
        self.ob = OB()

    def allocate(self, depth):
        self.reset()
        for i in range(depth):
            self.ob.ask_sizes.append(0.)
            self.ob.asks.append(0.)
            self.ob.bid_sizes.append(0.)
            self.ob.bids.append(0.)

    def update(self, dat):
        if dat is None:
            return
        self.ob.ParseFromString(dat)

    def dump(self, depth=1):
        ask_str = []
        n = min(depth, len(self.ob.asks))
        for i in range(n):
            ask_str.append(f'({self.ob.asks[i]},{self.ob.ask_sizes[i]})')
        bid_str = []
        n = min(depth, len(self.ob.bids))
        for i in range(n):
            bid_str.append(f'({self.ob.bids[i]},{self.ob.bid_sizes[i]})')
        return ','.join(reversed(ask_str)) + '|' + ','.join(bid_str)

    @staticmethod
    def internal_agg(prices, sizes, precise, is_lower):
        if len(prices) != len(sizes):
            raise Exception("agg error: len(prices)!=len(sizes)")

        factor = 1.0 / precise
        dic = {}
        for i in range(len(prices)):
            if is_lower:
                px = math.floor(prices[i] * factor) / factor
            else:
                px = math.ceil(prices[i] * factor) / factor
            if px not in dic:
                dic[px] = []
            dic[px].append((prices[i], sizes[i]))

        ob = []
        for k, v in dic.items():
            item = AggItem()
            item.boundary = k
            item.qty = round(sum(e[1] for e in v), 4)
            val = sum(e[0] * e[1] for e in v)
            item.avgprc = round(val / item.qty, 3)
            ob.append(item)
        return ob

    def aggregate(self, precise, depth, use_avgprc=True):
        asks = internal_agg(self.ob.asks, self.ob.ask_sizes, precise, False)[:depth]
        bids = internal_agg(self.ob.bids, self.ob.bid_sizes, precise, True)[:depth]

        self.allocate(depth)

        for i in range(len(asks)):
            self.ob.asks[i] = asks[i].avgprc if use_avgprc else asks[i].boundary
            self.ob.ask_sizes[i] = asks[i].qty

        for i in range(len(bids)):
            self.ob.bids[i] = bids[i].avgprc if use_avgprc else bids[i].boundary
            self.ob.bid_sizes[i] = bids[i].qty
