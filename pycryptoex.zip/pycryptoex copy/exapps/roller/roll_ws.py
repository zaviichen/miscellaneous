from pycryptoex.okcoin import OKCoinWebSocket


class RollWebSocket(object):

    MaxLimit = 200

    def __init__(self, symbol, contract, **kwargs):
        self.params = kwargs
        self.symbol = symbol.split('_')[0] if '_' in symbol else symbol
        self.contract = contract
        self.log = None

        self.data = {
            'ticker': [],
            'depth': [],
            'trade': []
        }

        channels = []
        # channels.append(f'ok_sub_futureusd_{self.symbol}_index')
        # channels.append(f'ok_sub_futureusd_{self.symbol}_ticker_{contract}')
        # channels.append(f'ok_sub_futureusd_{self.symbol}_trade_{contract}')
        channels.append(f'ok_sub_futureusd_{self.symbol}_depth_{self.contract}_20')

        ws_params = {
            'wsurl': 'wss://real.okex.com:10440/websocket/okexapi',
            'binary': False,
            'daemon': False,
            'channels': channels
        }

        self.ws = OKCoinWebSocket(ws_params)
        self.ws.add_callback('on_message', self.on_message)

    def connect(self):
        self.log.info(f"connecting websocket for future {self.symbol}, {self.contract}...")
        self.ws.connect()

    def on_message(self, msg):
        for e in msg:
            if 'event' in e:
                continue
            try:
                chan = e['channel']
                data = e['data']
                if 'result' in data:
                    continue

                if 'ticker' in chan:
                    self.data['ticker'].append(data)
                elif 'depth' in chan:
                    self.data['depth'].append(data)
                elif 'trade' in chan:
                    self.data['trade'].extend(data)
                elif 'index' in chan:
                    self.data['index'].append(data)

                for k,v in self.data.items():
                    if len(v) > RollWebSocket.MaxLimit:
                        self.data[k] = self.data[k][RollWebSocket.MaxLimit // 2:]
            except:
                self.log.error(f"on_message: {msg}")

    def get_depth(self):
        ob = self.data['depth']
        if len(ob) == 0:
            self.log.error("no orderbook found")
            return None
        return ob[-1]
