import time
import atexit
import signal
import sys
import collections
import numpy as np
from multiprocessing.pool import ThreadPool
from exapps.roller.logger import get_logger
from exapps.roller.future import Future
from exapps.roller.roll_ws import RollWebSocket
from pycryptoex.okcoin import OKEx


class RollBot(object):
    def __init__(self, **kwargs):
        self.params = kwargs
        self.ex = OKEx(kwargs['exchange'])
        self.symbol = kwargs['symbol']
        self.near = Future(self.ex, self.symbol, kwargs['near_fut'])
        self.far = Future(self.ex, self.symbol, kwargs['far_fut'])
        self.sel_offset = kwargs['sel_offset']
        self.buy_offset = kwargs['buy_offset']
        self.auto_shift = kwargs['auto_shift']
        self.qty = kwargs.get('fixed_amount', 1)
        self.open_delta_limit = kwargs.get('open_delta_limit', 3)
        self.active = True
        self.use_websocket = kwargs.get('use_websocket', False)
        self.far_ws = None
        self.near_ws = None
        self.roll_spreads = collections.deque(maxlen=200)
        atexit.register(self.exit)
        signal.signal(signal.SIGTERM, self.exit)

        self.log = get_logger(f"{self.symbol}-{self.near.contract}-{self.far.contract}", kwargs['log_dir'])
        self.near.log = self.log
        self.far.log = self.log

    def exit(self):
        try:
            self.near.cancel_open_orders()
            self.far.cancel_open_orders()
        except Exception as ex:
            self.log.error(f"unable to cancel all live orders: {ex}")
        self.active = False
        self.log.info("strategy exit")
        sys.exit()

    @property
    def buy_spread(self):
        if not self.ready:
            return 0
        return (self.far.ask - self.near.bid) / ((self.far.ask + self.near.bid) / 2)

    @property
    def sel_spread(self):
        if not self.ready:
            return 0
        return (self.far.bid - self.near.ask) / ((self.far.bid + self.near.ask) / 2)

    @property
    def mid_spread(self):
        return round((self.buy_spread + self.sel_spread) / 2, 4)

    @property
    def shift(self):
        if not self.auto_shift:
            return 0
        if len(self.roll_spreads) > 0:
            return np.mean(self.roll_spreads).round(4)
        return 0

    @property
    def ready(self):
        return self.far.ready and self.near.ready

    def quote_roll(self, quote_px, qty):
        oid = self.near.place_order(quote_px, qty)
        if oid < 0:
            self.log.warn(f"quote_roll failed.")
            return None

        time.sleep(1)
        orders = self.near.get_orders([oid])
        if oid not in orders:
            self.log.error(f"fail to find the quote order information: {oid}")
            return None

        (px, qfill) = orders[oid]
        if qfill == 0 or px == 0:
            self.log.info(f"quote order not filled. cancel it")
            self.near.cancel_orders([oid])
            return None

        return (oid, px, qfill)

    def hedge_roll(self, hedge_px, qty):
        oid = self.far.place_order(hedge_px, qty)
        if oid < 0:
            self.log.warn(f"hedge_roll failed.")
            return None

        time.sleep(1)
        orders = self.far.get_orders([oid])
        if oid not in orders:
            return None

        (px, qfill) = orders[oid]
        return (oid, px, qfill)

    def buy_roll(self, qty):
        ''' sell near(quote ask), buy far(hit ask) '''
        hedge_px = self.far.ask
        quote_px = round(hedge_px * (1 - self.shift + self.buy_offset), 3)

        qty_ = min(self.far.ask_sizes[0], self.near.bid_sizes[0]) // 2
        qty_ = min(qty, qty_)

        self.log.info(
            f"trying buy roll: near={self.near.dump_ob(1)}, far={self.far.dump_ob(1)}, shift={self.shift}, quote_px={quote_px}, hedge_px={hedge_px}")

        res = self.quote_roll(quote_px, -qty_)
        if res is not None:
            _, qpx, qqty = res
            hedge_px = round(hedge_px * 1.003, 3)
            _, hpx, hqty = self.hedge_roll(hedge_px, +qqty)
            self.log.info(f"buy roll: sell near {qqty}@{qpx} ({quote_px}), buy far {qqty}@{hpx} ({hedge_px})")

    def sel_roll(self, qty):
        ''' buy near(quote bid), sell far(hit bid) '''
        hedge_px = self.far.bid
        quote_px = round(hedge_px * (1 - self.shift - self.sel_offset), 3)

        qty_ = min(self.far.bid_sizes[0], self.near.ask_sizes[0]) // 2
        qty_ = min(qty, qty_)

        self.log.info(
            f"trying sel roll: near={self.near.dump_ob(1)}, far={self.far.dump_ob(1)}, shift={self.shift}, quote_px={quote_px}, hedge_px={hedge_px}")

        res = self.quote_roll(quote_px, qty_)
        if res is not None:
            _, qpx, qqty = res
            hedge_px = round(hedge_px * 0.997, 3)
            _, hpx, hqty = self.hedge_roll(hedge_px, -qqty)
            self.log.info(f"sel_roll: buy near {qqty}@{qpx} ({quote_px}), sell far {qqty}@{hpx} ({hedge_px})")

    def quote(self):
        if len(self.roll_spreads) < 10:
            self.log.info(f"quote|not enough data to calculate base shift, skip quoting")
            return

        self.near.update_position()
        self.near.update_open_orders()
        self.far.update_position()
        self.far.update_open_orders()
        self.log.info(f"quote|pos near={self.near.dump_pos()}, far={self.far.dump_pos()}")

        sig = self.mid_spread - self.shift
        self.log.info(f"quote|sig={sig:.4f}, base={self.shift}, [{self.buy_offset}, {self.sel_offset}]")

        if sig < -self.buy_offset:
            quota = self.open_delta_limit - abs(self.near.short)
            if quota > 0:
                qty = min(self.qty, quota)
                self.buy_roll(qty)

        if sig > self.sel_offset:
            quota = self.open_delta_limit - abs(self.near.long)
            if quota > 0:
                qty = min(self.qty, quota)
                self.sel_roll(qty)

    def run_update(self):
        freq = self.params.get('update_period', 3)
        while self.active:
            try:
                if self.use_websocket:
                    ob = self.near_ws.get_depth()
                    self.near.update_ws(ob)
                    ob = self.far_ws.get_depth()
                    self.far.update_ws(ob)
                else:
                    self.near.update()
                    self.far.update()
                if "ob_group_precise" in self.params:
                    precise = self.params['ob_group_precise']
                    depth = self.params['ob_group_depth']
                    self.near.aggregate(precise, depth)
                    self.far.aggregate(precise, depth)
                self.roll_spreads.append(self.mid_spread)
            except Exception as ex:
                self.log.error(f"update|exception: {ex}")
            time.sleep(freq)

    def run_quote(self):
        freq = self.params.get('quote_period', 10)
        while self.active:
            try:
                if self.ready:
                    self.quote()
            except Exception as ex:
                self.log.error(f"quote|exception: {ex}")
            time.sleep(freq)

    def run_sanity_check(self):
        try:
            while self.active:
                # if self.cancel_fails >= 10:
                #     raise Exception(f"cancel fails >= 10")
                # if len(self.open_orders) > self.open_delta_limit * 2:
                #     raise Exception(f"#open orders >= {self.open_delta_limit} * 2")
                delta = self.near.long + self.near.short + self.far.long + self.far.short
                if delta != 0:
                    time.sleep(10)
                    delta2 = self.near.long + self.near.short + self.far.long + self.far.short
                    if delta2 != 0:
                        raise Exception(f"imbalance delta: near={self.near.dump_pos()}, far={self.far.dump_pos()}")
                time.sleep(1)
        except Exception as ex:
            self.log.critical(ex)
            self.exit()

    def far_ws_connect(self):
        self.far_ws = RollWebSocket(self.far.symbol, self.far.contract)
        self.far_ws.log = self.log
        self.far_ws.connect()

    def near_ws_connect(self):
        self.near_ws = RollWebSocket(self.near.symbol, self.near.contract)
        self.near_ws.log = self.log
        self.near_ws.connect()

    def start(self):
        self.log.info("strategy start")
        self.active = True

        funcs = [
            self.run_update,
            self.run_quote,
            self.run_sanity_check
        ]

        if self.use_websocket:
            funcs.extend([self.far_ws_connect, self.near_ws_connect])

        pool = ThreadPool(processes=len(funcs))
        for func in funcs:
            pool.apply_async(func)

        while self.active:
            time.sleep(60)
