# sample = r"C:\Users\Alex\PycharmProjects\pycryptoex\exapps\roller\sample.xlsx"
sample = r"/Users/zhchen/PycharmProjects/pycryptoex/exapps/roller/sample.xlsx"

from datetime import datetime
import xlwings as xw

wb = xw.Book(sample)
sht = wb.sheets['btc']
sht2 = wb.sheets['ltc']

import time
from pycryptoex.okcoin import OKCoinWebSocket, OKEx, OKCoinCn, OKCoinCom, OKExLogger

spot_ex = OKCoinCn({
    'access_key': '495f84ac-3bc4-4355-821e-73cf8ddf9cfe',
    'secret_key': '9844E17C2565D78787CFF6165DF150A6'
})
fut_ex = OKEx({'access_key': 'fde59cd3-33ea-44d9-8cf9-4c5e5b8e79e1',
               'secret_key': 'A8B8F9353FC9C01D6E3B419A25582D14'})

while True:
    time.sleep(1)
    try:
        sht.range('A2').value = datetime.now()

        symbol = 'btc_usd'
        index = fut_ex.future_index(symbol)['future_index']
        sht.range('B2').value = index

        t = spot_ex.ticker('btc_cny')['ticker']
        px = (float(t['buy']) + float(t['sell'])) / 2
        sht.range('C2').value = px

        u = fut_ex.future_userinfo()
        amount = float(u['info']['btc']['account_rights'])
        sht.range('D2').value = amount

        c = spot_ex.userinfo()
        cny = float(c['info']['funds']['free']['cny']) + float(c['info']['funds']['freezed']['cny'])
        sht.range('F2').value = cny

        _maps = {'this_week': ('B', 'C'),
                 'next_week': ('D', 'E'),
                 'quarter': ('F', 'G')}

        for k, v in _maps.items():
            tick = fut_ex.future_depth(symbol, k, 5)
            asks = tick['asks']
            for i in range(5):
                try:
                    sht.range(v[0] + str(5 + i)).value = asks[i][0]
                    sht.range(v[1] + str(5 + i)).value = asks[i][1] * 100 / index
                except:
                    pass

            bids = tick['bids']
            for i in range(5):
                try:
                    sht.range(v[0] + str(10 + i)).value = bids[i][0]
                    sht.range(v[1] + str(10 + i)).value = bids[i][1] * 100 / index
                except:
                    pass

        tick = spot_ex.depth('btc_cny', 5)
        asks = tick['asks']
        for i in range(5):
            sht.range('H' + str(5 + i)).value = asks[i][0]
            sht.range('I' + str(5 + i)).value = asks[i][1]

        bids = tick['bids']
        for i in range(5):
            sht.range('H' + str(10 + i)).value = bids[i][0]
            sht.range('I' + str(10 + i)).value = bids[i][1]
    except Exception as ex:
        print(ex)

    try:
        sht2.range('A2').value = datetime.now()

        symbol = 'ltc_usd'
        index = fut_ex.future_index(symbol)['future_index']
        sht2.range('B2').value = index

        t = spot_ex.ticker('ltc_cny')['ticker']
        px = (float(t['buy']) + float(t['sell'])) / 2
        sht2.range('C2').value = px

        u = fut_ex.future_userinfo()
        amount = float(u['info']['ltc']['account_rights'])
        sht2.range('D2').value = amount

        _maps = {'this_week': ('B', 'C'),
                 'next_week': ('D', 'E'),
                 'quarter': ('F', 'G')}

        for k, v in _maps.items():
            tick = fut_ex.future_depth(symbol, k, 5)
            asks = tick['asks']
            for i in range(5):
                try:
                    sht2.range(v[0] + str(5 + i)).value = asks[i][0]
                    sht2.range(v[1] + str(5 + i)).value = asks[i][1] * 100 / index
                except:
                    pass

            bids = tick['bids']
            for i in range(5):
                try:
                    sht2.range(v[0] + str(10 + i)).value = bids[i][0]
                    sht2.range(v[1] + str(10 + i)).value = bids[i][1] * 100 / index
                except:
                    pass

        tick = spot_ex.depth('ltc_cny', 5)
        asks = tick['asks']
        for i in range(5):
            sht2.range('H' + str(5 + i)).value = asks[i][0]
            sht2.range('I' + str(5 + i)).value = asks[i][1]

        bids = tick['bids']
        for i in range(5):
            sht2.range('H' + str(10 + i)).value = bids[i][0]
            sht2.range('I' + str(10 + i)).value = bids[i][1]
    except Exception as ex:
        print(ex)
