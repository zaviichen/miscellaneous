import math
from pycryptoex.okcoin import OKEx


class Future(object):
    def __init__(self, ex, symbol, contract, depth=50):
        self.ex = ex
        self.ws = None
        self.symbol = symbol
        self.contract = contract
        self.depth = depth
        self.ask_prices = []
        self.bid_prices = []
        self.ask_sizes = []
        self.bid_sizes = []
        self.ask_amounts = []
        self.bid_amounts = []
        self.long = 0
        self.short = 0
        self.open_orders = []
        self.log = None

    @property
    def ask(self):
        return self.ask_prices[0] if len(self.ask_prices) > 0 else 0

    @property
    def bid(self):
        return self.bid_prices[0] if len(self.bid_prices) > 0 else 0

    @property
    def spread(self):
        if not self.ready:
            return 0
        return (self.ask - self.bid) / (self.ask * 0.5 + self.bid * 0.5)

    @property
    def ready(self):
        return self.ask > 0 and self.bid > 0

    def reset(self):
        self.ask_prices.clear()
        self.bid_prices.clear()
        self.ask_sizes.clear()
        self.bid_sizes.clear()
        self.ask_amounts.clear()
        self.bid_amounts.clear()

    def allocate(self, depth):
        self.ask_sizes = [0.] * depth
        self.ask_prices = [0.] * depth
        self.ask_amounts = [0.] * depth
        self.bid_sizes = [0.] * depth
        self.bid_prices = [0.] * depth
        self.bid_amounts = [0.] * depth

    def update(self):
        ob = self.ex.future_depth(self.symbol, self.contract, self.depth)
        self.reset()

        asks = ob['asks']
        for i in range(len(asks) - 1, -1, -1):
            self.ask_prices.append(asks[i][0])
            self.ask_sizes.append(asks[i][1])

        bids = ob['bids']
        for i in range(len(bids)):
            self.bid_prices.append(bids[i][0])
            self.bid_sizes.append(bids[i][1])
        return ob

    def update_ws(self, ob):
        if ob is None:
            return
        self.reset()

        asks = ob['asks']
        for i in range(len(asks) - 1, -1, -1):
            self.ask_prices.append(float(asks[i][0]))
            self.ask_sizes.append(float(asks[i][1]))
            self.ask_amounts.append(float(asks[i][2]))

        bids = ob['bids']
        for i in range(len(bids)):
            self.bid_prices.append(float(bids[i][0]))
            self.bid_sizes.append(float(bids[i][1]))
            self.bid_amounts.append(float(bids[i][2]))

    class AggItem(object):
        def __init__(self):
            self.boundary = 0
            self.avgprc = 0
            self.qty = 0

    @staticmethod
    def internal_agg(prices, sizes, precise, is_lower):
        if len(prices) != len(sizes):
            raise Exception("agg error: len(prices)!=len(sizes)")

        factor = 1.0 / precise
        dic = {}
        for i in range(len(prices)):
            if is_lower:
                px = math.floor(prices[i] * factor) / factor
            else:
                px = math.ceil(prices[i] * factor) / factor
            if px not in dic:
                dic[px] = []
            dic[px].append((prices[i], sizes[i]))

        ob = []
        for k, v in dic.items():
            item = Future.AggItem()
            item.boundary = k
            item.qty = round(sum(e[1] for e in v), 4)
            val = sum(e[0] * e[1] for e in v)
            item.avgprc = round(val / item.qty, 3)
            ob.append(item)
        return ob

    def aggregate(self, precise, depth, use_avgprc=True):
        asks = Future.internal_agg(self.ask_prices, self.ask_sizes, precise, False)[:depth]
        bids = Future.internal_agg(self.bid_prices, self.bid_sizes, precise, True)[:depth]

        self.reset()
        self.allocate(depth)

        for i in range(len(asks)):
            self.ask_prices[i] = asks[i].avgprc if use_avgprc else asks[i].boundary
            self.ask_sizes[i] = asks[i].qty

        for i in range(len(bids)):
            self.bid_prices[i] = bids[i].avgprc if use_avgprc else bids[i].boundary
            self.bid_sizes[i] = bids[i].qty

    def dump_ob(self, depth=100):
        ask_str = []
        n = min(depth, len(self.ask_prices))
        for i in range(n):
            ask_str.append(f'({self.ask_prices[i]},{self.ask_sizes[i]})')
        bid_str = []
        n = min(depth, len(self.bid_prices))
        for i in range(n):
            bid_str.append(f'({self.bid_prices[i]},{self.bid_sizes[i]})')
        return ','.join(reversed(ask_str)) + '|' + ','.join(bid_str)

    def update_position(self):
        rsp = None
        try:
            rsp = self.ex.future_position(self.symbol, self.contract)
            if rsp['result']:
                if len(rsp['holding']) > 0:
                    p = rsp['holding'][0]
                    self.long = int(p['buy_amount'])
                    self.short = -1 * int(p['sell_amount'])
                else:
                    self.long = self.short = 0
        except Exception as ex:
            self.log.error("get_position error: ", rsp)
            raise ex

    def update_open_orders(self):
        x = self.ex.future_order_info(self.symbol, self.contract, "1")
        orders = []
        if x is not None:
            for e in x['orders']:
                self.log.info(f'\topen: {e}')
                orders.append(e)
        self.open_orders = orders

    def order_side(self, order):
        type_ = int(order['type'])
        return 'B' if type_ == 1 or type_ == 4 else 'S'

    def order_qopen(self, order):
        side = self.order_side(order)
        sign = 1 if side == 'B' else -1
        qty = int(order['amount'])
        qdone = int(order['deal_amount'])
        qopen = qty - qdone
        return sign * qopen

    @property
    def open_long(self):
        qopens = [self.order_qopen(o) for o in self.open_orders]
        return sum(q for q in qopens if q > 0)

    @property
    def open_short(self):
        qopens = [self.order_qopen(o) for o in self.open_orders]
        return sum(q for q in qopens if q < 0)

    def place_order(self, price, amount):
        if amount > 0:
            type = OKEx.OrderTypes.OpenLong
            if abs(self.short) - self.open_long >= amount:
                type = OKEx.OrderTypes.CloseShort
        else:
            amount = abs(amount)
            type = OKEx.OrderTypes.OpenShort
            if self.long - abs(self.open_short) >= amount:
                type = OKEx.OrderTypes.CloseLong

        type_str = OKEx.OrderTypes.to_str(type)
        self.log.info(f"place order: {self.symbol}, {self.contract}, {type_str} {amount} @ {price}")

        rsp = self.ex.future_trade(self.symbol, self.contract, type, price, amount)
        try:
            order_id = int(rsp['order_id'])
            self.log.info(f"place order: success, order_id={order_id}")
            return order_id
        except Exception as ex:
            self.log.error(f"place order: {rsp}, {ex}")
            return -1

    def place_order2(self, price, amount):
        isbuy = amount > 0
        amount = abs(amount)
        oids = []

        def _place(type, qty, px):
            type_str = OKEx.OrderTypes.to_str(type)
            self.log.info(f"place order: {self.symbol}, {self.contract}, {type_str} {qty} @ {px}")
            rsp = self.ex.future_trade(self.symbol, self.contract, type, px, qty)
            try:
                order_id = int(rsp['order_id'])
                self.log.info(f"place order: success, order_id={order_id}")
                return order_id
            except Exception as ex:
                self.log.error(f"place order: {rsp}, {ex}")
                return -1

        if isbuy:
            if self.short < 0:
                qty = min(abs(self.short), amount)
                oids.append(_place(OKEx.OrderTypes.CloseShort, price, qty))
                if amount - qty > 0:
                    oids.append(_place(OKEx.OrderTypes.OpenLong, price, amount - qty))
            else:
                oids.append(_place(OKEx.OrderTypes.OpenLong, price, amount))
        else:
            if self.long > 0:
                qty = min(self.long, amount)
                oids.append(_place(OKEx.OrderTypes.CloseLong, price, qty))
                if amount - qty > 0:
                    oids.append(_place(OKEx.OrderTypes.OpenShort, price, amount - qty))
            else:
                oids.append(_place(OKEx.OrderTypes.OpenShort, price, amount))
        return oids

    def cancel_orders(self, order_ids):
        self.log.info(f"cancel order: {self.contract}, {','.join(str(o) for o in order_ids)}")
        while len(order_ids) > 0:
            oids = order_ids[:3]
            order_ids = order_ids[3:]
            rsp = self.ex.future_cancel(self.symbol, self.contract, oids)
            self.log.info(f"cancel order response: {rsp}")

    def get_open_orders(self):
        x = self.ex.future_order_info(self.symbol, self.contract, "1")
        orders = []
        if x is not None:
            for e in x['orders']:
                self.log.info(f'\topen: {e}')
                orders.append(e)
        return orders

    def cancel_open_orders(self):
        orders = self.get_open_orders()
        order_ids = [o['order_id'] for o in orders]
        if len(order_ids) > 0:
            self.cancel_orders(order_ids)

    def get_orders(self, order_ids):
        orders = {}
        if len(order_ids) > 0:
            x = self.ex.future_orders_info(self.symbol, self.contract, order_ids)
            for e in x['orders']:
                status = int(e['status'])
                id = int(e['order_id'])
                if status == 0:
                    self.log.info(f"\topen: {e}")
                    orders[id] = (0, 0)
                elif status == 1 or status == 2:
                    self.log.info(f"\tfill: {e}")
                    orders[id] = (float(e['price_avg']), float(e['deal_amount']))
                elif status == 4 or status == -1:
                    self.log.info(f"\tcancel: {e}")
                    orders[id] = (0, 0)
                else:
                    self.log.warn(f"\tunknown order status: {status}, {e}")
        return orders

    def dump_pos(self):
        return f'{self.long}({self.open_long})/{self.short}({self.open_short})'
