import logging
from logging.handlers import TimedRotatingFileHandler


def get_logger(name, dir):
    file = f"{dir}/{name}.log"
    log = logging.getLogger(name)
    fmt = logging.Formatter("%(asctime)s|%(levelname)s|%(message)s")

    handler = TimedRotatingFileHandler(file, when='midnight')
    handler.setFormatter(fmt)
    log.addHandler(handler)

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    log.addHandler(console)

    # log.setLevel(logging.INFO)
    log.setLevel(logging.DEBUG)
    return log
