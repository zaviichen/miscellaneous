import logging

logging.basicConfig(level=logging.INFO)
log = logging.getLogger('test')

import pytest
import time
from collections import namedtuple

from pycryptoex.okcoin.okspot import OKCoinCn, OKCoinCom
from pycryptoex.okcoin.okex import OKEx

OKSpotCase = namedtuple('OKSpotCase', ['ex', 'symbol'])
spot_cases = [
    OKSpotCase(ex=OKCoinCn({'access_key': '495f84ac-3bc4-4355-821e-73cf8ddf9cfe',
                            'secret_key': '9844E17C2565D78787CFF6165DF150A6'}),
               symbol='ltc_cny'),
    # OKSpotCase(ex=OKCoinCom({'access_key': 'fde59cd3-33ea-44d9-8cf9-4c5e5b8e79e1',
    #                          'secret_key': 'A8B8F9353FC9C01D6E3B419A25582D14'}),
    #            symbol='ltc_usd'),
]

OKExCase = namedtuple('OKExCase', ['ex', 'symbol', 'contract'])
fut_cases = [
    # OKExCase(ex=OKEx({'access_key': 'fde59cd3-33ea-44d9-8cf9-4c5e5b8e79e1',
    #                   'secret_key': 'A8B8F9353FC9C01D6E3B419A25582D14'}),
    #          symbol='btc_usd', contract='this_week'),
    OKExCase(ex=OKEx({'access_key': '04ac9a41-b37d-4670-8dcc-1770b56dd085',
                      'secret_key': 'E5648DEDC801FF5CF671B35B85417E76'}),
             symbol='ltc_usd', contract='next_week'),
]


@pytest.mark.parametrize('x', spot_cases)
class TestOKSpot(object):
    def test_ticker(self, x):
        v = x.ex.ticker(x.symbol)
        log.info(f"{x.ex.name}.ticker: {v}")
        assert v

    def test_depth(self, x):
        v = x.ex.depth(x.symbol)
        log.info(f"{x.ex.name}.depth: {v}")
        assert v

    def test_trades(self, x):
        v = x.ex.trades(x.symbol)
        log.info(f"{x.ex.name}.trades: {v}")
        assert v

    def test_userinfo(self, x):
        v = x.ex.userinfo()
        log.info(f"{x.ex.name}.test_userinfo: {v}")
        assert v

    def test_trade(self, x):
        ex = x.ex
        symbol = x.symbol

        ob = ex.depth(symbol, 10)
        bp = ob['bids'][-1][0]

        rsp = ex.trade(symbol, "buy", bp, 0.1)
        order_id = int(rsp['order_id'])
        log.info(f"trade: {rsp}")

        info = ex.order_info(symbol, order_id)
        log.info(f"order_info: {info}")

        rsp = ex.cancel_order(symbol, [order_id])
        log.info(f"cancel_order: {rsp}")

    def test_withdraw(self, x):
        v = x.ex.withdraw(x.symbol, 0, "Zaviichen4866", "zhihui.chen.4866@gmail.com", 0.1, "okex")
        log.info(f"{x.ex.name}.withdraw: {v}")

        id = str(v['withdraw_id'])
        info = x.ex.withdraw_info(x.symbol, id)
        log.info(f"{x.ex.name}.withdraw_info: {info}")

        time.sleep(10)
        info = x.ex.withdraw_info(x.symbol, id)
        log.info(f"{x.ex.name}.withdraw_info: {info}")
        assert v

@pytest.mark.parametrize('x', fut_cases)
class TestOKEx(object):
    def test_ticker(self, x):
        v = x.ex.future_ticker(x.symbol, x.contract)
        log.info(f"{x.ex.name}.future_ticker: {v}")
        assert v

    def test_future_depth(self, x):
        v = x.ex.future_depth(x.symbol, x.contract)
        log.info(f"{x.ex.name}.future_depth: {v}")
        assert v

    def test_future_trades(self, x):
        v = x.ex.future_trades(x.symbol, x.contract)
        log.info(f"{x.ex.name}.future_trades: {v}")
        assert v

    def test_future_index(self, x):
        v = x.ex.future_index(x.symbol)
        log.info(f"{x.ex.name}.future_index: {v}")
        assert v

    def test_exchange_rate(self, x):
        v = x.ex.exchange_rate()
        log.info(f"{x.ex.name}.exchange_rate: {v}")
        assert v

    def test_future_estimated_price(self, x):
        v = x.ex.future_estimated_price(x.symbol)
        log.info(f"{x.ex.name}.future_estimated_price: {v}")
        assert v

    def test_future_hold_amount(self, x):
        v = x.ex.future_hold_amount(x.symbol, x.contract)
        log.info(f"{x.ex.name}.future_hold_amount: {v}")
        assert v

    def test_future_price_limit(self, x):
        v = x.ex.future_price_limit(x.symbol, x.contract)
        log.info(f"{x.ex.name}.future_price_limit: {v}")
        assert v

    def test_future_userinfo(self, x):
        v = x.ex.future_userinfo()
        log.info(f"{x.ex.name}.future_userinfo: {v}")
        assert v

    def test_future_position(self, x):
        v = x.ex.future_position(x.symbol, x.contract)
        log.info(f"{x.ex.name}.future_position: {v}")
        assert v

    def test_future_trade(self, x):
        ex = x.ex
        symbol = x.symbol
        contract = x.contract

        ob = ex.future_depth(symbol, contract, 10)
        bp = ob['bids'][-1][0]

        rsp = ex.future_trade(symbol, contract, OKEx.OrderTypes.OpenLong, bp, 1)
        order_id = int(rsp['order_id'])
        log.info(f"future_trade: {rsp}")

        info = ex.future_orders_info(symbol, contract, [order_id])
        log.info(f"future_orders_info: {info}")

        rsp = ex.future_cancel(symbol, contract, [order_id])
        log.info(f"future_cancel: {rsp}")

    def test_future_open_orders(self, x):
        v = x.ex.future_order_info(x.symbol, x.contract, "1")
        log.info(f"{x.ex.name}.future_order_info: {v}")
        assert v

    def test_future_devolve(self, x):
        v = x.ex.future_devolve(x.symbol, "1", 0.01)
        log.info(f"{x.ex.name}.future_devolve: {v}")
        assert v

    def test_withdraw(self, x):
        v = x.ex.withdraw(x.symbol, 0, "Zaviichen4866", "zaviichen@gmail.com", 0.1, "okcom")
        log.info(f"{x.ex.name}.withdraw: {v}")

        id = str(v['withdraw_id'])
        info = x.ex.withdraw_info(x.symbol, id)
        log.info(f"{x.ex.name}.withdraw_info: {info}")

        time.sleep(10)
        info = x.ex.withdraw_info(x.symbol, id)
        log.info(f"{x.ex.name}.withdraw_info: {info}")
        assert v
