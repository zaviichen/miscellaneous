import logging

logging.basicConfig(level=logging.INFO)
log = logging.getLogger('test')

import pytest
from collections import namedtuple

from pycryptoex.bitmex import BitMEX

BitMEXCase = namedtuple('BitMEXCase', ['ex', 'symbol'])
cases = [
    BitMEXCase(ex=BitMEX({'access_key': 'YQN-ucsFm_ji5FKSx6lXKSR6',
                          'secret_key': '6nfBUn8ox-E8YE1nmnrMrbjQpXmJZNlK8djRH_luWprI5zoP'}),
               symbol='XBTUSD'),
]


@pytest.mark.parametrize('x', cases)
class TestBitMEX(object):
    def test_quote(self, x):
        v = x.ex.quote(x.symbol)
        log.info(f"{x.ex.name}.quote: {v}")
        assert v

    def test_orderbook(self, x):
        v = x.ex.json_to_orderbook(x.symbol)
        log.info(f"{x.ex.name}.orderbook: {v}")
        assert v

    def test_trade(self, x):
        v = x.ex.trade(x.symbol)
        log.info(f"{x.ex.name}.trade: {v}")
        assert v

    def test_instrument(self, x):
        v = x.ex.instrument(symbol=None, start=0, count=2)
        log.info(f"{x.ex.name}.instrument: {v}")
        assert v

    def test_instrument_active(self, x):
        v = x.ex.instrument_active()
        log.info(f"{x.ex.name}.instrument_active: {v}")
        assert v

    def test_instrument_indices(self, x):
        v = x.ex.instrument_indices()
        log.info(f"{x.ex.name}.instrument_indices: {v}")
        assert v

    def test_instrument_active_and_indices(self, x):
        v = x.ex.instrument_active_and_indices()
        log.info(f"{x.ex.name}.instrument_active_and_indices: {v}")
        assert v

    def test_position(self, x):
        v = x.ex.position()
        log.info(f"{x.ex.name}.position: {v}")
        assert (v is not None)

    def test_order(self, x):
        v = x.ex.order(symbol=None, start=0, count=2)
        log.info(f"{x.ex.name}.order: {v}")
        assert (v is not None)

    def test_place_order(self, x):
        ex = x.ex
        symbol = x.symbol

        ob = ex.json_to_orderbook(symbol, 100)
        bp = ob[-1]['price']

        rsp = ex.place_order(symbol, bp, 1)
        log.info(f"place_order: {rsp}")

        orders = ex.open_orders(symbol)
        order_ids = [o['orderID'] for o in orders]
        log.info(f"open_orders: {order_ids}")

        rsp = ex.cancel_order(order_ids)
        log.info(f"cancel_order: {rsp}")
