from __future__ import absolute_import
from time import sleep
import sys
from datetime import datetime
from os.path import getmtime
import random
import requests
import atexit
import signal
import dateutil
import math
from market_maker.indicator import tightOb
import numpy as np

from market_maker import bitmex
from market_maker.settings import settings
from market_maker.utils import log, constants, errors, exchange


def XBt_to_XBT(XBt):
    return float(XBt) / constants.XBt_TO_XBT
def XBT_to_XBt(XBT):
    return float(XBT) * constants.XBt_TO_XBT


def cost(instrument, quantity, price):
    mult = instrument["multiplier"]
    P = mult * price if mult >= 0 else mult / price
    return abs(quantity * P)

def margin(instrument, quantity, price):
    return cost(instrument, quantity, price) * instrument["initMargin"]

def contractsToXBT(instrument, contracts):
    if instrument['isInverse'] and not instrument['isQuanto']:
        return -contracts/(XBt_to_XBT(instrument['multiplier'])*instrument['markPrice'])
    elif not instrument['isInverse'] and instrument['isQuanto']:
        return -XBt_to_XBT(instrument["multiplier"])*(contracts * instrument['markPrice'])
    else:
        raise("unknown contractsToXBT instrument type %s", instrument['symbol'])
    return 0.0

def XBTToContracts(instrument, XBT):
    if instrument['isInverse'] and not instrument['isQuanto']:
        return math.floor(-XBT*instrument['markPrice']*XBt_to_XBT(instrument['multiplier']))
    elif not instrument['isInverse'] and instrument['isQuanto']:
        return math.floor(XBT_to_XBt(instrument["multiplier"])/instrument['markPrice'])
    else:
        raise("unknown XBTToContracts instrument type %s", instrument['symbol'])
    return 0.0

def roundToTick(price, tickSize, tickLog, how="near"):
    if how=="near":
        return round(round(price/tickSize)*tickSize, tickLog)
    elif how=="up":
        return round(math.ceil(price/tickSize)*tickSize, tickLog)
    elif how=="down":
        return round(math.floor(price/tickSize)*tickSize, tickLog)

# def roundToTick(price, tickSize, tickLog, how="near"):
#     if how=="near":
#         return np.round(np.round(np.divide(price, tickSize))*tickSize, tickLog)
#     elif how=="up":
#         return np.round(np.ceil(np.divide(price, tickSize))*tickSize, tickLog)
#     elif how=="down":
#         return np.round(np.floor(np.divide(price, tickSize))*tickSize, tickLog)
