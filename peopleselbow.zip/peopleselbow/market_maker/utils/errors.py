class AuthenticationError(Exception):
    pass

class MarketClosedError(Exception):
    pass

class MarketEmptyError(Exception):
    pass
