import logging
from market_maker.settings import settings
import datetime


def setup_custom_logger(name):
    formatter = logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(module)s - %(message)s')

    handler = logging.StreamHandler()
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(settings.LOG_LEVEL)
    logger.addHandler(handler)

    dir = logging.FileHandler(datetime.datetime.now().strftime("./logs/log_%Y%m%d_%H%M%S.log"))
    logger.addHandler(dir)
    return logger
