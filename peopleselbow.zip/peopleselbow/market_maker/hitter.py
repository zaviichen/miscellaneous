from __future__ import absolute_import
from time import sleep
import sys
from datetime import datetime
from datetime import datetime, time
import traceback

from os.path import getmtime
import time
import random
import requests
import atexit
import signal
import dateutil
import numpy as np
import pandas as pd
from market_maker.indicator import tightOb
from market_maker import bitmex
from market_maker.settings import settings
from market_maker.utils import log, constants, errors, exchange
from market_maker.utils.utils import *
import apikey

# Used for reloading the bot - saves modified times of key files
import os
watched_files_mtimes = [(f, getmtime(f)) for f in settings.WATCHED_FILES]


#
# Helpers
#
logger = log.setup_custom_logger('root')


class HitterStrat:
    def __init__(self):
        self.exchange = exchange.ExchangeInterface(settings.DRY_RUN)
        # Once exchange is created, register exit handler that will always cancel orders
        # on any error.
        atexit.register(self.exit)
        signal.signal(signal.SIGTERM, self.exit)
        self.lastOrderTime = 0
        self.lastOrderBuyTime = 0
        self.lastOrderSellTime = 0
        logger.info("Using symbol %s." % self.exchange.symbol)
        self.orderFile = None
        self.lastPrintTime = 0
    def init(self):
        if settings.DRY_RUN:
            logger.info("Initializing dry run. Orders printed below represent what would be posted to BitMEX.")
        else:
            logger.info("Order Manager initializing, connecting to BitMEX. Live run: executing real trades.")

        self.start_time = datetime.now()
        self.instrument = self.exchange.get_instrument()
        self.starting_qty = self.exchange.get_delta()
        self.running_qty = self.starting_qty
        self.alphas = tightOb.hitterAlphas(self.exchange)

        self.reset()
        if settings.testNet:
            self.orderFile = open(datetime.now().strftime("./logs/UAT_" + settings.SYMBOL + "_order_%Y%m%d_%H%M%S.csv"), "a")
        else:
            self.orderFile = open(datetime.now().strftime("./logs/PROD_" + settings.SYMBOL + "_order_%Y%m%d_%H%M%S.csv"), "a")
        header = "symbol,date,time,price,qty,bidPx,askPx,bidSz,askSz,idx,idxrate,TotAlpha"
        for alpha in self.alphas:
            header += ",ALPHA_"+alpha.getName()
        self.orderFile.write(header+"\n")
        self.orderFile.flush()

    def reset(self):
        self.exchange.cancel_all_orders()
        self.sanity_check()
        self.print_status()
        if not self.orderFile is None:
            self.orderFile.close()
            self.orderFile = None

    def alphaVal(self, print=False):
        curString = "Alpha: "
        alphaVal = 0.0
        for alpha in self.alphas:
            val = alpha.compute(self.exchange.symbol)
            alphaVal += val
            curString += alpha.getName() + " %0.2f, " % (val*1e4)
        alphaVal = np.clip(alphaVal, -settings.TOTAL_ALPHA_CAP, settings.TOTAL_ALPHA_CAP)
        if print:
            curString += "Tot %0.2f"%(alphaVal*1e4)
            logger.info(curString)
        return alphaVal

    def print_status(self):
        """Print the current MM status."""
        self.alphaVal(print=True)
        if self.lastPrintTime + 3 > time.time():
            return
        logger.info("-----")
        instrument = self.exchange.get_instrument()
        margin = self.exchange.get_margin()
        position = self.exchange.get_position()
        self.running_qty = self.exchange.get_delta()
        self.start_XBt = margin["marginBalance"]
        ob = self.exchange.get_ob()
        lastTickTime = dateutil.parser.parse(ob['timestamp'][0]).timestamp()
        logger.info("Last time %s, %0.fsecs ago"%(ob['timestamp'][0], datetime.now().timestamp() - lastTickTime))
        logger.info("%s bid/ask %0.*f (%0.f)/ %0.*f(%0.f)"%(self.exchange.symbol, \
                                                           instrument['tickLog'], ob['bidPrice'][0], ob['bidSize'][0], \
                                                            instrument['tickLog'], ob['askPrice'][0], ob['askSize'][0]))

        logger.info("Current XBT Funds/Balance: %.3f/%0.3f" % (XBt_to_XBT(self.start_XBt), XBt_to_XBT(margin["walletBalance"])))
        logger.info("Current Contract Position: %d" % self.running_qty)
        if position['currentQty'] != 0:
            logger.info("Avg Cost Price: %.2f" % float(position['avgCostPrice']))
            logger.info("Avg Entry Price: %.2f" % float(position['avgEntryPrice']))
        logger.info("Contracts / XBT Traded This Run: %d / %d " % (self.running_qty - self.starting_qty, contractsToXBT(instrument , self.running_qty - self.starting_qty)))
        logger.info("Total Contract Delta: %0.4f XBT" % self.exchange.calc_delta()['spot'])
        logger.info("Net unrealized, realized, total XBT pnl %0.2f / %0.2f / %0.2f"% \
                    ( XBt_to_XBT(position['unrealisedPnl']),  XBt_to_XBT(position['realisedPnl']),  \
                      XBt_to_XBT(position['unrealisedPnl']+position['unrealisedPnl'])))
        logger.info("-----")
        self.lastPrintTime = time.time()



    def decision(self):
        if self.lastOrderTime + settings.MAX_ORDER_INTERVAL_SEC > time.time():
            return

        try:
            alpha = self.alphaVal()
            instrument = self.exchange.get_instrument()
            spread = (instrument['askPrice']-instrument['bidPrice'])/instrument['midPrice']
            takerFeeBps = instrument['takerFee']
            buyProfit = alpha - spread/2.0 - takerFeeBps
            sellProfit = -alpha - spread/2.0 - takerFeeBps

            delta = self.exchange.calc_delta()['mark_price']
            posContracts = self.exchange.get_delta()
            if buyProfit > settings.PROFIT_MARGIN and self.lastOrderBuyTime + settings.MAX_BUY_ORDER_INTERVAL_SEC < time.time():
                orderPx = instrument['midPrice'] * (1.0+min(spread/2.0 + buyProfit- settings.PROFIT_MARGIN, settings.MAX_ORDER_AGGRESS_BPS))
                orderPx = roundToTick(orderPx, 10**-instrument['tickLog'], instrument['tickLog'], "down")
                orderSz = self.getDepthFromPrice(orderPx)
                orderSz = min(orderSz, settings.MAX_CONTRACTS_PER_ORDER)
                maxDeltaContract = max(0, XBTToContracts( instrument, settings.MAX_XBT_POSITION - delta))
                orderSz = min(orderSz, maxDeltaContract)
                orderSz = min(orderSz, max(0, settings.MAX_POSITION-posContracts))
                orderSz = max(0, orderSz)
                self.place_order(orderPx, orderSz, "ImmediateOrCancel")

            elif sellProfit > settings.PROFIT_MARGIN and self.lastOrderSellTime + settings.MAX_SELL_ORDER_INTERVAL_SEC < time.time():
                orderPx = instrument['midPrice'] * (1.0-min(sellProfit - settings.PROFIT_MARGIN + spread/2.0, settings.MAX_ORDER_AGGRESS_BPS))
                orderPx = roundToTick(orderPx, 10 ** -instrument['tickLog'], instrument['tickLog'], "up")
                orderSz = self.getDepthFromPrice(orderPx)
                orderSz = min(orderSz, settings.MAX_CONTRACTS_PER_ORDER)
                maxDeltaContract = max(0, XBTToContracts(instrument, -settings.MIN_XBT_POSITION + delta))
                orderSz = min(orderSz, maxDeltaContract)
                orderSz = min(orderSz, max(0, -settings.MIN_POSITION + posContracts))
                orderSz = max(0, orderSz)
                self.place_order(orderPx, -orderSz, "ImmediateOrCancel")
        except:
            logger.warning("unexpected error in hitter decision: %s", sys.exc_info()[0])
            logger.error(traceback.format_exc())


    def getDepthFromPrice(self, orderPx):
        ob = self.exchange.get_ob(self.exchange.symbol)
        if len(ob) <= 0:
            logger.warning("empty ob while trading getDepthFromPrice")
            return 0
        mid = (ob['bidPrice'][0] + ob['askPrice'][0]) /2.0
        if orderPx > mid:
            return np.sum(ob['askSize'][orderPx >= ob['askPrice']])
        else:
            return np.sum(ob['bidSize'][orderPx <= ob['bidPrice']])
    ###
    # Orders
    ###

    def place_order(self, px, size, timeInForce="GoodTillCancel"):
        if size == 0 or not np.isfinite(size):
            return
        if px <= 0 or not np.isfinite(px):
            return

        now = datetime.now()
        seconds_since_midnight = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()

        self.lastOrderTime = time.time()
        if size > 0:
            self.lastOrderBuyTime = self.lastOrderTime
        else:
            self.lastOrderSellTime = self.lastOrderTime

        self.exchange.place_order(px, size, timeInForce)
        instrument = self.exchange.get_instrument()
        ob = self.exchange.get_ob()
        logger.info("********* Creating %s order %0.f @ %.*f **************" % (timeInForce, size, instrument['tickLog'], px))
        #self.orderFile.write("self.exchange,date,time,price,qty,alpha,bidPx,askPx,bidSz,askSz")
        formatter = "%s,%s,%0.5f,%0.*f,%0.f,%0.*f,%0.*f,%0.f,%0.f,%.*f,%0.5f,%0.5f"%\
                             (self.exchange.symbol, now.strftime("%Y%m%d"), seconds_since_midnight, instrument['tickLog'], px, size, \
                             instrument['tickLog'], ob['bidPrice'][0], instrument['tickLog'], \
                              ob['askPrice'][0], ob['bidSize'][0], ob['askSize'][0], instrument['tickLog'], instrument['indicativeSettlePrice'], \
                              instrument['fundingRate'], self.alphaVal())
        for alpha in self.alphas:
            formatter +=",%0.5f"%alpha.compute(self.exchange.symbol)
        formatter +="\n"
        self.orderFile.write(formatter)
        self.orderFile.flush()

    ###
    # Position Limits
    ###

    def short_position_limit_exceeded(self):
        "Returns True if the short position limit is exceeded"
        if not settings.CHECK_POSITION_LIMITS:
            return False
        position = self.exchange.get_delta()
        xbtDelta = self.exchange.calc_delta()
        return position <= settings.MIN_POSITION-0.01 or xbtDelta['mark_price'] <= settings.MIN_XBT_POSITION-0.01

    def long_position_limit_exceeded(self):
        "Returns True if the long position limit is exceeded"
        if not settings.CHECK_POSITION_LIMITS:
            return False
        position = self.exchange.get_delta()
        xbtDelta = self.exchange.calc_delta()

        return position >= settings.MAX_POSITION+0.01 or xbtDelta['mark_price'] >= settings.MAX_XBT_POSITION+0.01

    def pnl_limit_exceeded(self):
        if not settings.CHECK_POSITION_LIMITS:
            return False
        pnl = XBt_to_XBT(self.exchange.get_pnl())
        return pnl < settings.STOP_LOST_XBT

    ###
    # Sanity
    ##

    def sanity_check(self):
        """Perform checks before placing orders."""
        now = datetime.now()
        seconds_since_midnight = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()

        if seconds_since_midnight >= 23*3600+59*60+50:
            logger.info("Almost midnight, restart after midnight")
            raise errors.MarketClosedError("Time passed")
            sys.exit()

        # Check if OB is empty - if so, can't quote.
        self.exchange.check_if_orderbook_empty()

        # Ensure market is still open.
        self.exchange.check_market_open()

        # Messanging if the position limits are reached
        if self.long_position_limit_exceeded():
            logger.info("Long delta limit exceeded")
            logger.info("Current Position: %.f, Maximum Position: %.f" %
                        (self.exchange.get_delta(), settings.MAX_POSITION))
            raise errors.MarketClosedError("Long delta limit exceeded")
            sys.exit()

        if self.short_position_limit_exceeded():
            logger.info("Short delta limit exceeded")
            logger.info("Current Position: %.f, Minimum Position: %.f" %
                        (self.exchange.get_delta(), settings.MIN_POSITION))
            raise errors.MarketClosedError("short delta limit exceeded")
            sys.exit()

        if self.pnl_limit_exceeded():
            logger.info("pnl_limit_exceeded")
            logger.info("Current pnl: %.2f, kill at: %.2f" %
                        (XBt_to_XBT(self.exchange.get_pnl()), settings.STOP_LOST_XBT))
            raise errors.MarketClosedError("pnl limit exceeded")
            sys.exit()

        self.exchange.calc_delta()

    ###
    # Running
    ###

    def check_file_change(self):
        """Restart if any files we're watching have changed."""
        for f, mtime in watched_files_mtimes:
            if getmtime(f) > mtime:
                self.restart()

    def check_connection(self):
        """Ensure the WS connections are still open."""
        return self.exchange.is_open()

    def exit(self):
        logger.info("Shutting down. All open orders will be cancelled.")
        try:
            self.exchange.cancel_all_orders()
            self.exchange.bitmex.exit()
        except errors.AuthenticationError as e:
            logger.info("Was not authenticated; could not cancel orders.")
        except Exception as e:
            logger.info("Unable to cancel orders: %s" % e)

        sys.exit()

    def run_loop(self):
        while True:
            sys.stdout.flush()

            self.check_file_change()
            sleep(settings.LOOP_INTERVAL)

            # This will restart on very short downtime, but if it's longer,
            # the MM will crash entirely as it is unable to connect to the WS on boot.
            if not self.check_connection():
                logger.error("Realtime data connection unexpectedly closed, restarting.")
                self.restart()

            self.sanity_check()  # Ensures health of mm - several cut-out points here
            self.print_status()  # Print skew, delta, etc
            self.decision()

    def restart(self):
        logger.info("Restarting the hitter...")
        #os.execv(sys.executable, [sys.executable] + sys.argv)

#
# Helpers
#




def run():
    logger.info('Ob hitter Version: %s\n' % constants.VERSION)
    apikey.updateSettingsKeys()
    om = HitterStrat()
    # Try/except just keeps ctrl-c from printing an ugly stacktrace
    try:
        om.init()
        om.run_loop()
    except (KeyboardInterrupt, SystemExit):
        sys.exit()
