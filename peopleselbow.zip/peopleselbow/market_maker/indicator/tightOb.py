from __future__ import absolute_import
import pandas as pd
import numpy as np
from time import sleep
import sys
from datetime import datetime
from os.path import getmtime
import random
import requests
import atexit
import signal
import dateutil
import abc
from abc import ABC, ABCMeta, abstractmethod
from operator import add
from datetime import datetime,timezone

from market_maker import bitmex
from market_maker.settings import settings
from market_maker.utils import log, constants, errors, utils

# Used for reloading the bot - saves modified times of key files
import os
watched_files_mtimes = [(f, getmtime(f)) for f in settings.WATCHED_FILES]


#
# Helpers
#
logger = log.setup_custom_logger('obAlpha')


class Alpha(ABC):
    def __init__(self, exchange, cap):
        self.capBps = cap
        self.exchange = exchange

    @abstractmethod
    def compute(self, symbol):
        raise("compute not implemented")

    def capValue(self, value):
        if not np.isfinite(value):
            return 0.0
        if value > self.capBps:
            value = self.capBps
        if value < -self.capBps:
            value = -self.capBps
        return value

    def getName(self):
        return self.__class__.__name__

class tbob(Alpha):
    def __init__(self, exchange, cap, weights, bucketBps, orderCap=9999999, revOrderCap = 9999999):
        super(tbob, self).__init__(exchange, cap)
        self.weights = weights
        self.bucketBps = bucketBps
        self.orderCap = orderCap
        self.revOrderCap = revOrderCap

    def compute(self, symbol):
        value = 0
        ob = self.exchange.get_ob(symbol)
        bidSize = ob['bidSize']
        askSize = ob['askSize']
        bidPrice = ob['bidPrice']
        askPrice = ob['askPrice']
        bidSize = np.clip(bidSize, 0, self.revOrderCap)
        askSize = np.clip(askSize, 0, self.revOrderCap)
        bidSize[bidSize >= self.revOrderCap] = -self.orderCap
        askSize[askSize >= self.revOrderCap] = -self.orderCap
        bidSize = np.clip(bidSize, -self.orderCap, self.orderCap)
        askSize = np.clip(askSize, -self.orderCap, self.orderCap)

        tickLog = self.exchange.get_instrument(symbol)['tickLog']
        tickSize = 10**-tickLog
        length = len(self.weights)

        obBuckets = convertToObBuckets(bidPrice, bidSize, askPrice, askSize, self.bucketBps, 2*length, tickSize, tickLog)

        bidSizeNorm = np.inner(self.weights, bidSize[:length])
        askSizeNorm = np.inner(self.weights, askSize[:length])

        fairBid = bidPrice[0]
        fairAsk = askPrice[0]
        mid = (fairBid+fairAsk)/2.0
        if bidSizeNorm > askSizeNorm:
            askSizeCum = np.cumsum(askSize)
            askSizeNormArr = [np.inner(self.weights, askSize[i:(i+length)]) for i in range(length)]
            askSizeTmp = np.roll(askSizeCum,1)
            askSizeTmp[0] = 0
            askSizeTmp = [size*self.weights[0] for size in askSizeTmp]
            askSizeTmp = askSizeTmp[:length]
            askSizeNormArr = np.add(askSizeTmp, askSizeNormArr)
            fairAsk = np.interp(bidSizeNorm, askSizeNormArr, askPrice[:length])
        else:
            bidSizeCum = np.cumsum(bidSize)
            bidSizeNormArr = [np.inner(self.weights, bidSize[i:(i+length)]) for i in range(length)]
            bidSizeTmp = np.roll(bidSizeCum,1)
            bidSizeTmp[0] = 0
            bidSizeTmp = [size*self.weights[0] for size in bidSizeTmp]
            bidSizeTmp = bidSizeTmp[:length]
            bidSizeNormArr = np.add(bidSizeTmp, bidSizeNormArr)
            fairBid = np.interp(askSizeNorm, bidSizeNormArr, bidPrice[:length])

        fairMid = (fairAsk+fairBid)/2.0
        return self.capValue(1.75*((fairMid/mid)-1))

def convertToObBuckets(bidPx, bidSz, askPx, askSz, bucketBps, bucketLevels, tickSize, tickLog):
    if bidPx is None or bidSz is None or askPx is None or askSz is None:
        logger.warning("obBuckets no ob")
        return None

    buyPxBins = [utils.roundToTick(bidPx[0] * (1 - i*bucketBps), tickSize, tickLog, "up")  for i in range(bucketLevels+1)]  #create one more level to drop
    askPxBins = [utils.roundToTick(askPx[0] * (1 + i * bucketBps), tickSize, tickLog, "down") for i in range(bucketLevels+1)]
    buyBinIdx = np.digitize(bidPx, buyPxBins, right=True)
    askBinIdx = np.digitize(askPx, askPxBins, right=False)
    buySzBins = [0] * bucketLevels
    askSzBins = [0] * bucketLevels
    for i in range(bucketLevels):
        buySzBins[i] = np.sum(bidSz[buyBinIdx == (i + 1)]) #binned to right, cause descending
        askSzBins[i] = np.sum(askSz[askBinIdx == (i + 1)])

    return {"bidPrice":buyPxBins, "bidSize":buySzBins, "askPrice":askPxBins, "askSize":askSzBins}


def hitterAlphas(exchange):
    alphas = []
    alphas += [obAlpha(exchange)]
    alphas += [hitRateAlpha(exchange)]
    alphas += [fundingAlpha(exchange)]
    alphas += [riskAversionAlpha(exchange)]
    return alphas

def obAlpha(exchange):
    weight = [0.0] * 10
    sumWeight = 0
    for i in range(10):
        weight[i] = pow(1 / 1.5, i + 1)
        sumWeight += weight[i]
    for i in range(10):
        weight[i] /= sumWeight
    return tbob(exchange, 20e-4, weight, 4e-4, 50000, 100000)

def hitRateAlpha(exchange):
    return HR(exchange, 5e-4, 120, coeff=10*0.1/2500)

def riskAversionAlpha(exchange):
    return RA(exchange, 3e-4, 3e-4)



class Expma():
    def __init__(self, lag):
        self.lag = float(lag)
        self.lastTimeSecs = float(0)
        self.startTimeSecs = -1
        self.lastData = 0.0
    def compute(self, data, timeSecs):
        if self.startTimeSecs <= 0 or timeSecs - self.lastTimeSecs < -60: #date jump
            self.lastTimeSecs = timeSecs
            self.startTimeSecs = timeSecs
            self.lastData = data
        if data == 0:
            return self.lastData

        dt = timeSecs - self.lastTimeSecs
        alpha = pow(0.13533, dt/self.lag)
        alpha = np.clip(alpha, 0.0, 1.0)
        self.lastData = (1.0-alpha)*data + alpha*self.lastData
        self.lastTimeSecs = timeSecs
        if timeSecs - self.startTimeSecs < 0.5*self.lag:
            return 0
        return self.lastData

class HR(Alpha):
    def __init__(self, exchange, cap, lag, coeff=0.1*0.1/2500.):
        super(HR, self).__init__(exchange, cap)
        self.expma = Expma(lag)
        self.lastTime = datetime.utcnow()
        self.spreadCoeff = coeff

    def compute(self, symbol):
        midnight = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        secsSinceMidnight = (datetime.utcnow()-midnight).total_seconds() - 5#in case our machine time is faster, we minus 1
        trades = self.exchange.get_trades(symbol)
        if len(trades) <= 0:
            return self.capValue(self.spreadCoeff*self.expma.compute(0, secsSinceMidnight))
        trades['timestamp'] = [pd.to_datetime(ts, format="%Y-%m-%dT%H:%M:%S.%fZ") for ts in trades['timestamp']]
        sides = [1 if side == 'Buy' else -1 for side in trades['side']]
        tds = trades['timestamp']-midnight
        seconds = [td.total_seconds() for td in tds]
        for i in range(len(sides)):
            if trades['timestamp'][i] > self.lastTime and seconds[i] > 0.0:
                self.lastTime = trades['timestamp'][i]
                self.value = self.expma.compute(sides[i], seconds[i])
        return self.capValue(self.spreadCoeff * self.expma.compute(0, secsSinceMidnight))

class RA(Alpha):
    def __init__(self, exchange, cap, riskAversionsBpsAtMax):
        super(RA, self).__init__(exchange, cap)
        self.riskAversionsBpsAtMax = riskAversionsBpsAtMax

    def compute(self,symbol):
        position = self.exchange.get_delta()
        return self.capValue(np.interp(position, [settings.MIN_POSITION, settings.MAX_POSITION], [self.riskAversionsBpsAtMax, -self.riskAversionsBpsAtMax]))

class Funding(Alpha):
    def __init__(self, exchange, cap, timePairs, sides, thresholdRate=10e-4):
        super(Funding, self).__init__(exchange, cap)
        self.timePairs = timePairs
        self.sides = sides
        self.thresholdRate = thresholdRate

    def compute(self, symbol):
        midnight = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        secsSinceMidnight = (datetime.utcnow() - midnight).total_seconds()

        for i in range(len(self.timePairs)):
            if secsSinceMidnight < self.timePairs[i][0] or secsSinceMidnight > self.timePairs[i][1]:
                continue
            instrument = self.exchange.get_instrument(symbol)
            rate = instrument['fundingRate']
            if -self.thresholdRate < rate < self.thresholdRate:
                return 0
            if rate < 0:
                rate += self.thresholdRate
                rate = min(rate, -self.thresholdRate)
            else:
                rate -= self.thresholdRate
                rate = max(rate, self.thresholdRate)

            alpha = np.interp(secsSinceMidnight, self.timePairs[i], [rate*self.sides[i], np.sign(rate)*self.sides[i]*self.thresholdRate])
            return self.capValue(alpha)
        return 0.0

def fundingAlpha(exchange):
    return Funding(exchange, 10e-4,
                   [[14100-10, 14400], [14400+2.5, 14420], [42900-10, 43200], [43200+2.5, 43220], [71700-10, 72000], [72000+2.5, 72020]],
                   [-1,1,-1,1,-1,1], 0.0006)

