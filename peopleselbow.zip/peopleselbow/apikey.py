import getpass
from market_maker.settings import settings
import socket
from Crypto.Cipher import AES
import base64
import logging

encryptedPairs = {"Desktop": ["chw9KS3kfrQ7Pqj1CVKqfhec", b'VkL6Jq0M2pk1Umb7hgQSAJJl/JN+8JWU9oCitJbygOD9tkqssTdgLXzhaFqknTKR'], \
                  "EC2AMAZ-HHBEI6K":["PYHdNVkXaJXa6Xpaq3MmyDko", b'9Xue6vxyBUh7ln2XnM7OaOhzSlt+XJ9ZqF154Wh6dHEObWXk2xafej/4Z/jAKCB4']}


def updateSettingsKeys():
    if settings.testNet==False:
        settings.CHECK_POSITION_LIMITS = True
        response = getpass.getpass("Enter Prod password (enter random for testnet): ")
        cipher = AES.new(response.rjust(32), AES.MODE_ECB)
        encryptedPair = encryptedPairs[socket.gethostname()]
        try:
            settings.API_SECRET = cipher.decrypt(base64.b64decode(encryptedPair[1])).decode("utf-8")
            settings.API_KEY = encryptedPair[0]
            settings.BASE_URL = "https://www.bitmex.com/api/v1/"  # Once you're ready, uncomment this.
        except:
            logging.error("\n\n@@@@invalid password, switching to testnet@@@@@\n@@@@invalid password, switching to testnet@@@@@\n")

    if not settings.testNet and settings.DRY_RUN==False:
        response = input("send orders to market in PROD (False for sim)? (T/F) : ")
        settings.CHECK_POSITION_LIMITS = True
        if not (response == "T" or response =="t"):
            settings.DRY_RUN = True
