import json
from datetime import datetime, timedelta
import pytz
import threading

tzoffset = 8 * 3600


def dt2utc(dt):
    epoch = datetime.utcfromtimestamp(0)
    delta = dt - epoch
    return int(delta.total_seconds() - tzoffset)


def date2str(dt):
    return dt.strftime('%Y-%m-%d')


def str2date(str):
    return datetime.strptime(str, '%Y-%m-%d')


def str2dt(str):
    return datetime.strftime(str, '%Y-%m-%d %H:%M:%S')


def utc2dt(utc):
    dt = datetime.fromtimestamp(utc + tzoffset, tz=pytz.utc)
    dt = dt.replace(tzinfo=None)
    return dt


def utcnow():
    return dt2utc(datetime.now())


def now():
    return datetime.now()


def today():
    return datetime.date(now())


def return_threads(funcs, names=(), timeout=None):
    class RtThread(threading.Thread):
        def __init__(self, func, name):
            threading.Thread.__init__(self, name=name)
            self.func = func
            self.result = None

        def run(self):
            try:
                self.result = self.func()
            except:
                self.result = None

        def join(self, *args, **kwargs):
            super(RtThread, self).join(*args, **kwargs)
            return self.result

    threads = []
    for i, func in enumerate(funcs):
        name = names[i] if len(names) > i else None
        t = RtThread(func, name)
        threads.append(t)
        t.start()
    return [t.join(timeout) for t in threads]


def load_conf(conf):
    return json.load(open(conf))
