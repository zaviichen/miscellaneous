#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib
import hashlib
import time
import requests

HUOBI_SERVICE_API = "https://api.huobi.com/apiv3"

BUY_MARKET = "buy_market"
CANCEL_ORDER = "cancel_order"
NEW_DEAL_ORDERS = "get_new_deal_orders"
ORDER_ID_BY_TRADE_ID = "get_order_id_by_trade_id"
GET_ORDERS = "get_orders"
ORDER_INFO = "order_info"
SELL_MARKET = "sell_market"


def signature(params):
    params = sorted(params.iteritems(), key=lambda d: d[0], reverse=False)
    message = urllib.urlencode(params)
    m = hashlib.md5()
    m.update(message)
    m.digest()
    sig = m.hexdigest()
    return sig


class HoubiApi(object):
    def __init__(self, access_key, secret_key):
        self.access_key = access_key
        self.secret_key = secret_key

    def getAccountInfo(self):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp, "method": "get_account_info"}
        sign = signature(params)
        params['sign'] = sign

        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def buy(self, coinType, price, amount, tradePassword, tradeid):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp, "price": price,
                  "coin_type": coinType, "amount": amount, "method": "buy"}
        sign = signature(params)
        params['sign'] = sign
        del params['secret_key']
        if tradePassword:
            params['trade_password'] = tradePassword
        if tradeid:
            params['trade_id'] = tradeid

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def buyMarket(self, coinType, amount, tradePassword, tradeid, method):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp,
                  "coin_type": coinType,
                  "amount": amount, "method": method}
        sign = signature(params)
        params['sign'] = sign
        if tradePassword:
            params['trade_password'] = tradePassword
        if tradeid:
            params['trade_id'] = tradeid

        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def cancelOrder(self, coinType, id, method):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp,
                  "coin_type": coinType, "id": id,
                  "method": method}
        sign = signature(params)
        params['sign'] = sign
        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def getNewDealOrders(self, coinType, method):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp,
                  "coin_type": coinType,
                  "method": method}
        sign = signature(params)
        params['sign'] = sign
        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def getOrderIdByTradeId(self, coinType, tradeid, method):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp,
                  "coin_type": coinType,
                  "method": method, "trade_id": tradeid}
        sign = signature(params)
        params['sign'] = sign
        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def getOrders(self, coinType, method):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp,
                  "coin_type": coinType,
                  "method": method}
        sign = signature(params)
        params['sign'] = sign
        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def getOrderInfo(self, coinType, id, method):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp,
                  "coin_type": coinType,
                  "method": method, "id": id}
        sign = signature(params)
        params['sign'] = sign
        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def sell(self, coinType, price, amount, tradePassword, tradeid):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp, "price": price,
                  "coin_type": coinType, "amount": amount, "method": "sell"}
        sign = signature(params)
        params['sign'] = sign
        del params['secret_key']
        if tradePassword:
            params['trade_password'] = tradePassword
        if tradeid:
            params['trade_id'] = tradeid

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None

    def sellMarket(self, coinType, amount, tradePassword, tradeid, method):
        timestamp = long(time.time())
        params = {"access_key": self.access_key, "secret_key": self.secret_key, "created": timestamp,
                  "coin_type": coinType,
                  "amount": amount, "method": method}
        sign = signature(params)
        params['sign'] = sign
        if tradePassword:
            params['trade_password'] = tradePassword
        if tradeid:
            params['trade_id'] = tradeid

        del params['secret_key']

        payload = urllib.urlencode(params)
        r = requests.post(HUOBI_SERVICE_API, params=payload)
        if r.status_code == 200:
            data = r.json()
            return data
        else:
            return None
