from model import Tick, Account
from utils import dumps, json_request, return_threads
from env import Env
from exchange import Exchange
from exchange.houbi.restapi import HoubiApi
from functools import partial

exchange = "houbi"


def _hbsym(sym):
    if sym == 'btc':
        return '1'
    elif sym == 'ltc':
        return '2'
    else:
        return sym


class HoubiExch(Exchange):
    def __init__(self, params):
        super(HoubiExch, self).__init__(params)
        self.name = exchange
        self.api = HoubiApi(params['access_key'], params['secret_key'])

    def get_tick(self, sym):
        t = Tick(exchange, sym)
        if sym == 'btc':
            ticker_url = 'http://api.huobi.com/staticmarket/ticker_btc_json.js'
            orderbook_url = 'http://api.huobi.com/staticmarket/depth_btc_5.js'
        elif sym == 'ltc':
            ticker_url = 'http://api.huobi.com/staticmarket/ticker_ltc_json.js'
            orderbook_url = 'http://api.huobi.com/staticmarket/depth_ltc_5.js'
        else:
            ticker_url = ''
            orderbook_url = ''

        tkfunc = partial(json_request, ticker_url)
        obfunc = partial(json_request, orderbook_url)
        (tk, ob) = return_threads([tkfunc, obfunc], timeout=Env.ticker_interval)

        if tk is not None:
            t.sutc = int(tk['time'])
            tk = tk['ticker']
            t.last = float(tk['last'])
            t.volume = float(tk['vol'])
            t.bid0 = float(tk['buy'])
            t.ask0 = float(tk['sell'])
        if ob is not None:
            asks = ob['asks'][::-1]
            t._ap = [e[0] for e in asks]
            t._as = [e[1] for e in asks]
            bids = ob['bids']
            t._bp = [e[0] for e in bids]
            t._bs = [e[1] for e in bids]
        t.lutc = Env.utcnow()
        return t

    def get_balance(self):
        acct = self.api.getAccountInfo()
        a = Account(self.name)
        a.btc = float(acct['available_btc_display'])
        a.ltc = float(acct['available_ltc_display'])
        a.cny = float(acct['available_cny_display'])
        self.account = a
        return a

    def send_order(self, sym, qty, prc):
        if qty > 0:
            res = self.api.buy(_hbsym(sym), str(prc), str(qty), None, None)
        else:
            res = self.api.sell(_hbsym(sym), str(prc), str(-qty), None, None)
        print res
        if str(res['result']) == 'success':
            return res['id']
        else:
            return -1


if __name__ == "__main__":
    params = {
        "access_key": "f04786bf-1cbe3598-edf7bc03-7cf77",
        "secret_key": "6af577ac-2122432f-a6f89a9d-2d780"
    }
    ex = HoubiExch(params)
    print ex.get_balance()
    t = ex.get_tick('btc')
    print t
    print ex.send_order('btc', 0.01, t._bs[-1])
    print ex.send_order('btc', -0.01, t._ap[-1])
