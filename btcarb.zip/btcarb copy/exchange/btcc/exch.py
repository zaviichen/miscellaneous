import restapi
from exchange import Exchange
from model import Tick, Account
from env import Env
from utils import dumps, json_request, return_threads
from functools import partial

exchange = "btcc"

ticker_url = 'https://data.btcchina.com/data/ticker?market={0}'
orderbook_url = 'https://data.btcchina.com/data/orderbook?market={0}&limit=5'


def _btccsym(sym):
    if sym == 'btc':
        return 'btccny'
    elif sym == 'ltc':
        return 'ltccny'
    else:
        return sym


class BtccExch(Exchange):
    def __init__(self, params):
        super(BtccExch, self).__init__(params)
        self.name = exchange
        self.api = restapi.BTCChina(params['access_key'], params['secret_key'])

    def get_tick(self, sym):
        t = Tick(self.name, sym)

        tkfunc = partial(json_request, ticker_url.format(_btccsym(sym)))
        obfunc = partial(json_request, orderbook_url.format(_btccsym(sym)))
        (tk, ob) = return_threads([tkfunc, obfunc], timeout=Env.ticker_interval)

        if tk is not None:
            tk = tk['ticker']
            t.sutc = int(tk['date'])
            t.last = float(tk['last'])
            t.volume = float(tk['vol'])
            t.bid0 = float(tk['buy'])
            t.ask0 = float(tk['sell'])

        if ob is not None:
            asks = ob['asks'][::-1]
            t._ap = [e[0] for e in asks]
            t._as = [e[1] for e in asks]
            bids = ob['bids']
            t._bp = [e[0] for e in bids]
            t._bs = [e[1] for e in bids]
        t.lutc = Env.utcnow()
        self.tick = t
        return t

    def get_balance(self):
        _acct = self.api.get_account_info()
        balance = _acct['balance']
        a = Account(self.name)
        a.btc = float(balance['btc']['amount'])
        a.ltc = float(balance['ltc']['amount'])
        a.cny = float(balance['cny']['amount'])
        self.account = a
        return a

    def send_order(self, sym, qty, prc):
        if qty == 0 or prc <= 0:
            print("wrong qry or prc.")
            return -1
        if qty > 0:
            return self.api.buy(prc, qty, _btccsym(sym))
        else:
            return self.api.sell(prc, -qty, _btccsym(sym))


if __name__ == "__main__":
    access_key = "0c0d5a87-8ddb-47a6-97f9-3d787953f37f"
    secret_key = "967e27b0-f3c8-4669-a8df-cb6ad612f6c6"

    ex = BtccExch(access_key, secret_key)
    print ex.get_balance('cny')
    t = ex.get_tick('btc')
    print t
    print ex.send_order('btc', 0.01, t._bs[-1])
    print ex.send_order('btc', -0.01, t._ap[-1])
