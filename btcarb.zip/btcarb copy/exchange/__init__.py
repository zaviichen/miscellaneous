import zmq


class Exchange(object):

    def __init__(self, params):
        self.name = ''
        self.access_key = params['access_key']
        self.secret_key = params['secret_key']
        self.tick = None
        self.account = None
        self.params = params

        # zmq settings
        self.context = zmq.Context()
        self.pub = self.context.socket(zmq.PUB)
        try:
            pub_addr = self.params["zmq_pub"]
            print("bind pub address: {0}".format(pub_addr))
            self.pub.bind(pub_addr)
        except Exception as ex:
            print(ex)

    def publish(self, topic, msg):
        try:
            print("{0}|{1}".format(topic, msg))
            self.pub.send_string("{0}|{1}".format(topic, msg))
        except Exception as ex:
            print(ex)
