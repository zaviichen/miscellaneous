from model import Tick, Account
from utils import dumps, return_threads
from env import Env
from exchange import Exchange
from exchange.okcoin.restapi import OKCoinSpot
import simplejson as json
from functools import partial

exchange = "okcoin"


def _oksym(sym):
    if sym == 'btc':
        return 'btc_cny'
    elif sym == 'ltc':
        return 'ltc_cny'
    else:
        return sym



class OkcoinExch(Exchange):
    def __init__(self, params):
        super(OkcoinExch, self).__init__(params)
        self.name = exchange
        self.api = OKCoinSpot("www.okcoin.cn", params['access_key'], params['secret_key'])

    def get_tick(self, sym):
        t = Tick(self.name, sym)

        tkfunc = partial(self.api.ticker, _oksym(sym))
        obfunc = partial(self.api.depth, _oksym(sym), 5)
        (tk, ob) = return_threads([tkfunc, obfunc], timeout=Env.ticker_interval)

        if tk is not None:
            t.sutc = int(tk['date'])
            tk = tk['ticker']
            t.last = float(tk['last'])
            t.volume = float(tk['vol'])
            t.bid0 = float(tk['buy'])
            t.ask0 = float(tk['sell'])
        if ob is not None:
            asks = ob['asks'][::-1]
            t._ap = [e[0] for e in asks]
            t._as = [e[1] for e in asks]
            bids = ob['bids']
            t._bp = [e[0] for e in bids]
            t._bs = [e[1] for e in bids]
        t.lutc = Env.utcnow()
        self.tick = t
        return t

    def get_balance(self):
        acct = json.loads(self.api.userinfo())
        free = acct['info']['funds']['free']
        a = Account(self.name)
        a.btc = float(free['btc'])
        a.ltc = float(free['ltc'])
        a.cny = float(free['cny'])
        self.account = a
        return a

    def send_order(self, sym, qty, prc):
        if qty > 0:
            res = self.api.trade(_oksym(sym), 'buy', str(prc), str(qty))
        else:
            res = self.api.trade(_oksym(sym), 'sell', str(prc), str(-qty))
        res = json.loads(res)
        print(res)
        if res['result'] != True:
            return -res['error_code']
        else:
            return res['order_id']


if __name__ == "__main__":
    params = {
        "access_key": "495f84ac-3bc4-4355-821e-73cf8ddf9cfe",
        "secret_key": "9844E17C2565D78787CFF6165DF150A6"
    }
    ex = OkcoinExch(params)
    print ex.get_balance()
    t = ex.get_tick('btc')
    print t
    print ex.send_order('btc', 0.01, t._bs[-1])
    print ex.send_order('btc', -0.01, t._ap[-1])
