import requests
import time
import threading
import os.path
from utils import utcnow, now, today, load_conf
from model import Tick, Account, Order
from exchange import Exchange

def encryption(params, secret_key):
    import hashlib
    sign = ''
    for key in sorted(params.keys()):
        sign += key + '=' + str(params[key]) + '&'
    data = sign + 'secret_key=' + secret_key
    return hashlib.md5(data.encode("utf8")).hexdigest().upper()


class OkCoinCn(Exchange):
    """ https: // www.okcoin.cn/about/rest_api.do """
    root = "www.okcoin.cn"

    def __init__(self, params):
        super(OkCoinCn, self).__init__(params)
        self.name = 'okcoin'
        self.timeout = params.get('timeout', 1)
        print("okcoin init.")

    def _get(self, url, params):
        try:
            r = requests.get("https://{0}/{1}".format(OkCoinCn.root, url), params=params, timeout=self.timeout)
            print(r.url)
            return r.json()
        except Exception as ex:
            print(ex)
            return None

    def _post(self, url, params):
        try:
            r = requests.post("https://{0}/{1}".format(OkCoinCn.root, url), data=params, timeout=self.timeout)
            print(r.url)
            return r.json()
        except Exception as ex:
            print(ex)
            return None

    def _get_ticker(self, sym):
        return self._get("api/v1/ticker.do", {'symbol': sym})

    def _get_depth(self, sym, size=5, merge=0.01):
        return self._get("api/v1/depth.do", {'symbol': sym, 'size': size, 'merge': merge})

    def _get_trades(self, sym):
        return self._get("api/v1/trades.do", {'symbol': sym})

    def _get_kline(self, sym, _type='1day', size=60):
        return self._get("api/v1/kline.do", {'symbol': sym, 'type': _type, 'size': size})

    def _post_userinfo(self):
        params = {'api_key': self.access_key}
        params['sign'] = encryption(params, self.secret_key)
        return self._post("api/v1/userinfo.do", params)

    def _post_trade(self, symbol, _type, price='', amount=''):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'type': _type
        }
        if price:
            params['price'] = price
        if amount:
            params['amount'] = amount
        params['sign'] = encryption(params, self.secret_key)
        return self._post("api/v1/trade.do", params)

    def _post_cancel_order(self, symbol, oids):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'order_id': ','.join(str(o) for o in oids)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("api/v1/cancel_order.do", params)

    def _post_order_info(self, symbol, oid):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'order_id': str(oid)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("api/v1/order_info.do", params)

    def _post_orders_info(self, symbol, type, oids):
        params = {
            'api_key': self.access_key,
            'symbol': symbol,
            'type': type,
            'order_id': ','.join(str(o) for o in oids)
        }
        params['sign'] = encryption(params, self.secret_key)
        return self._post("api/v1/orders_info.do", params)

    def create_tick(self, sym, tk, ob):
        t = Tick(self.name, sym)
        if tk is not None:
            t.sutc = int(tk['date'])
            tk = tk['ticker']
            t.last = float(tk['last'])
            t.accvol = float(tk['vol'])
            t.bid = float(tk['buy'])
            t.ask = float(tk['sell'])
        if ob is not None:
            asks = ob['asks'][::-1]
            t._ap = [e[0] for e in asks]
            t._as = [e[1] for e in asks]
            bids = ob['bids']
            t._bp = [e[0] for e in bids]
            t._bs = [e[1] for e in bids]
        t.lutc = utcnow()
        return t

    def create_account(self, acct):
        free = acct['info']['funds']['free']
        a = Account(self.name)
        a.btc = float(free['btc'])
        a.ltc = float(free['ltc'])
        a.cny = float(free['cny'])
        return a

    def create_order(self, info):
        o = Order(info['symbol'], info['price'], info['amount'])
        o.id = info['order_id']
        qdone = info['deal_amount']
        o.qfill = qdone - o.qdone
        o.qdone = qdone
        o.avg_price = info['avg_price']
        o.update_utc = utcnow()
        o.init_utc = int(info['create_date'] / 1000)
        type = info['type']
        if type == 'buy' or type == 'buy_market':
            o.side = Order.Side.Buy
        else:
            o.side = Order.Side.Sell
        status = info['status']
        if status == 0 or status == 1:
            o.status = Order.Status.Live
        elif status == -1:
            o.status = Order.Status.Cancel
        elif status == 2:
            o.status = Order.Status.Fill
        else:
            o.status = Order.Status.Unknown


    def get_tick(self, sym):
        ticker = self._get_ticker(sym)
        depth = self._get_depth(sym, size=5, merge=1)
        t = self.create_tick(sym, ticker, depth)
        return t

    def subscribe_market_data(self, sym):
        root = self.params['root']
        interval = self.params.get('tick_interval', 2)

        file = "{0}/{1}.{2}.{3}.dat".format(root, self.name, sym, today())
        f = open(file, 'a')
        if os.path.isfile(file) and os.path.getsize(file) == 0:
            f.write(Tick.csv_header() + '\n')

        last_ticker_update = 0
        while True:
            time.sleep(0.2)
            utc = utcnow()
            if utc % interval != 0:
                continue
            if utc - last_ticker_update < interval:
                continue
            else:
                last_ticker_update = utc
            now_ = now()
            if now_.hour == 23 and now_.minute == 59 and now_.second >= 50:
                print("time exit: {0}".format(now_))
                break
            try:
                t = self.get_tick(sym)
                msg = t.to_csv()
                f.write(msg + '\n')

                topic = "{0}:{1}".format(self.name, sym)
                self.publish(topic, msg)
            except Exception as ex:
                print(ex)
            finally:
                f.flush()
        f.close()

    def send_order(self, sym, qty, prc):
        if qty > 0:
            res = self._post_trade(sym, 'buy', str(prc), str(qty))
        else:
            res = self._post_trade(sym, 'sell', str(prc), str(-qty))
        # print(res)
        if res['result'] != True:
            return -res['error_code']
        else:
            return res['order_id']

    def cancel_order(self, sym, oids):
        res = self._post_cancel_order(sym, oids)
        # print(res)
        res2 = {}
        if res['success'] != '':
            for oid in res['success'].split(','):
                res2[int(oid)] = True
        if res['error'] != '':
            for oid in res['error'].split(','):
                res2[int(oid)] = False
        return res2

    def order_info(self, sym, oid):
        res = self._post_order_info(sym, oid)
        print(res)

    def orders_info(self, sym, oids, is_complete):
        type = 1 if is_complete else 0
        res = self._post_orders_info(sym, type, oids)
        print(res)

    def start(self):
        print("okcoin start.")
        threads = []
        for sym in self.params['symbol']:
            print("subscribe {0}".format(sym))
            t = threading.Thread(target=self.subscribe_market_data, args=(sym,))
            threads.append(t)
            t.start()
        [t.join() for t in threads]


if __name__ == '__main__':
    import sys

    conf = "/Users/zhchen/PycharmProjects/btcarb/exchange/okcoin/config.json"
    if len(sys.argv) > 1:
        conf = sys.argv[1]

    params = load_conf(conf)
    ex = OkCoinCn(params)
    # ex.start()
    info =  ex._post_userinfo()
    print ex.create_account(info)

    sym = 'btc_cny'
    t = ex.get_tick(sym)
    print(t)
    order_ids = []
    order_ids.append(ex.send_order(sym, -0.01, t._ap[-1]))
    order_ids.append(ex.send_order(sym, -0.01, t._ap[-1]))
    print(order_ids)
    # print(ex.cancel_order(sym, order_ids))
    print(ex.order_info(sym, order_ids[1]))
    print(ex.orders_info(sym, order_ids, True))
    print(ex.orders_info(sym, order_ids, False))
    # print(ex.orders_info(sym, order_ids[1]))