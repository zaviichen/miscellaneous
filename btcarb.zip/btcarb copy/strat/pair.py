import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from model import Tick

tickdf = pd.read_csv("/Users/zhchen/PycharmProjects/btcarb/data/ticker.dat.2016-07-29", header=None)
Tick.level  = 3
tickdf.columns = Tick.csv_header().split(',')
tickdf = tickdf.set_index(pd.to_datetime(tickdf.time), drop=True)


df = tickdf.query("symbol=='btc' and last > 0")
df['mid'] = (df.ap0 + df.bp0) / 2
df['spread'] = (df.ap0 - df.bp0) / df.mid

x = df.pivot(columns='exch', values='mid')
x = x.fillna(method='pad')
r= (x - x.iloc[0]) / x.iloc[0]
ex1 = 'houbi'
ex2 = 'okcoin'
r['ex1-ex2'] = r[ex1] - r[ex2]

# ids = r[r.okcoin < -0.5].index
# print df[df.exch=='okcoin'].ix[ids]
y = df.pivot(columns='exch', values='spread')

fig, (ax0, ax1, ax2) = plt.subplots(3, 1, sharex=True)
r.plot(y=[ex1,ex2,'ex1-ex2'], ax=ax0)
y.plot(y=[ex1,ex2], ax=ax1)
profit = r['ex1-ex2'].abs() - (y[ex1] + y[ex2])
profit.plot(ax=ax2)

# btc vs ltc

# df = tickdf.query("exch=='okcoin' and last > 0")
# df['mid'] = (df.ask0 + df.bid0) / 2
# df['spread'] = (df.ap0 - df.bp0) / df.mid
#
# x = df.pivot(columns='symbol', values='mid')
# x = x.fillna(method='pad')
# r= (x - x.iloc[0]) / x.iloc[0]
# ex1 = 'btc'
# ex2 = 'ltc'
# pair = '{0}-{1}'.format(ex1, ex2)
# r[pair] = r[ex1] - r[ex2]
# print r[ex1].corr(r[ex2])
#
#
# y = df.pivot(columns='symbol', values='spread')
#
# _, (ax0, ax1, ax2) = plt.subplots(3, 1, sharex=True)
# r.plot(y=[ex1,ex2,pair], ax=ax0)
# y.plot(y=[ex1,ex2], ax=ax1)
# profit = r[pair].abs() - (y[ex1] + y[ex2])
# profit.plot(ax=ax2)


#
# main strategy
#
corr = 1.0
open_threshold = 2*1e-4
close_threshold = 1*1e-4

import sys
import time
from env import Env
from utils import return_threads
from functools import partial
from exchange.okcoin.exch import OkcoinExch

conf = "/Users/zhchen/PycharmProjects/btcarb/config.json"
if len(sys.argv) > 1:
    conf = sys.argv[1]

Env.init(conf)
print("initialized env from config file: {0}".format(conf))

ex = OkcoinExch(Env.conf['exchanges']['okcoin'])

ticker_funcs = []
ticker_funcs.append(partial(ex.get_tick, 'btc'))
ticker_funcs.append(partial(ex.get_tick, 'ltc'))
acct = ex.get_balance()
print("init account: {0}".format(acct))

last_ticker_update = 0
btcs = []
ltcs = []
is_opened = False
pair_pos = {'btc': 0., 'ltc': 0.}


while True:
    now = Env.utcnow()
    if now % Env.ticker_interval != 0:
        time.sleep(0.2)
        continue
    if now - last_ticker_update < Env.ticker_interval:
        continue
    else:
        last_ticker_update = now

    ticks = return_threads(ticker_funcs, timeout=Env.ticker_interval - 0.2)
    for t in ticks:
        if t is None:
            continue
        if t.last <= 0 or t.ask <=0 or t.bid <= 0:
            continue
        print("{0}: bid/ask={1: >8}/{2: >8}, mid={3: >8}, last={4: >8}".format(
            t.symbol, t.bid, t.ask, t.mid, t.last))
        if t.symbol == 'btc':
            btcs.append(t)
        if t.symbol == 'ltc':
            ltcs.append(t)

    if len(btcs) < 5 or len(ltcs) < 5:
        continue

    btc = btcs[-1]
    ltc = ltcs[-1]
    br = (btc.mid - btcs[0].mid) / btcs[0].mid
    lr = (ltc.mid - ltcs[0].mid) / ltcs[0].mid

    bsize = 0.02
    lsize = round((btc.last * bsize) / ltc.last, 1)

    spread = br - lr * corr
    print("spread={0:.4f}, btc return={1:.4f}, ltc return={2:.4f}".format(spread, br, lr))
    boid = -1
    loid = -1

    if not is_opened and abs(spread) > open_threshold:
        if spread > 0:
            print("open pair|spread={0:.5f}, btc={1}@{2}, ltc={3}@{4}".format(spread, bsize, btc.ask, -lsize, ltc.bid))
            boid = ex.send_order('btc', bsize, btc.ask)
            loid = ex.send_order('ltc', -lsize, ltc.bid)
            pair_pos['btc'] = bsize
            pair_pos['ltc'] = -lsize
        else:
            print("open pair|spread={0:.5f}, btc={1}@{2}, ltc={3}@{4}".format(spread, -bsize, btc.bid, lsize, ltc.ask))
            boid = ex.send_order('btc', -bsize, btc.bid)
            loid = ex.send_order('ltc', lsize, ltc.ask)
            pair_pos['btc'] = -bsize
            pair_pos['ltc'] = lsize
        print("btc oid={0}, ltc oid={1}".format(boid, loid))
        if boid > 0 and loid > 0:
            is_opened = True
            # need to query order status
            acct = ex.get_balance()
            print("update account: {0}".format(acct))
        else:
            if boid == -1 and loid > 0:
                print("btc failed, cancel ltc...")
                # ex.cancel_order(loid)
            if loid == -1 and boid > 0:
                print("ltc failed, cancel btc...")
                # ex.cancel_order(boid)

    if is_opened and abs(spread) < close_threshold:
        bqty = -pair_pos['btc']
        lqty = -pair_pos['ltc']
        if bqty < 0:
            print("close pair|spread={0:.5f}, btc={1}@{2}, ltc={3}@{4}".format(
                spread, bqty, btc.bid, lqty, ltc.ask))
            boid = ex.send_order('btc', bqty, btc.bid)
            loid = ex.send_order('ltc', bqty, ltc.ask)
        else:
            print("close pair|spread={0:.5f}, btc={1}@{2}, ltc={3}@{4}".format(
                spread, bqty, btc.ask, lqty, ltc.bid))
            boid = ex.send_order('btc', bqty, btc.ask)
            loid = ex.send_order('ltc', bqty, ltc.bid)
        pair_pos['btc'] = 0
        pair_pos['ltc'] = 0
        print("btc oid={0}, ltc oid={1}".format(boid, loid))
        if boid > 0 and loid > 0:
            is_opened = False
            # need to query order status
            acct = ex.get_balance()
            print("update account: {0}".format(acct))
        else:
            if boid == -1 and loid > 0:
                print("btc failed, cancel ltc...")
                # ex.cancel_order(loid)
            if loid == -1 and boid > 0:
                print("ltc failed, cancel btc...")
                # ex.cancel_order(boid)
