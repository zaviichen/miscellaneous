from utils import utc2dt, utcnow


class Tick(object):
    level = 5

    def __init__(self, exch, sym):
        self.exch = exch
        self.symbol = sym
        self.last = 0
        self.accvol = 0
        self.bid = 0
        self.ask = 0
        self._ap = []
        self._bp = []
        self._as = []
        self._bs = []
        self.iutc = utcnow()    # local init utc
        self.lutc = 0           # local received utc
        self.sutc = 0           # server response utc

    def __str__(self):
        return str(self.__dict__)

    def to_csv(self):
        n = Tick.level
        items = [utc2dt(self.iutc), self.exch, self.symbol, self.last, self.accvol, self.bid, self.ask]
        if len(self._ap) >= n:
            items += self._ap[:n] + self._as[:n] + self._bp[:n] + self._bs[:n]
        else:
            items += [0] * (n * 4)
        items += [self.iutc, self.lutc, self.sutc]
        return ",".join(str(e) for e in items)

    @staticmethod
    def csv_header():
        header = "time,exch,symbol,last,accvol,buy,sell,{0},iutc,lutc,sutc"
        q = ','.join(
            ['ap{0}'.format(i) for i in range(Tick.level)] +
            ['as{0}'.format(i) for i in range(Tick.level)] +
            ['bp{0}'.format(i) for i in range(Tick.level)] +
            ['bs{0}'.format(i) for i in range(Tick.level)])
        return header.format(q)


class Account(object):

    def __init__(self, exch):
        self.exch = exch
        self.btc = 0
        self.ltc = 0
        self.cny = 0
        self.iutc = utcnow()

    def __str__(self):
        return str(self.__dict__)


class Order(object):

    class Side:
        Buy = 'Buy'
        Sell = 'Sell'

    class Status:
        Init = 'Init'
        Live = 'Live'
        Fill = 'Fill'
        Cancel = 'Cancel'
        Reject = 'Reject'
        Unknown = 'Unknown'

    def __init__(self, sym, qty, prc):
        self.id = 0
        self.symbol = sym
        self.price = prc
        self.quantity = qty
        self.side = Order.Side.Buy
        self.status = Order.Status.Init
        self.init_utc = utcnow()
        self.update_utc = 0
        self.qdone = 0
        self.qfill = 0
        self.avg_price = 0

    def __str__(self):
        return str(self.__dict__)

    @property
    def qopen(self):
        return self.quantity - self.qdone

    @property
    def value(self):
        return self.quantity * self.price

    def update(self, rsp):
        self.id = int(rsp['order_id'])
        qdone = float(rsp['deal_amount'])
        self.qfill = qdone - self.qdone
        self.qdone = qdone
        self.avg_price = float(rsp['avg_price'])
        self.update_utc = utcnow()
        status = rsp['status']
        if status == 0 or status == 1:
            self.status = Order.Status.Live
        elif status == -1:
            self.status = Order.Status.Cancel
        elif status == 2:
            self.status = Order.Status.Fill
        else:
            self.status = Order.Status.Unknown