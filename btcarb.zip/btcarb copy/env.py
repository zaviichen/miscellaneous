import zmq
import logging
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler
import simplejson as json
from utils import dt2utc


class Env(object):
    _init = False
    _context = None
    _pub = None
    _sub = None
    _logger = None

    conf = None
    exchanges = []
    ticker_interval = 3

    @classmethod
    def init(cls, conf):
        if cls._init:
            return
        cls._init = True
        cls.conf = json.load(open(conf))
        cls.ticker_interval = int(cls.conf['ticker_interval'])

        if "zmq_pub" in cls.conf:
            cls._context = zmq.Context()
            cls._pub = cls._context.socket(zmq.PUB)
            cls._pub.bind(cls.conf["zmq_pub"])

        cls._logger = logging.getLogger("execution")
        handler = TimedRotatingFileHandler("{0}/execution.log".format(cls.conf['root']), when="MIDNIGHT")
        handler.setFormatter(logging.Formatter("%(asctime)s|%(message)s"))
        cls._logger.addHandler(handler)
        cls._logger.setLevel(logging.INFO)

    @classmethod
    def log(cls, msg):
        cls._logger.info(msg)

    @classmethod
    def pub(cls, msg):
        if cls._pub is not None:
            cls._pub.send(msg)

    @staticmethod
    def now():
        return datetime.now()

    @staticmethod
    def utcnow():
        return dt2utc(datetime.now())

    @staticmethod
    def today():
        return datetime.date(datetime.now())
