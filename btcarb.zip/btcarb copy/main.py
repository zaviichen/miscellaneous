import sys
import time
from env import Env
from utils import return_threads, dumps
from functools import partial
from exchange.btcc.exch import BtccExch
from exchange.okcoin.exch import OkcoinExch
from exchange.houbi.exch import HoubiExch

conf = "/Users/zhchen/PycharmProjects/btcarb/config.json"
if len(sys.argv) > 1:
    conf = sys.argv[1]

Env.init(conf)
Env.log("initialized env from config file: {0}".format(conf))

exchanges = {}

if 'btcc' in Env.exchanges:
    exchanges['btcc'] = BtccExch(Env.conf['exchanges']['btcc'])

if 'okcoin' in Env.exchanges:
    exchanges['okcoin'] = OkcoinExch(Env.conf['exchanges']['okcoin'])

if 'houbi' in Env.exchanges:
    exchanges['houbi'] = HoubiExch(Env.conf['exchanges']['houbi'])

ticker_funcs = []
for ex in exchanges.values():
    ticker_funcs.append(partial(ex.get_tick, 'btc'))
    ticker_funcs.append(partial(ex.get_tick, 'ltc'))
    acct = ex.get_balance()
    Env.log("init account: {0}".format(acct))
    # Env.tklog(ex.name, Tick.csvheader())

last_ticker_update = 0

while True:
    now = Env.utcnow()
    if now % Env.ticker_interval != 0:
        time.sleep(0.2)
        continue
    if now - last_ticker_update < Env.ticker_interval:
        continue
    else:
        last_ticker_update = now

    ticks = return_threads(ticker_funcs, timeout=Env.ticker_interval - 0.2)
    for t in ticks:
        print t
        if t is not None:
            Env.tklog(t.tocsv())
            Env.pub("{0}:{1} {2}".format(t.exch, t.symbol, dumps(t)))
